﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace NetworkTopology
{
    class FileOperClass
    {
        /// <summary>
        /// 导出ListView 到excel文件
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="myListView"></param>
        public void ExportExcel(string fileName, ListView myListView)
        {
            if (myListView.Items.Count > 0)
            {
                string saveFileName = "";
                //bool fileSaved = false;  
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.DefaultExt = "xlsx";
                saveDialog.Filter = "Excel 2007文件|*.xlsx|Excel 99-03文件|*.xls";
                saveDialog.FileName = fileName;
                if (saveDialog.ShowDialog() == DialogResult.Cancel)
                    return;

                //被点了取消  
                if (saveDialog.FileName.IndexOf(":") < 0)
                    return;

                saveFileName = saveDialog.FileName;
                if (saveFileName.IndexOf(":") < 0) return; //被点了取消   
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (xlApp == null)
                {
                    MessageBox.Show("无法创建Excel对象，可能该设备未安装Excel", "警告", MessageBoxButtons.OK);
                    return;
                }

                Microsoft.Office.Interop.Excel.Workbooks workbooks = xlApp.Workbooks;
                Microsoft.Office.Interop.Excel.Workbook workbook = workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];//取得sheet1  

                //写入标题，即列名
                for (int i = 1; i <= myListView.Columns.Count; i++)
                {
                    worksheet.Cells[1, i + 1] = myListView.Columns[i - 1].Text;
                }

                //写入数值
                for (int r= 0; r < myListView.Items.Count; r++)
                {
                    for (int i = 0; i < myListView.Columns.Count; i++)
                    {
                        try
                        {
                            if (myListView.Items[r].SubItems[i].Text!=String.Empty)
                                worksheet.Cells[r + 2, i + 1] = myListView.Items[r].SubItems[i].Text;
                        }
                        catch
                        {
                        }
                        
                    }
                    System.Windows.Forms.Application.DoEvents();
                }

                worksheet.Columns.EntireColumn.AutoFit();//列宽自适应  
                //if (Microsoft.Office.Interop.cmbxType.Text != "Notification")  
                //{  
                //    Excel.Range rg = worksheet.get_Range(worksheet.Cells[2, 2], worksheet.Cells[ds.Tables[0].Rows.Count + 1, 2]);  
                //    rg.NumberFormat = "00000000";  
                //}  

                if (saveFileName != "")
                {
                    try
                    {
                        workbook.Saved = true;
                        workbook.SaveCopyAs(saveFileName);
                        //fileSaved = true;  
                    }
                    catch (Exception ex)
                    {
                        //fileSaved = false;  
                        MessageBox.Show("导出文件出错,文件可能正被打开！\n" + ex.Message, "警告", MessageBoxButtons.OK);
                    }

                }
                //else  
                //{  
                //    fileSaved = false;  
                //}  
                xlApp.Quit();
                GC.Collect();//强行销毁   
                // if (fileSaved && System.IO.File.Exists(saveFileName)) System.Diagnostics.Process.Start(saveFileName); //打开EXCEL  
                MessageBox.Show(fileName + " 保存成功", "提示", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("报表为空,无表格需要导出", "提示", MessageBoxButtons.OK);
            }
        }

        /// <summary>
        /// 导出DataGridView 到excel文件
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="myDGV"></param>
        public void ExportExcel(string fileName, DataGridView myDGV)
        {
            if (myDGV.Rows.Count > 0)
            {
                string saveFileName = "";
                //bool fileSaved = false;  
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.DefaultExt = "xlsx";
                saveDialog.Filter = "Excel 2007文件|*.xlsx|Excel 99-03文件|*.xls";
                saveDialog.FileName = fileName;
                if (saveDialog.ShowDialog() == DialogResult.Cancel)
                    return;

                //被点了取消  
                if (saveDialog.FileName.IndexOf(":") < 0)
                    return; 
                
                saveFileName = saveDialog.FileName;
                if (saveFileName.IndexOf(":") < 0) return; //被点了取消   
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (xlApp == null)
                {
                    MessageBox.Show("无法创建Excel对象，可能该设备未安装Excel","警告",MessageBoxButtons.OK);
                    return;
                }

                Microsoft.Office.Interop.Excel.Workbooks workbooks = xlApp.Workbooks;
                Microsoft.Office.Interop.Excel.Workbook workbook = workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];//取得sheet1  

                //写入标题  
                for (int i = 0; i < myDGV.ColumnCount; i++)
                {
                    worksheet.Cells[1, i + 1] = myDGV.Columns[i].HeaderText;
                }
                //写入数值  
                for (int r = 0; r < myDGV.Rows.Count; r++)
                {
                    for (int i = 0; i < myDGV.ColumnCount; i++)
                    {
                        worksheet.Cells[r + 2, i + 1] = myDGV.Rows[r].Cells[i].Value;
                    }
                    System.Windows.Forms.Application.DoEvents();
                }
                worksheet.Columns.EntireColumn.AutoFit();//列宽自适应  
                //if (Microsoft.Office.Interop.cmbxType.Text != "Notification")  
                //{  
                //    Excel.Range rg = worksheet.get_Range(worksheet.Cells[2, 2], worksheet.Cells[ds.Tables[0].Rows.Count + 1, 2]);  
                //    rg.NumberFormat = "00000000";  
                //}  

                if (saveFileName != "")
                {
                    try
                    {
                        workbook.Saved = true;
                        workbook.SaveCopyAs(saveFileName);
                        //fileSaved = true;  
                    }
                    catch (Exception ex)
                    {
                        //fileSaved = false;  
                        MessageBox.Show("导出文件出错,文件可能正被打开！\n" + ex.Message,"警告",MessageBoxButtons.OK);
                    }

                }
                //else  
                //{  
                //    fileSaved = false;  
                //}  
                xlApp.Quit();
                GC.Collect();//强行销毁   
                // if (fileSaved && System.IO.File.Exists(saveFileName)) System.Diagnostics.Process.Start(saveFileName); //打开EXCEL  
                MessageBox.Show(fileName + " 保存成功", "提示", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("报表为空,无表格需要导出", "提示", MessageBoxButtons.OK);
            }
        }


        public void ExportRichTextBoxToWord(string fileName, RichTextBox richTextBox1)
        {
            //保存为WORD文件
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("文本为空,无数据需要保存", "提示", MessageBoxButtons.OK);
                return;
            }

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            string FileName = saveFileDialog1.FileName;
            if (FileName.Length < 1)
                return;
            FileName += ".doc";
            try
            {
                Word.ApplicationClass MyWord = new Word.ApplicationClass();
                Word.Document MyDoc;
                Object Nothing = System.Reflection.Missing.Value;
                MyDoc = MyWord.Documents.Add(ref Nothing, ref Nothing, ref Nothing, ref Nothing);
                MyDoc.Paragraphs.Last.Range.Text = richTextBox1.Text;
                object MyFileName = FileName;
                //将WordDoc文档对象的内容保存为DOC文档
                //                MyDoc.SaveAs(ref MyFileName,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing,ref Nothing); 
                //关闭WordDoc文档对象 
                MyDoc.Close(ref Nothing, ref Nothing, ref Nothing);
                //关闭WordApp组件对象 
                MyWord.Quit(ref Nothing, ref Nothing, ref Nothing);
                MessageBox.Show("WORD文件保存成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception Err)
            {
                MessageBox.Show("WORD文件保存操作失败！" + Err.Message, "警告", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
