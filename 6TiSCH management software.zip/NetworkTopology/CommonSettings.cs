﻿// A Force-Directed Diagram Layout Algorithm
// Bradley Smith - 2010/07/01

using System;
using System.Collections.Generic;
using System.Drawing;
//using ForceDirected;

/// <summary>
/// Represents a simple diagram consisting of nodes and connections, implementing a 
/// force-directed algorithm for automatically arranging the nodes.
/// </summary>
public class CommonSettings
{
        //private const double ATTRACTION_CONSTANT = 0.1;		// spring constant
        //private const double REPULSION_CONSTANT = 10000;	// charge constant

        //private const double DEFAULT_DAMPING = 0.5;
        //private const int DEFAULT_SPRING_LENGTH = 100;
        //private const int DEFAULT_MAX_ITERATIONS = 1000;

        
}
