﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ForceDirected
{
    public struct ScreenInfo
    {
        public int screenMinWidth;                   //每个显示区最小宽度
        public int screenMinHeight;                  //每个显示区最小高度

        public bool screenSingleColumn;         //显示区是否以单列形式显示

        public double screenYUp;                     //Y轴上限坐标
        public double screenYDown;                //Y轴下限坐标
        public double screenXLeftFull;             //X轴全程左坐标
        public double screenXRightFull;          //X轴全程右坐标
        public double screenXLeftShow;           //X轴显示左坐标
        public double screenXRightShow;           //X轴显示右坐标

        public bool bApplRangelAll;                  //是否应用至每个区域块

        public int leftRemain;                            //左侧预留空白
        public int rightRemain;                          //右侧预留空白
        public int upRemain;                             //上侧预留空白
        public int downRemain;                        //下侧预留空白

        public bool bApplRemainAll;                //是否应用至每个区域块

        public bool screenXLog;                        //X轴是否以对数形式显示
        public bool screenYLog;                        //Y轴是否以对数形式显示

        public int xMinPix;                             //x轴坐标标注最小间隔
        public int yMinPix;                              //y轴坐标标注最小间隔

        public Color[] drwClr;                         //绘制颜色信息

        public int lineStyle;                          //0:线条  1:离散圆  2：离散方形
        public float[] drwWth;                         //线宽
    }

    public struct ScreenSettingInfo
    {
        public bool beLegend;                   //是否绘制图例
        public bool beNodeName;                  //是否显示节点的名称
        public bool beNodeConnectorName;     //是否显示两节点间连线的名称
    }


    public partial class FrmScreenProp : Form
    {
        public ScreenInfo si;
        public FrmScreenProp()
        {
            InitializeComponent();
            this.si.drwClr = new Color[7];
            this.si.drwWth = new float[4];
        }
        public FrmScreenProp(ScreenInfo si)
            :this()
        {
            this.si.drwClr = new Color[7];
            this.si.drwWth = new float[4];
            this.si = si;
           // InitializeComponent();
        }

        private void FrmScreenProp_Load(object sender, EventArgs e)
        {
            txtXLeftFull.Text = si.screenXLeftFull.ToString();
            txtXLeftShow.Text = si.screenXLeftShow.ToString();
            txtXRightFull.Text = si.screenXRightFull.ToString();
            txtXRightShow.Text = si.screenXRightShow.ToString();
            txtYUp.Text = si.screenYUp.ToString();
            txtYDown.Text = si.screenYDown.ToString();
            txtMinWidth.Text = si.screenMinWidth.ToString();
            txtMinHeight.Text = si.screenMinHeight.ToString();
            txtXMinPix.Text = si.xMinPix.ToString();
            txtYMinPix.Text = si.yMinPix.ToString();
            chkXLog.Checked = si.screenXLog;
            chkYLog.Checked = si.screenYLog;
            radioBtSingle.Checked = si.screenSingleColumn;

            txtLeftRemain.Text = si.leftRemain.ToString();
            txtRightReamin.Text = si.rightRemain.ToString();
            txtUpReamin.Text = si.upRemain.ToString();
            txtDowntReamin.Text = si.downRemain.ToString();
            cmbLineStyle.SelectedIndex = si.lineStyle;
            picClrRect.BackColor = si.drwClr[0];
            picClrGrid.BackColor = si.drwClr[1];
            picClrShape.BackColor = si.drwClr[2];
            picClrCursor.BackColor = si.drwClr[3];
            picClrInfo.BackColor = si.drwClr[4];
            picClrSlcArea.BackColor = si.drwClr[5];
            picClrBckgrd.BackColor = si.drwClr[6];

            txtWidthRect.Text = si.drwWth[0].ToString();
            txtWidthGrid.Text = si.drwWth[1].ToString();
            txtWidthShape.Text = si.drwWth[2].ToString();
            txtWidthCursor.Text = si.drwWth[3].ToString();

            chkRangeAll.Checked=si.bApplRangelAll ;
             chkRemainAll.Checked=si.bApplRemainAll;
        }

        private void btOk_Click(object sender, EventArgs e)
        {
            si.screenXLeftFull = double.Parse(txtXLeftFull.Text);
            si.screenXLeftShow = double.Parse(txtXLeftShow.Text);
            si.screenXRightFull = double.Parse(txtXRightFull.Text);
            si.screenXRightShow = double.Parse(txtXRightShow.Text);
            si.screenYUp = double.Parse(txtYUp.Text);
            si.screenYDown = double.Parse(txtYDown.Text);
            si.screenXLog = chkXLog.Checked;
            si.screenYLog = chkYLog.Checked;
            si.screenSingleColumn = radioBtSingle.Checked;
            si.screenMinWidth = int.Parse(txtMinWidth.Text);
            si.screenMinHeight = int.Parse(txtMinHeight.Text);
            si.xMinPix = int.Parse(txtXMinPix.Text);
            si.yMinPix = int.Parse(txtYMinPix.Text);
            si.leftRemain = int.Parse(txtLeftRemain.Text);
            si.rightRemain = int.Parse(txtRightReamin.Text);
            si.upRemain = int.Parse(txtUpReamin.Text);
            si.downRemain = int.Parse(txtDowntReamin.Text);
            si.bApplRangelAll = chkRangeAll.Checked;
            si.bApplRemainAll = chkRemainAll.Checked;
            si.lineStyle = cmbLineStyle.SelectedIndex;
            si.drwClr[0]= picClrRect.BackColor ;
            si.drwClr[1] = picClrGrid.BackColor;
            si.drwClr[2]  = picClrShape.BackColor;
            si.drwClr[3] = picClrCursor.BackColor ;
            si.drwClr[4]  = picClrInfo.BackColor;
            si.drwClr[5] = picClrSlcArea.BackColor ;
            si.drwClr[6]  =picClrBckgrd.BackColor ;

            si.drwWth[0] = Int32.Parse(txtWidthRect.Text.Trim());
            si.drwWth[1] = Int32.Parse(txtWidthGrid.Text.Trim());
            si.drwWth[2] = Int32.Parse(txtWidthShape.Text.Trim());
            si.drwWth[3] = Int32.Parse(txtWidthCursor.Text.Trim());

        }

        private void picClrRect_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrRect.BackColor= clg.Color;
        }

        private void picClrGrid_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrGrid.BackColor = clg.Color;
        }

        private void picClrShape_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrShape.BackColor = clg.Color;
        }

        private void picClrCursor_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrCursor.BackColor = clg.Color;
        }

        private void picClrInfo_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrInfo.BackColor = clg.Color;
        }

        private void picClrSlcArea_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrSlcArea.BackColor = clg.Color;
        }

        private void picClrBckgrd_Click(object sender, EventArgs e)
        {
            ColorDialog clg = new ColorDialog();
            if (clg.ShowDialog() == DialogResult.OK)
                picClrBckgrd.BackColor = clg.Color;
        }
    }
}