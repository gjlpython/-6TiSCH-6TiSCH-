﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NetworkTopology
{
    public partial class CellEditForm : Form
    {
        private int moveCurPosX;
        private int moveCurPosY;

        public string editText = "";

        public CellEditForm()
        {
            InitializeComponent();
        }

        private void CellEditForm_Load(object sender, EventArgs e)
        {
            //textBox1.Left = panel1.Left;
            //textBox1.Top = panel1.Top;
            //textBox1.Width = panel1.Width;

            ////button1.Parent = panel1;
            ////button2.Parent = panel1;


            //textBox_Edit.Text = editText;
            richTextBoxPrintCtrl_Edit.Text = editText;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //editText = textBox_Edit.Text;
            editText = richTextBoxPrintCtrl_Edit.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void CellEditForm_SizeChanged(object sender, EventArgs e)
        {
            panel1.Top = this.ClientRectangle.Top;
            panel1.Left = this.ClientRectangle.Left;
            panel1.Width = this.ClientRectangle.Width;

            richTextBoxPrintCtrl_Edit.Left = panel1.Left;
            richTextBoxPrintCtrl_Edit.Top = panel1.Bottom;
            richTextBoxPrintCtrl_Edit.Width = panel1.Width;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + (e.X - moveCurPosX), this.Location.Y + (e.Y - moveCurPosY));
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                moveCurPosX = e.X;
                moveCurPosY = e.Y;
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
