﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace NetworkTopology
{

    public partial class FormNew : Form
    {
        int x, y;
        TCPOper oper;
        public DataLinkInfo linkSet;
        public bool connectedRst;

        //const int WM_NCHITTEST = 0x0084;
        //const int HTLEFT = 10;
        //const int HTRIGHT = 11;
        //const int HTTOP = 12;
        //const int HTTOPLEFT = 13;
        //const int HTTOPRIGHT = 14;
        //const int HTBOTTOM = 15;
        //const int HTBOTTOMLEFT = 0x10;
        //const int HTBOTTOMRIGHT = 17;
        //protected override void WndProc(ref Message m)
        //{
        //    base.WndProc(ref m);
        //    switch (m.Msg)
        //    {
        //        case WM_NCHITTEST:
        //            Point vPoint = new Point((int)m.LParam & 0xFFFF,
        //                (int)m.LParam >> 16 & 0xFFFF);
        //            vPoint = PointToClient(vPoint);
        //            if (vPoint.X <= 5)
        //                if (vPoint.Y <= 5)
        //                    m.Result = (IntPtr)HTTOPLEFT;
        //                else if (vPoint.Y >= ClientSize.Height - 5)
        //                    m.Result = (IntPtr)HTBOTTOMLEFT;
        //                else m.Result = (IntPtr)HTLEFT;
        //            else if (vPoint.X >= ClientSize.Width - 5)
        //                if (vPoint.Y <= 5)
        //                    m.Result = (IntPtr)HTTOPRIGHT;
        //                else if (vPoint.Y >= ClientSize.Height - 5)
        //                    m.Result = (IntPtr)HTBOTTOMRIGHT;
        //                else m.Result = (IntPtr)HTRIGHT;
        //            else if (vPoint.Y <= 5)
        //                m.Result = (IntPtr)HTTOP;
        //            else if (vPoint.Y >= ClientSize.Height - 5)
        //                m.Result = (IntPtr)HTBOTTOM;
        //            break;
        //    }
        //}

        public FormNew()
        {
            InitializeComponent();

            oper = new TCPOper();
        }

        private void FormNew_Load(object sender, EventArgs e)
        {
            //foreach (Control control in this.Controls)//遍历本窗体中所有的ComboBox控件
            //{
            //    if (control.GetType().ToString() == "System.Windows.Forms.GroupBox")
            //    {
            //        (control as GroupBox).Parent = panel1;
            //        (control as GroupBox).BackColor = Color.Transparent;
            //    }
            //}
            if (!Socket.OSSupportsIPv6) MessageBox.Show("系统不支持IPv6地址或IPv6地址未启用！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            for (int i = 0; i < Dns.GetHostEntry(Dns.GetHostName()).AddressList.Length; i++)//获取主机的IP地址列表及列表长度
            {
                if (Dns.GetHostEntry(Dns.GetHostName()).AddressList[i].ToString().Contains(":"))//如果":"存在于IP地址列表的标准表示中（详见IPV6的标准语法）
                {
                    this.cmbServerName.Items.Add(Dns.GetHostEntry(Dns.GetHostName()).AddressList[i].ToString());//将地址列表标准表示法添加到comboBox1的集合
                }
            }
            cmbServerName.SelectedIndex = 0;//comboBox1的索引为0

            //cmbLocalName.SelectedIndex = 0;
            ////cmbServerName.SelectedIndex = 0;
            //cmbSDNName.SelectedIndex = 0;
        }

        private void cmbAuthentication_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public delegate bool MethodCaller(DataLinkInfo linkSetInput);//定义个代理

        private void btOk_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            //linkSet.LocalName = cmbLocalName.Text.Trim();
            //linkSet.LocalPort = cmbLocalPort.Text.Trim();
            linkSet.ServerName = cmbServerName.Text.Trim();
            linkSet.ServerPort = cmbServerPort.Text.Trim();
            //linkSet.SDNIPName = cmbSDNName.Text.Trim();
            //linkSet.SDNPort = cmbSDNPort.Text.Trim();

            // 方案1 
            //if (!oper.CheckConnectionEffectiveness(linkSet))
            //{
            //    MessageBox.Show("连接设置无效，操作前请重新输入!","警告",MessageBoxButtons.OK);
            //    Cursor = Cursors.Default;
            //    return;
            //}

            // 方案2 
            //MethodCaller mc = new MethodCaller(oper.CheckConnectionEffectiveness);
            //DataLinkInfo linkSetInput = linkSet;//输入参数
            //IAsyncResult result = mc.BeginInvoke(linkSet, null, null);
            //connectedRst = mc.EndInvoke(result);//用于接收返回值
            //if (!connectedRst)
            //{
            //    MessageBox.Show("连接设置无效，操作前请重新输入!", "警告", MessageBoxButtons.OK);
            //    Cursor = Cursors.Default;
            //    return;
            //}

            // 方案3
            //ThreadStart threadStart = new ThreadStart(CheckConnectionEffectiveness);
            //Thread bg_Connect = new Thread(threadStart);
            //bg_Connect.IsBackground = true;
            //bg_Connect.Start();
            //bg_Connect.Join();
            //bg_Connect.Abort();

            // 不进行连接，只传递IP和端口号进去
            connectedRst = true;
            if (!connectedRst)
            {
                MessageBox.Show("连接设置无效，操作前请重新输入!", "警告", MessageBoxButtons.OK);
                Cursor = Cursors.Default;
                return;
            }

            this.DialogResult = DialogResult.OK;
            Cursor = Cursors.Default;
        }


        public void CheckConnectionEffectiveness()
        {

            connectedRst = false;
            System.Net.IPAddress ip = System.Net.IPAddress.Parse(linkSet.ServerName); // 服务器地址 
            int port = int.Parse(linkSet.ServerPort); // 服务器端口号

            try
            {
                TcpClient NetworkClient = TimeOutSocket.Connect(new IPEndPoint(ip, port), TimeOutSocket.TcpClientConnectTimeout); // 连接服务器
                if (NetworkClient != null)
                {
                    connectedRst = NetworkClient.Connected;
                    NetworkClient.Close();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message); // 输出发生错误的信息
                connectedRst = false;
            }
        }


        private void btCancle_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
        }

        private void FormNew_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                x = e.X;
                y = e.Y;
            }
        }

        private void FormNew_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + (e.X - x), this.Location.Y + (e.Y - y));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;//最小化
        }
    }
}
