﻿namespace ForceDirected {
	partial class Demo {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Demo));
            this.LiDaoXiang = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randomTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.力导向ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.realTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.routerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listBox_RecMsg = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSM_Luyoubiao = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Chaozhenbiao = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Lianlubiao = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Jiaohuanjiliubiao = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.统计信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打印拓扑图ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.显示设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图例ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NodeNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ConnectorNameToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.默认设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView_Material = new System.Windows.Forms.DataGridView();
            this.Column_Node = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_gridviewPrint = new System.Windows.Forms.Button();
            this.btn_gridviewSave = new System.Windows.Forms.Button();
            this.pictureBox_ListHeader = new System.Windows.Forms.PictureBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button11 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.richTextBoxPrintCtrl_Receive = new RichTextBoxPrintCtrl.RichTextBoxPrintCtrl();
            this.toolStrip_cmd = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.获取panidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取WIAPA拓扑信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取回程网络拓扑信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取WIAPA设备路由表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置WIAPA设备路由表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取WIAPA设备超帧表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置WIAPA设备超帧表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取WIAPA设备链路表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置WIAPA设备链路表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取交换机流表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.增加交换机流表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除交换机流表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.联合调度ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.richTextBoxPrintCtrl_Send = new RichTextBoxPrintCtrl.RichTextBoxPrintCtrl();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dst_comboBox = new System.Windows.Forms.ComboBox();
            this.src_comboBox = new System.Windows.Forms.ComboBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer_LineAnimate = new System.Windows.Forms.Timer(this.components);
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine();
            this.checkBox_CMD = new System.Windows.Forms.CheckBox();
            this.panel_Caidan = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button_Seprator = new System.Windows.Forms.Button();
            this.btn_Gengxin = new System.Windows.Forms.Button();
            this.btn_Pailie = new System.Windows.Forms.Button();
            this.btn_Tongji = new System.Windows.Forms.Button();
            this.btn_Youhua = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btn_Diaodu = new System.Windows.Forms.Button();
            this.printDocument_Prev = new System.Drawing.Printing.PrintDocument();
            this.printDocument_DataGridview = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument_RichTextBox = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.btn_Max = new System.Windows.Forms.Button();
            this.btn_file = new System.Windows.Forms.Button();
            this.btn_Min = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.LinkInfoLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button1 = new System.Windows.Forms.Button();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.清空ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox_NodeInfo = new System.Windows.Forms.ComboBox();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Material)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ListHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip_cmd.SuspendLayout();
            this.panel_Caidan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // LiDaoXiang
            // 
            this.LiDaoXiang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.LiDaoXiang.Location = new System.Drawing.Point(691, 168);
            this.LiDaoXiang.Name = "LiDaoXiang";
            this.LiDaoXiang.Size = new System.Drawing.Size(75, 23);
            this.LiDaoXiang.TabIndex = 0;
            this.LiDaoXiang.Text = "力导向";
            this.LiDaoXiang.UseVisualStyleBackColor = true;
            this.LiDaoXiang.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.Window;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 80);
            this.splitContainer1.MinimumSize = new System.Drawing.Size(400, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1MinSize = 24;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.AliceBlue;
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Panel2MinSize = 0;
            this.splitContainer1.Size = new System.Drawing.Size(859, 384);
            this.splitContainer1.SplitterDistance = 680;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer4);
            this.splitContainer2.Panel1.Controls.Add(this.LiDaoXiang);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.Color.AliceBlue;
            this.splitContainer2.Panel2.Controls.Add(this.dataGridView_Material);
            this.splitContainer2.Panel2.Controls.Add(this.btn_gridviewPrint);
            this.splitContainer2.Panel2.Controls.Add(this.btn_gridviewSave);
            this.splitContainer2.Panel2.Controls.Add(this.pictureBox_ListHeader);
            this.splitContainer2.Panel2.SizeChanged += new System.EventHandler(this.splitContainer2_Panel2_SizeChanged);
            this.splitContainer2.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer2_Panel2_Paint);
            this.splitContainer2.Size = new System.Drawing.Size(680, 384);
            this.splitContainer2.SplitterDistance = 218;
            this.splitContainer2.SplitterWidth = 3;
            this.splitContainer2.TabIndex = 6;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.menuStrip1);
            this.splitContainer4.Panel1.Controls.Add(this.pictureBox1);
            this.splitContainer4.Panel1MinSize = 0;
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.listBox_RecMsg);
            this.splitContainer4.Panel2MinSize = 0;
            this.splitContainer4.Size = new System.Drawing.Size(680, 218);
            this.splitContainer4.SplitterDistance = 343;
            this.splitContainer4.SplitterWidth = 1;
            this.splitContainer4.TabIndex = 19;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 4);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(60, 32);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.randomTestToolStripMenuItem,
            this.力导向ToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.saveToFileToolStripMenuItem,
            this.testToolStripMenuItem1,
            this.realTestToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(52, 28);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // randomTestToolStripMenuItem
            // 
            this.randomTestToolStripMenuItem.Name = "randomTestToolStripMenuItem";
            this.randomTestToolStripMenuItem.Size = new System.Drawing.Size(220, 28);
            this.randomTestToolStripMenuItem.Text = "数据生成+力导向";
            this.randomTestToolStripMenuItem.Visible = false;
            // 
            // 力导向ToolStripMenuItem
            // 
            this.力导向ToolStripMenuItem.Name = "力导向ToolStripMenuItem";
            this.力导向ToolStripMenuItem.Size = new System.Drawing.Size(220, 28);
            this.力导向ToolStripMenuItem.Text = "力导向";
            this.力导向ToolStripMenuItem.Visible = false;
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(220, 28);
            this.loadToolStripMenuItem.Text = "Load from File ...";
            this.loadToolStripMenuItem.Visible = false;
            // 
            // saveToFileToolStripMenuItem
            // 
            this.saveToFileToolStripMenuItem.Name = "saveToFileToolStripMenuItem";
            this.saveToFileToolStripMenuItem.Size = new System.Drawing.Size(220, 28);
            this.saveToFileToolStripMenuItem.Text = "Save to File ...";
            this.saveToFileToolStripMenuItem.Visible = false;
            // 
            // testToolStripMenuItem1
            // 
            this.testToolStripMenuItem1.Name = "testToolStripMenuItem1";
            this.testToolStripMenuItem1.Size = new System.Drawing.Size(220, 28);
            this.testToolStripMenuItem1.Text = "Simulation";
            // 
            // realTestToolStripMenuItem
            // 
            this.realTestToolStripMenuItem.Name = "realTestToolStripMenuItem";
            this.realTestToolStripMenuItem.Size = new System.Drawing.Size(220, 28);
            this.realTestToolStripMenuItem.Text = "RealTest";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(217, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(220, 28);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(56, 28);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Visible = false;
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.emitterToolStripMenuItem,
            this.receiverToolStripMenuItem,
            this.linkToolStripMenuItem,
            this.routerToolStripMenuItem,
            this.testToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(117, 28);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // emitterToolStripMenuItem
            // 
            this.emitterToolStripMenuItem.Name = "emitterToolStripMenuItem";
            this.emitterToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.emitterToolStripMenuItem.Text = "Emitter";
            // 
            // receiverToolStripMenuItem
            // 
            this.receiverToolStripMenuItem.Name = "receiverToolStripMenuItem";
            this.receiverToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.receiverToolStripMenuItem.Text = "Receiver";
            // 
            // linkToolStripMenuItem
            // 
            this.linkToolStripMenuItem.Name = "linkToolStripMenuItem";
            this.linkToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.linkToolStripMenuItem.Text = "Link";
            // 
            // routerToolStripMenuItem
            // 
            this.routerToolStripMenuItem.Name = "routerToolStripMenuItem";
            this.routerToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.routerToolStripMenuItem.Text = "Router";
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.testToolStripMenuItem.Text = "Test";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.AliceBlue;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(343, 218);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint_1);
            this.pictureBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDoubleClick);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            this.pictureBox1.Resize += new System.EventHandler(this.pictureBox1_Resize);
            // 
            // listBox_RecMsg
            // 
            this.listBox_RecMsg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox_RecMsg.ContextMenuStrip = this.contextMenuStrip1;
            this.listBox_RecMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox_RecMsg.FormattingEnabled = true;
            this.listBox_RecMsg.ItemHeight = 25;
            this.listBox_RecMsg.Location = new System.Drawing.Point(0, 0);
            this.listBox_RecMsg.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listBox_RecMsg.Name = "listBox_RecMsg";
            this.listBox_RecMsg.Size = new System.Drawing.Size(336, 218);
            this.listBox_RecMsg.TabIndex = 32;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSM_Luyoubiao,
            this.TSM_Chaozhenbiao,
            this.TSM_Lianlubiao,
            this.TSM_Jiaohuanjiliubiao,
            this.toolStripSeparator2,
            this.统计信息ToolStripMenuItem,
            this.打印拓扑图ToolStripMenuItem,
            this.显示设置ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(207, 206);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // TSM_Luyoubiao
            // 
            this.TSM_Luyoubiao.Name = "TSM_Luyoubiao";
            this.TSM_Luyoubiao.Size = new System.Drawing.Size(206, 28);
            this.TSM_Luyoubiao.Text = "路由表获取";
            this.TSM_Luyoubiao.Visible = false;
            this.TSM_Luyoubiao.Click += new System.EventHandler(this.TSM_Luyoubiao_Click);
            // 
            // TSM_Chaozhenbiao
            // 
            this.TSM_Chaozhenbiao.Name = "TSM_Chaozhenbiao";
            this.TSM_Chaozhenbiao.Size = new System.Drawing.Size(206, 28);
            this.TSM_Chaozhenbiao.Text = "超帧表获取";
            this.TSM_Chaozhenbiao.Visible = false;
            this.TSM_Chaozhenbiao.Click += new System.EventHandler(this.TSM_Chaozhenbiao_Click);
            // 
            // TSM_Lianlubiao
            // 
            this.TSM_Lianlubiao.Name = "TSM_Lianlubiao";
            this.TSM_Lianlubiao.Size = new System.Drawing.Size(206, 28);
            this.TSM_Lianlubiao.Text = "链路表获取";
            this.TSM_Lianlubiao.Visible = false;
            this.TSM_Lianlubiao.Click += new System.EventHandler(this.TSM_Lianlubiao_Click);
            // 
            // TSM_Jiaohuanjiliubiao
            // 
            this.TSM_Jiaohuanjiliubiao.Name = "TSM_Jiaohuanjiliubiao";
            this.TSM_Jiaohuanjiliubiao.Size = new System.Drawing.Size(206, 28);
            this.TSM_Jiaohuanjiliubiao.Text = "交换机流表获取";
            this.TSM_Jiaohuanjiliubiao.Visible = false;
            this.TSM_Jiaohuanjiliubiao.Click += new System.EventHandler(this.TSM_Jiaohuanjiliubiao_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(203, 6);
            // 
            // 统计信息ToolStripMenuItem
            // 
            this.统计信息ToolStripMenuItem.Image = global::NetworkTopology.Properties.Resources.统计信息;
            this.统计信息ToolStripMenuItem.Name = "统计信息ToolStripMenuItem";
            this.统计信息ToolStripMenuItem.Size = new System.Drawing.Size(206, 28);
            this.统计信息ToolStripMenuItem.Text = "统计信息";
            this.统计信息ToolStripMenuItem.Click += new System.EventHandler(this.统计信息ToolStripMenuItem_Click);
            // 
            // 打印拓扑图ToolStripMenuItem
            // 
            this.打印拓扑图ToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.打印拓扑图ToolStripMenuItem.Image = global::NetworkTopology.Properties.Resources._20090903223051234;
            this.打印拓扑图ToolStripMenuItem.Name = "打印拓扑图ToolStripMenuItem";
            this.打印拓扑图ToolStripMenuItem.Size = new System.Drawing.Size(206, 28);
            this.打印拓扑图ToolStripMenuItem.Text = "保存拓扑图";
            this.打印拓扑图ToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.打印拓扑图ToolStripMenuItem.Click += new System.EventHandler(this.打印拓扑图ToolStripMenuItem_Click);
            // 
            // 显示设置ToolStripMenuItem
            // 
            this.显示设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.图例ToolStripMenuItem,
            this.NodeNameToolStripMenuItem,
            this.ConnectorNameToolStripMenuItem1,
            this.默认设置ToolStripMenuItem});
            this.显示设置ToolStripMenuItem.Name = "显示设置ToolStripMenuItem";
            this.显示设置ToolStripMenuItem.Size = new System.Drawing.Size(206, 28);
            this.显示设置ToolStripMenuItem.Text = "显示设置";
            this.显示设置ToolStripMenuItem.Click += new System.EventHandler(this.显示设置ToolStripMenuItem_Click);
            // 
            // 图例ToolStripMenuItem
            // 
            this.图例ToolStripMenuItem.Name = "图例ToolStripMenuItem";
            this.图例ToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.图例ToolStripMenuItem.Text = "图例";
            this.图例ToolStripMenuItem.Click += new System.EventHandler(this.图例ToolStripMenuItem_Click);
            // 
            // NodeNameToolStripMenuItem
            // 
            this.NodeNameToolStripMenuItem.Name = "NodeNameToolStripMenuItem";
            this.NodeNameToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.NodeNameToolStripMenuItem.Text = "节点名称";
            this.NodeNameToolStripMenuItem.Click += new System.EventHandler(this.连线ToolStripMenuItem_Click);
            // 
            // ConnectorNameToolStripMenuItem1
            // 
            this.ConnectorNameToolStripMenuItem1.Name = "ConnectorNameToolStripMenuItem1";
            this.ConnectorNameToolStripMenuItem1.Size = new System.Drawing.Size(152, 28);
            this.ConnectorNameToolStripMenuItem1.Text = "连线名称";
            this.ConnectorNameToolStripMenuItem1.Click += new System.EventHandler(this.ConnectorNameToolStripMenuItem1_Click);
            // 
            // 默认设置ToolStripMenuItem
            // 
            this.默认设置ToolStripMenuItem.Name = "默认设置ToolStripMenuItem";
            this.默认设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.默认设置ToolStripMenuItem.Text = "默认设置";
            this.默认设置ToolStripMenuItem.Click += new System.EventHandler(this.默认设置ToolStripMenuItem_Click);
            // 
            // dataGridView_Material
            // 
            this.dataGridView_Material.AllowUserToAddRows = false;
            this.dataGridView_Material.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridView_Material.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Material.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Material.BackgroundColor = System.Drawing.Color.DeepSkyBlue;
            this.dataGridView_Material.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView_Material.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Material.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column_Node});
            this.dataGridView_Material.Location = new System.Drawing.Point(27, 39);
            this.dataGridView_Material.MultiSelect = false;
            this.dataGridView_Material.Name = "dataGridView_Material";
            this.dataGridView_Material.RowHeadersVisible = false;
            this.dataGridView_Material.RowTemplate.Height = 23;
            this.dataGridView_Material.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Material.Size = new System.Drawing.Size(467, 104);
            this.dataGridView_Material.TabIndex = 36;
            this.dataGridView_Material.VirtualMode = true;
            this.dataGridView_Material.Visible = false;
            // 
            // Column_Node
            // 
            this.Column_Node.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column_Node.Frozen = true;
            this.Column_Node.Name = "Column_Node";
            this.Column_Node.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column_Node.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column_Node.Visible = false;
            this.Column_Node.Width = 40;
            // 
            // btn_gridviewPrint
            // 
            this.btn_gridviewPrint.BackgroundImage = global::NetworkTopology.Properties.Resources.print;
            this.btn_gridviewPrint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_gridviewPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_gridviewPrint.ForeColor = System.Drawing.Color.White;
            this.btn_gridviewPrint.Location = new System.Drawing.Point(615, 3);
            this.btn_gridviewPrint.Name = "btn_gridviewPrint";
            this.btn_gridviewPrint.Size = new System.Drawing.Size(22, 22);
            this.btn_gridviewPrint.TabIndex = 5;
            this.btn_gridviewPrint.Text = "打印";
            this.btn_gridviewPrint.UseVisualStyleBackColor = true;
            this.btn_gridviewPrint.Click += new System.EventHandler(this.btn_gridviewPrint_Click);
            // 
            // btn_gridviewSave
            // 
            this.btn_gridviewSave.BackgroundImage = global::NetworkTopology.Properties.Resources.save;
            this.btn_gridviewSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_gridviewSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_gridviewSave.ForeColor = System.Drawing.Color.White;
            this.btn_gridviewSave.Location = new System.Drawing.Point(593, 3);
            this.btn_gridviewSave.Name = "btn_gridviewSave";
            this.btn_gridviewSave.Size = new System.Drawing.Size(22, 22);
            this.btn_gridviewSave.TabIndex = 4;
            this.btn_gridviewSave.Text = "保存";
            this.btn_gridviewSave.UseVisualStyleBackColor = true;
            this.btn_gridviewSave.Click += new System.EventHandler(this.btn_gridviewSave_Click);
            // 
            // pictureBox_ListHeader
            // 
            this.pictureBox_ListHeader.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox_ListHeader.Location = new System.Drawing.Point(27, 3);
            this.pictureBox_ListHeader.Name = "pictureBox_ListHeader";
            this.pictureBox_ListHeader.Size = new System.Drawing.Size(610, 22);
            this.pictureBox_ListHeader.TabIndex = 3;
            this.pictureBox_ListHeader.TabStop = false;
            this.pictureBox_ListHeader.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_ListHeader_Paint);
            // 
            // splitContainer3
            // 
            this.splitContainer3.BackColor = System.Drawing.SystemColors.Window;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.panel1);
            this.splitContainer3.Panel1.Controls.Add(this.richTextBoxPrintCtrl_Receive);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.toolStrip_cmd);
            this.splitContainer3.Panel2.Controls.Add(this.richTextBoxPrintCtrl_Send);
            this.splitContainer3.Panel2.SizeChanged += new System.EventHandler(this.splitContainer3_Panel2_SizeChanged);
            this.splitContainer3.Size = new System.Drawing.Size(176, 384);
            this.splitContainer3.SplitterDistance = 218;
            this.splitContainer3.SplitterWidth = 3;
            this.splitContainer3.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.textBox21);
            this.panel1.Controls.Add(this.textBox20);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(10, 72);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(713, 132);
            this.panel1.TabIndex = 37;
            this.panel1.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(463, 20);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(112, 33);
            this.comboBox2.TabIndex = 31;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(583, 16);
            this.button11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(118, 103);
            this.button11.TabIndex = 33;
            this.button11.Text = "详情";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(463, 96);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(112, 31);
            this.textBox21.TabIndex = 32;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(463, 58);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(112, 31);
            this.textBox20.TabIndex = 31;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(343, 19);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 32);
            this.button4.TabIndex = 21;
            this.button4.Text = "Sensor3";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(343, 58);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(112, 31);
            this.textBox7.TabIndex = 10;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(343, 96);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(112, 31);
            this.textBox6.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(225, 96);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(112, 31);
            this.textBox5.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(225, 58);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(112, 31);
            this.textBox4.TabIndex = 7;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(225, 19);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 32);
            this.button3.TabIndex = 6;
            this.button3.Text = "Sensor2";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 101);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "湿度";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 62);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "温度";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sensor";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(107, 19);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 32);
            this.button2.TabIndex = 2;
            this.button2.Text = "Sensor1";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(107, 96);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(112, 31);
            this.textBox3.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(107, 58);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(112, 31);
            this.textBox1.TabIndex = 0;
            // 
            // richTextBoxPrintCtrl_Receive
            // 
            this.richTextBoxPrintCtrl_Receive.BackColor = System.Drawing.Color.AliceBlue;
            this.richTextBoxPrintCtrl_Receive.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxPrintCtrl_Receive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxPrintCtrl_Receive.Location = new System.Drawing.Point(0, 0);
            this.richTextBoxPrintCtrl_Receive.Name = "richTextBoxPrintCtrl_Receive";
            this.richTextBoxPrintCtrl_Receive.Size = new System.Drawing.Size(176, 218);
            this.richTextBoxPrintCtrl_Receive.TabIndex = 6;
            this.richTextBoxPrintCtrl_Receive.Text = "";
            this.richTextBoxPrintCtrl_Receive.TextChanged += new System.EventHandler(this.richTextBoxPrintCtrl_Receive_TextChanged);
            // 
            // toolStrip_cmd
            // 
            this.toolStrip_cmd.BackColor = System.Drawing.Color.AliceBlue;
            this.toolStrip_cmd.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip_cmd.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip_cmd.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip_cmd.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton4,
            this.toolStripButton2,
            this.toolStripSeparator3,
            this.toolStripButton3,
            this.toolStripSplitButton1});
            this.toolStrip_cmd.Location = new System.Drawing.Point(10, 127);
            this.toolStrip_cmd.Name = "toolStrip_cmd";
            this.toolStrip_cmd.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip_cmd.Size = new System.Drawing.Size(186, 33);
            this.toolStrip_cmd.TabIndex = 7;
            this.toolStrip_cmd.Text = "toolStrip1";
            this.toolStrip_cmd.Paint += new System.Windows.Forms.PaintEventHandler(this.toolStrip_cmd_Paint);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::NetworkTopology.Properties.Resources._20090903223051234;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(35, 30);
            this.toolStripButton1.Text = "Save";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            this.toolStripButton1.MouseLeave += new System.EventHandler(this.toolStripButton1_MouseLeave);
            this.toolStripButton1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.toolStripButton1_MouseMove);
            this.toolStripButton1.Paint += new System.Windows.Forms.PaintEventHandler(this.toolStripButton1_Paint_1);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.AutoSize = false;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::NetworkTopology.Properties.Resources._130F64013420_15E9;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(35, 30);
            this.toolStripButton4.Text = "Print";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            this.toolStripButton4.MouseLeave += new System.EventHandler(this.toolStripButton1_MouseLeave);
            this.toolStripButton4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.toolStripButton1_MouseMove);
            this.toolStripButton4.Paint += new System.Windows.Forms.PaintEventHandler(this.toolStripButton1_Paint_1);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.AutoSize = false;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::NetworkTopology.Properties.Resources.System_Recycle_Bin_Empty;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(35, 30);
            this.toolStripButton2.Text = "Clear";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            this.toolStripButton2.MouseLeave += new System.EventHandler(this.toolStripButton1_MouseLeave);
            this.toolStripButton2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.toolStripButton1_MouseMove);
            this.toolStripButton2.Paint += new System.Windows.Forms.PaintEventHandler(this.toolStripButton1_Paint_1);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.ForeColor = System.Drawing.Color.Blue;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.AutoSize = false;
            this.toolStripButton3.BackColor = System.Drawing.Color.AliceBlue;
            this.toolStripButton3.Image = global::NetworkTopology.Properties.Resources.Mail_Send;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(60, 30);
            this.toolStripButton3.Text = "发送";
            this.toolStripButton3.Click += new System.EventHandler(this.button1_Click);
            this.toolStripButton3.MouseLeave += new System.EventHandler(this.toolStripButton1_MouseLeave);
            this.toolStripButton3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.toolStripButton1_MouseMove);
            this.toolStripButton3.Paint += new System.Windows.Forms.PaintEventHandler(this.toolStripButton1_Paint_1);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.AutoSize = false;
            this.toolStripSplitButton1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.获取panidToolStripMenuItem,
            this.获取WIAPA拓扑信息ToolStripMenuItem,
            this.获取回程网络拓扑信息ToolStripMenuItem,
            this.获取WIAPA设备路由表ToolStripMenuItem,
            this.设置WIAPA设备路由表ToolStripMenuItem,
            this.获取WIAPA设备超帧表ToolStripMenuItem,
            this.设置WIAPA设备超帧表ToolStripMenuItem,
            this.获取WIAPA设备链路表ToolStripMenuItem,
            this.设置WIAPA设备链路表ToolStripMenuItem,
            this.获取交换机流表ToolStripMenuItem,
            this.增加交换机流表ToolStripMenuItem,
            this.删除交换机流表ToolStripMenuItem,
            this.联合调度ToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(12, 30);
            this.toolStripSplitButton1.Text = " ";
            // 
            // 获取panidToolStripMenuItem
            // 
            this.获取panidToolStripMenuItem.Name = "获取panidToolStripMenuItem";
            this.获取panidToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取panidToolStripMenuItem.Text = "获取panid";
            this.获取panidToolStripMenuItem.Click += new System.EventHandler(this.获取panidToolStripMenuItem_Click);
            // 
            // 获取WIAPA拓扑信息ToolStripMenuItem
            // 
            this.获取WIAPA拓扑信息ToolStripMenuItem.Name = "获取WIAPA拓扑信息ToolStripMenuItem";
            this.获取WIAPA拓扑信息ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取WIAPA拓扑信息ToolStripMenuItem.Text = "获取WIA-PA拓扑";
            this.获取WIAPA拓扑信息ToolStripMenuItem.Click += new System.EventHandler(this.获取WIAPA拓扑信息ToolStripMenuItem_Click);
            // 
            // 获取回程网络拓扑信息ToolStripMenuItem
            // 
            this.获取回程网络拓扑信息ToolStripMenuItem.Name = "获取回程网络拓扑信息ToolStripMenuItem";
            this.获取回程网络拓扑信息ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取回程网络拓扑信息ToolStripMenuItem.Text = "获取回程网络拓扑";
            this.获取回程网络拓扑信息ToolStripMenuItem.Click += new System.EventHandler(this.获取回程网络拓扑信息ToolStripMenuItem_Click);
            // 
            // 获取WIAPA设备路由表ToolStripMenuItem
            // 
            this.获取WIAPA设备路由表ToolStripMenuItem.Name = "获取WIAPA设备路由表ToolStripMenuItem";
            this.获取WIAPA设备路由表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取WIAPA设备路由表ToolStripMenuItem.Text = "获取WIA-PA设备路由表";
            this.获取WIAPA设备路由表ToolStripMenuItem.Click += new System.EventHandler(this.获取WIAPA设备路由表ToolStripMenuItem_Click);
            // 
            // 设置WIAPA设备路由表ToolStripMenuItem
            // 
            this.设置WIAPA设备路由表ToolStripMenuItem.Name = "设置WIAPA设备路由表ToolStripMenuItem";
            this.设置WIAPA设备路由表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.设置WIAPA设备路由表ToolStripMenuItem.Text = "设置WIA-PA设备路由表";
            this.设置WIAPA设备路由表ToolStripMenuItem.Visible = false;
            this.设置WIAPA设备路由表ToolStripMenuItem.Click += new System.EventHandler(this.设置WIAPA设备路由表ToolStripMenuItem_Click);
            // 
            // 获取WIAPA设备超帧表ToolStripMenuItem
            // 
            this.获取WIAPA设备超帧表ToolStripMenuItem.Name = "获取WIAPA设备超帧表ToolStripMenuItem";
            this.获取WIAPA设备超帧表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取WIAPA设备超帧表ToolStripMenuItem.Text = "获取WIA-PA设备超帧表";
            this.获取WIAPA设备超帧表ToolStripMenuItem.Click += new System.EventHandler(this.获取WIAPA设备超帧表ToolStripMenuItem_Click);
            // 
            // 设置WIAPA设备超帧表ToolStripMenuItem
            // 
            this.设置WIAPA设备超帧表ToolStripMenuItem.Name = "设置WIAPA设备超帧表ToolStripMenuItem";
            this.设置WIAPA设备超帧表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.设置WIAPA设备超帧表ToolStripMenuItem.Text = "设置WIA-PA设备超帧表";
            this.设置WIAPA设备超帧表ToolStripMenuItem.Visible = false;
            this.设置WIAPA设备超帧表ToolStripMenuItem.Click += new System.EventHandler(this.设置WIAPA设备超帧表ToolStripMenuItem_Click);
            // 
            // 获取WIAPA设备链路表ToolStripMenuItem
            // 
            this.获取WIAPA设备链路表ToolStripMenuItem.Name = "获取WIAPA设备链路表ToolStripMenuItem";
            this.获取WIAPA设备链路表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取WIAPA设备链路表ToolStripMenuItem.Text = "获取WIA-PA设备链路表";
            this.获取WIAPA设备链路表ToolStripMenuItem.Click += new System.EventHandler(this.获取WIAPA设备链路表ToolStripMenuItem_Click);
            // 
            // 设置WIAPA设备链路表ToolStripMenuItem
            // 
            this.设置WIAPA设备链路表ToolStripMenuItem.Name = "设置WIAPA设备链路表ToolStripMenuItem";
            this.设置WIAPA设备链路表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.设置WIAPA设备链路表ToolStripMenuItem.Text = "设置WIA-PA设备链路表";
            this.设置WIAPA设备链路表ToolStripMenuItem.Visible = false;
            this.设置WIAPA设备链路表ToolStripMenuItem.Click += new System.EventHandler(this.设置WIAPA设备链路表ToolStripMenuItem_Click);
            // 
            // 获取交换机流表ToolStripMenuItem
            // 
            this.获取交换机流表ToolStripMenuItem.Name = "获取交换机流表ToolStripMenuItem";
            this.获取交换机流表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.获取交换机流表ToolStripMenuItem.Text = "获取交换机流表";
            this.获取交换机流表ToolStripMenuItem.Click += new System.EventHandler(this.获取交换机流表ToolStripMenuItem_Click);
            // 
            // 增加交换机流表ToolStripMenuItem
            // 
            this.增加交换机流表ToolStripMenuItem.Name = "增加交换机流表ToolStripMenuItem";
            this.增加交换机流表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.增加交换机流表ToolStripMenuItem.Text = "增加交换机流表";
            this.增加交换机流表ToolStripMenuItem.Visible = false;
            this.增加交换机流表ToolStripMenuItem.Click += new System.EventHandler(this.增加交换机流表ToolStripMenuItem_Click);
            // 
            // 删除交换机流表ToolStripMenuItem
            // 
            this.删除交换机流表ToolStripMenuItem.Name = "删除交换机流表ToolStripMenuItem";
            this.删除交换机流表ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.删除交换机流表ToolStripMenuItem.Text = "删除交换机流表";
            this.删除交换机流表ToolStripMenuItem.Visible = false;
            this.删除交换机流表ToolStripMenuItem.Click += new System.EventHandler(this.删除交换机流表ToolStripMenuItem_Click);
            // 
            // 联合调度ToolStripMenuItem
            // 
            this.联合调度ToolStripMenuItem.Name = "联合调度ToolStripMenuItem";
            this.联合调度ToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.联合调度ToolStripMenuItem.Text = "联合调度";
            this.联合调度ToolStripMenuItem.Click += new System.EventHandler(this.联合调度ToolStripMenuItem_Click);
            // 
            // richTextBoxPrintCtrl_Send
            // 
            this.richTextBoxPrintCtrl_Send.BackColor = System.Drawing.Color.AliceBlue;
            this.richTextBoxPrintCtrl_Send.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxPrintCtrl_Send.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxPrintCtrl_Send.Location = new System.Drawing.Point(0, 0);
            this.richTextBoxPrintCtrl_Send.Margin = new System.Windows.Forms.Padding(1);
            this.richTextBoxPrintCtrl_Send.Name = "richTextBoxPrintCtrl_Send";
            this.richTextBoxPrintCtrl_Send.Size = new System.Drawing.Size(176, 163);
            this.richTextBoxPrintCtrl_Send.TabIndex = 7;
            this.richTextBoxPrintCtrl_Send.Text = "";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.FlatAppearance.BorderSize = 0;
            this.checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox1.Location = new System.Drawing.Point(27, 17);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(109, 29);
            this.checkBox1.TabIndex = 18;
            this.checkBox1.Text = "记录操作";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.Visible = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged_1);
            // 
            // dst_comboBox
            // 
            this.dst_comboBox.BackColor = System.Drawing.Color.AliceBlue;
            this.dst_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dst_comboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dst_comboBox.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.dst_comboBox.FormattingEnabled = true;
            this.dst_comboBox.Location = new System.Drawing.Point(897, 39);
            this.dst_comboBox.Margin = new System.Windows.Forms.Padding(0);
            this.dst_comboBox.Name = "dst_comboBox";
            this.dst_comboBox.Size = new System.Drawing.Size(112, 29);
            this.dst_comboBox.TabIndex = 8;
            this.dst_comboBox.Visible = false;
            // 
            // src_comboBox
            // 
            this.src_comboBox.BackColor = System.Drawing.Color.AliceBlue;
            this.src_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.src_comboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.src_comboBox.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.src_comboBox.FormattingEnabled = true;
            this.src_comboBox.Location = new System.Drawing.Point(897, 56);
            this.src_comboBox.Margin = new System.Windows.Forms.Padding(0);
            this.src_comboBox.Name = "src_comboBox";
            this.src_comboBox.Size = new System.Drawing.Size(112, 29);
            this.src_comboBox.TabIndex = 8;
            this.src_comboBox.Visible = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.SystemColors.Control;
            this.imageList1.Images.SetKeyName(0, "timg.png");
            this.imageList1.Images.SetKeyName(1, "Shape_ST.png");
            this.imageList1.Images.SetKeyName(2, "Receiver.png");
            this.imageList1.Images.SetKeyName(3, "Network.png");
            this.imageList1.Images.SetKeyName(4, "Sender.png");
            this.imageList1.Images.SetKeyName(5, "Shape_T.png");
            this.imageList1.Images.SetKeyName(6, "Router.png");
            // 
            // timer_LineAnimate
            // 
            this.timer_LineAnimate.Interval = 50;
            this.timer_LineAnimate.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // skinEngine1
            // 
            this.skinEngine1.@__DrawButtonFocusRectangle = true;
            this.skinEngine1.DisabledButtonTextColor = System.Drawing.Color.Gray;
            this.skinEngine1.DisabledMenuFontColor = System.Drawing.SystemColors.GrayText;
            this.skinEngine1.InactiveCaptionColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinFile = null;
            // 
            // checkBox_CMD
            // 
            this.checkBox_CMD.AutoSize = true;
            this.checkBox_CMD.BackColor = System.Drawing.Color.Transparent;
            this.checkBox_CMD.FlatAppearance.BorderSize = 0;
            this.checkBox_CMD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_CMD.Location = new System.Drawing.Point(770, 51);
            this.checkBox_CMD.Name = "checkBox_CMD";
            this.checkBox_CMD.Size = new System.Drawing.Size(90, 29);
            this.checkBox_CMD.TabIndex = 16;
            this.checkBox_CMD.Text = "命令行";
            this.checkBox_CMD.UseVisualStyleBackColor = false;
            this.checkBox_CMD.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // panel_Caidan
            // 
            this.panel_Caidan.BackColor = System.Drawing.Color.Transparent;
            this.panel_Caidan.Controls.Add(this.button5);
            this.panel_Caidan.Controls.Add(this.label8);
            this.panel_Caidan.Controls.Add(this.button_Seprator);
            this.panel_Caidan.Controls.Add(this.btn_Gengxin);
            this.panel_Caidan.Controls.Add(this.btn_Pailie);
            this.panel_Caidan.Controls.Add(this.btn_Tongji);
            this.panel_Caidan.Controls.Add(this.btn_Youhua);
            this.panel_Caidan.Location = new System.Drawing.Point(93, 2);
            this.panel_Caidan.Name = "panel_Caidan";
            this.panel_Caidan.Size = new System.Drawing.Size(492, 80);
            this.panel_Caidan.TabIndex = 17;
            this.panel_Caidan.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.button8_Click);
            this.panel_Caidan.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            this.panel_Caidan.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = global::NetworkTopology.Properties.Resources.切换视图;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(302, 43);
            this.button5.Margin = new System.Windows.Forms.Padding(1);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 40);
            this.button5.TabIndex = 22;
            this.button5.Text = "拓扑";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("宋体", 22F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(-2, 2);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(373, 38);
            this.label8.TabIndex = 19;
            this.label8.Text = "6TiSCH网络客户端";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            this.label8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.button8_Click);
            this.label8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            this.label8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
            // 
            // button_Seprator
            // 
            this.button_Seprator.BackColor = System.Drawing.Color.Aqua;
            this.button_Seprator.FlatAppearance.BorderSize = 0;
            this.button_Seprator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Seprator.Location = new System.Drawing.Point(300, 41);
            this.button_Seprator.Name = "button_Seprator";
            this.button_Seprator.Size = new System.Drawing.Size(3, 40);
            this.button_Seprator.TabIndex = 17;
            this.button_Seprator.Text = "button1";
            this.button_Seprator.UseVisualStyleBackColor = false;
            // 
            // btn_Gengxin
            // 
            this.btn_Gengxin.BackColor = System.Drawing.Color.Transparent;
            this.btn_Gengxin.FlatAppearance.BorderSize = 0;
            this.btn_Gengxin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Gengxin.Image = global::NetworkTopology.Properties.Resources.更新网络5;
            this.btn_Gengxin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Gengxin.Location = new System.Drawing.Point(0, 41);
            this.btn_Gengxin.Margin = new System.Windows.Forms.Padding(1);
            this.btn_Gengxin.Name = "btn_Gengxin";
            this.btn_Gengxin.Size = new System.Drawing.Size(75, 40);
            this.btn_Gengxin.TabIndex = 16;
            this.btn_Gengxin.Text = "网络更新";
            this.btn_Gengxin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Gengxin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Gengxin.UseVisualStyleBackColor = false;
            this.btn_Gengxin.Click += new System.EventHandler(this.realTestToolStripMenuItem_Click);
            this.btn_Gengxin.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Gengxin.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // btn_Pailie
            // 
            this.btn_Pailie.FlatAppearance.BorderSize = 0;
            this.btn_Pailie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Pailie.Image = global::NetworkTopology.Properties.Resources.切换视图;
            this.btn_Pailie.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Pailie.Location = new System.Drawing.Point(150, 41);
            this.btn_Pailie.Name = "btn_Pailie";
            this.btn_Pailie.Size = new System.Drawing.Size(75, 40);
            this.btn_Pailie.TabIndex = 10;
            this.btn_Pailie.Text = "切换排列";
            this.btn_Pailie.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Pailie.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Pailie.UseVisualStyleBackColor = true;
            this.btn_Pailie.Click += new System.EventHandler(this.button4_Click);
            this.btn_Pailie.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Pailie.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // btn_Tongji
            // 
            this.btn_Tongji.FlatAppearance.BorderSize = 0;
            this.btn_Tongji.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Tongji.Image = ((System.Drawing.Image)(resources.GetObject("btn_Tongji.Image")));
            this.btn_Tongji.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Tongji.Location = new System.Drawing.Point(75, 41);
            this.btn_Tongji.Margin = new System.Windows.Forms.Padding(1);
            this.btn_Tongji.Name = "btn_Tongji";
            this.btn_Tongji.Size = new System.Drawing.Size(75, 40);
            this.btn_Tongji.TabIndex = 15;
            this.btn_Tongji.Text = "统计信息";
            this.btn_Tongji.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Tongji.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Tongji.UseVisualStyleBackColor = true;
            this.btn_Tongji.Click += new System.EventHandler(this.btn_Tongji_Click);
            this.btn_Tongji.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Tongji.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // btn_Youhua
            // 
            this.btn_Youhua.FlatAppearance.BorderSize = 0;
            this.btn_Youhua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Youhua.Image = global::NetworkTopology.Properties.Resources._06767;
            this.btn_Youhua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Youhua.Location = new System.Drawing.Point(225, 41);
            this.btn_Youhua.Margin = new System.Windows.Forms.Padding(1);
            this.btn_Youhua.Name = "btn_Youhua";
            this.btn_Youhua.Size = new System.Drawing.Size(75, 40);
            this.btn_Youhua.TabIndex = 11;
            this.btn_Youhua.Text = "排列优化";
            this.btn_Youhua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Youhua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Youhua.UseVisualStyleBackColor = true;
            this.btn_Youhua.Click += new System.EventHandler(this.力导向ToolStripMenuItem_Click);
            this.btn_Youhua.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Youhua.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "IPv6Any"});
            this.comboBox3.Location = new System.Drawing.Point(495, 25);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(180, 33);
            this.comboBox3.TabIndex = 34;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(495, 53);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(180, 31);
            this.textBox2.TabIndex = 33;
            this.textBox2.Text = "5990";
            // 
            // btn_Diaodu
            // 
            this.btn_Diaodu.FlatAppearance.BorderSize = 0;
            this.btn_Diaodu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Diaodu.Image = global::NetworkTopology.Properties.Resources.联合调度;
            this.btn_Diaodu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Diaodu.Location = new System.Drawing.Point(1009, 41);
            this.btn_Diaodu.Name = "btn_Diaodu";
            this.btn_Diaodu.Size = new System.Drawing.Size(75, 40);
            this.btn_Diaodu.TabIndex = 7;
            this.btn_Diaodu.Text = "联合调度";
            this.btn_Diaodu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Diaodu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Diaodu.UseVisualStyleBackColor = true;
            this.btn_Diaodu.Visible = false;
            this.btn_Diaodu.Click += new System.EventHandler(this.button3_Click_1);
            this.btn_Diaodu.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Diaodu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // printDocument_Prev
            // 
            this.printDocument_Prev.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDocument_DataGridview
            // 
            this.printDocument_DataGridview.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage_1);
            // 
            // printDialog1
            // 
            this.printDialog1.Document = this.printDocument_RichTextBox;
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument_RichTextBox
            // 
            this.printDocument_RichTextBox.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument_RichTextBox_BeginPrint);
            this.printDocument_RichTextBox.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_RichTextBox_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument_RichTextBox;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // pageSetupDialog1
            // 
            this.pageSetupDialog1.Document = this.printDocument_RichTextBox;
            // 
            // btn_Max
            // 
            this.btn_Max.BackColor = System.Drawing.Color.Transparent;
            this.btn_Max.FlatAppearance.BorderSize = 0;
            this.btn_Max.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Max.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Max.Image = global::NetworkTopology.Properties.Resources.最大化2;
            this.btn_Max.Location = new System.Drawing.Point(810, 1);
            this.btn_Max.Name = "btn_Max";
            this.btn_Max.Size = new System.Drawing.Size(25, 25);
            this.btn_Max.TabIndex = 11;
            this.btn_Max.UseVisualStyleBackColor = false;
            this.btn_Max.Click += new System.EventHandler(this.button8_Click);
            this.btn_Max.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Max.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // btn_file
            // 
            this.btn_file.BackColor = System.Drawing.Color.Transparent;
            this.btn_file.FlatAppearance.BorderSize = 0;
            this.btn_file.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_file.ForeColor = System.Drawing.Color.Transparent;
            this.btn_file.Image = global::NetworkTopology.Properties.Resources.菜单2;
            this.btn_file.Location = new System.Drawing.Point(759, 1);
            this.btn_file.Name = "btn_file";
            this.btn_file.Size = new System.Drawing.Size(25, 25);
            this.btn_file.TabIndex = 14;
            this.btn_file.UseVisualStyleBackColor = false;
            this.btn_file.Visible = false;
            this.btn_file.Click += new System.EventHandler(this.btn_file_Click);
            this.btn_file.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_file.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // btn_Min
            // 
            this.btn_Min.BackColor = System.Drawing.Color.Transparent;
            this.btn_Min.FlatAppearance.BorderSize = 0;
            this.btn_Min.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Min.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Min.Image = global::NetworkTopology.Properties.Resources.无标题11;
            this.btn_Min.Location = new System.Drawing.Point(784, 1);
            this.btn_Min.Name = "btn_Min";
            this.btn_Min.Size = new System.Drawing.Size(25, 25);
            this.btn_Min.TabIndex = 12;
            this.btn_Min.UseVisualStyleBackColor = false;
            this.btn_Min.Click += new System.EventHandler(this.button9_Click);
            this.btn_Min.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Min.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Transparent;
            this.btn_Close.FlatAppearance.BorderSize = 0;
            this.btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Close.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Close.Image = global::NetworkTopology.Properties.Resources.无标题2;
            this.btn_Close.Location = new System.Drawing.Point(835, 1);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(25, 25);
            this.btn_Close.TabIndex = 10;
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.Click += new System.EventHandler(this.button7_Click);
            this.btn_Close.MouseLeave += new System.EventHandler(this.button7_MouseLeave);
            this.btn_Close.MouseMove += new System.Windows.Forms.MouseEventHandler(this.button7_MouseMove);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Silver;
            this.pictureBox2.Location = new System.Drawing.Point(0, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(860, 86);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint);
            this.pictureBox2.DoubleClick += new System.EventHandler(this.pictureBox2_DoubleClick);
            this.pictureBox2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.button8_Click);
            this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            this.pictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
            this.pictureBox2.Resize += new System.EventHandler(this.pictureBox2_Resize);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.AliceBlue;
            this.statusStrip1.BackgroundImage = global::NetworkTopology.Properties.Resources.PanelEx;
            this.statusStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LinkInfoLabel,
            this.toolStripProgressBar1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 471);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.statusStrip1.Size = new System.Drawing.Size(1114, 29);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            this.statusStrip1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form4_MouseDown);
            this.statusStrip1.MouseLeave += new System.EventHandler(this.statusStrip1_MouseLeave);
            this.statusStrip1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form4_MouseMove);
            this.statusStrip1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form4_MouseUp);
            // 
            // LinkInfoLabel
            // 
            this.LinkInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.LinkInfoLabel.Name = "LinkInfoLabel";
            this.LinkInfoLabel.Size = new System.Drawing.Size(82, 24);
            this.LinkInfoLabel.Text = "连接设置";
            this.LinkInfoLabel.ToolTipText = "双击以进行连接设置";
            this.LinkInfoLabel.DoubleClick += new System.EventHandler(this.LinkInfoLabel_DoubleClick);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.BackColor = System.Drawing.Color.AliceBlue;
            this.toolStripProgressBar1.MarqueeAnimationSpeed = 50;
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(50, 24);
            this.toolStripStatusLabel2.Text = "X: ,Y:";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(50, 24);
            this.toolStripStatusLabel1.Text = "X: ,Y:";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(243, 478);
            this.progressBar1.MarqueeAnimationSpeed = 50;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(122, 22);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(675, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 57);
            this.button1.TabIndex = 18;
            this.button1.Text = "监听";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.清空ToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(117, 32);
            // 
            // 清空ToolStripMenuItem
            // 
            this.清空ToolStripMenuItem.Name = "清空ToolStripMenuItem";
            this.清空ToolStripMenuItem.Size = new System.Drawing.Size(116, 28);
            this.清空ToolStripMenuItem.Text = "清空";
            this.清空ToolStripMenuItem.Click += new System.EventHandler(this.清空ToolStripMenuItem_Click);
            // 
            // comboBox_NodeInfo
            // 
            this.comboBox_NodeInfo.FormattingEnabled = true;
            this.comboBox_NodeInfo.Location = new System.Drawing.Point(888, 2);
            this.comboBox_NodeInfo.Name = "comboBox_NodeInfo";
            this.comboBox_NodeInfo.Size = new System.Drawing.Size(121, 33);
            this.comboBox_NodeInfo.TabIndex = 35;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1015, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 34);
            this.button6.TabIndex = 36;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // Demo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1114, 500);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.comboBox_NodeInfo);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dst_comboBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.panel_Caidan);
            this.Controls.Add(this.src_comboBox);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btn_Diaodu);
            this.Controls.Add(this.btn_Max);
            this.Controls.Add(this.checkBox_CMD);
            this.Controls.Add(this.btn_file);
            this.Controls.Add(this.btn_Min);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.splitContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(600, 400);
            this.Name = "Demo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "6TiSCH网络后台";
            this.Load += new System.EventHandler(this.Demo_Load);
            this.SizeChanged += new System.EventHandler(this.Demo_SizeChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Demo_Paint);
            this.Leave += new System.EventHandler(this.Demo_Leave);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Material)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ListHeader)).EndInit();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip_cmd.ResumeLayout(false);
            this.toolStrip_cmd.PerformLayout();
            this.panel_Caidan.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.Button LiDaoXiang;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.Timer timer_LineAnimate;
        private System.Windows.Forms.ToolStripStatusLabel LinkInfoLabel;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TSM_Luyoubiao;
        private System.Windows.Forms.ToolStripMenuItem TSM_Chaozhenbiao;
        private System.Windows.Forms.ToolStripMenuItem TSM_Lianlubiao;
        private System.Windows.Forms.ToolStripMenuItem TSM_Jiaohuanjiliubiao;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
        private System.Windows.Forms.Button btn_Diaodu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 统计信息ToolStripMenuItem;
        private System.Windows.Forms.ComboBox dst_comboBox;
        private System.Windows.Forms.ComboBox src_comboBox;
        private System.Windows.Forms.Button btn_Pailie;
        private System.Windows.Forms.Button btn_Youhua;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Button btn_Max;
        private System.Windows.Forms.Button btn_Min;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_file;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Button btn_Tongji;
        private System.Windows.Forms.CheckBox checkBox_CMD;
        private System.Windows.Forms.Panel panel_Caidan;
        private System.Windows.Forms.ToolStripMenuItem 打印拓扑图ToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument_Prev;
        private System.Windows.Forms.PictureBox pictureBox_ListHeader;
        private System.Windows.Forms.ToolStrip toolStrip_cmd;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.Button btn_gridviewSave;
        private System.Windows.Forms.Button btn_gridviewPrint;
        private System.Windows.Forms.Button btn_Gengxin;
        private System.Drawing.Printing.PrintDocument printDocument_DataGridview;
        private RichTextBoxPrintCtrl.RichTextBoxPrintCtrl richTextBoxPrintCtrl_Receive;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument_RichTextBox;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_Seprator;
        private System.Windows.Forms.ToolStripMenuItem 获取panidToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 显示设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图例ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem NodeNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ConnectorNameToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 默认设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取WIAPA拓扑信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取回程网络拓扑信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取WIAPA设备路由表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置WIAPA设备路由表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取WIAPA设备超帧表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置WIAPA设备超帧表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取WIAPA设备链路表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置WIAPA设备链路表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取交换机流表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 增加交换机流表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除交换机流表ToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBar1;
        private RichTextBoxPrintCtrl.RichTextBoxPrintCtrl richTextBoxPrintCtrl_Send;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ToolStripMenuItem 联合调度ToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem 清空ToolStripMenuItem;
        private System.Windows.Forms.ListBox listBox_RecMsg;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.DataGridView dataGridView_Material;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column_Node;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randomTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 力导向ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem realTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emitterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem routerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox_NodeInfo;
        private System.Windows.Forms.Button button6;
	}
}

