﻿namespace NetworkTopology
{
    partial class SensorData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.显示数值 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Sensor类型 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.当前时间1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.机器号 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.chart波形3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart波形2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.时钟2 = new System.Windows.Forms.Timer(this.components);
            this.时钟 = new System.Windows.Forms.Timer(this.components);
            this.横坐标2 = new System.Windows.Forms.Label();
            this.横坐标1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart波形3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart波形2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.显示数值);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Sensor类型);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.当前时间1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.机器号);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(16, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(398, 476);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Device Data";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(170, 18);
            this.label7.TabIndex = 8;
            this.label7.Text = "Device Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Time:";
            // 
            // 显示数值
            // 
            this.显示数值.AutoSize = true;
            this.显示数值.Location = new System.Drawing.Point(88, 255);
            this.显示数值.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.显示数值.Name = "显示数值";
            this.显示数值.Size = new System.Drawing.Size(17, 18);
            this.显示数值.TabIndex = 16;
            this.显示数值.Text = ".";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Long Addres:";
            // 
            // Sensor类型
            // 
            this.Sensor类型.AutoSize = true;
            this.Sensor类型.Location = new System.Drawing.Point(152, 219);
            this.Sensor类型.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Sensor类型.Name = "Sensor类型";
            this.Sensor类型.Size = new System.Drawing.Size(17, 18);
            this.Sensor类型.TabIndex = 15;
            this.Sensor类型.Text = ".";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "IPv6 Addres:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(142, 183);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 18);
            this.label8.TabIndex = 13;
            this.label8.Text = "温湿度Sensor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Sensor Type:";
            // 
            // 当前时间1
            // 
            this.当前时间1.AutoSize = true;
            this.当前时间1.Location = new System.Drawing.Point(80, 75);
            this.当前时间1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.当前时间1.Name = "当前时间1";
            this.当前时间1.Size = new System.Drawing.Size(17, 18);
            this.当前时间1.TabIndex = 12;
            this.当前时间1.Text = ".";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 18);
            this.label5.TabIndex = 6;
            this.label5.Text = "Service Type:";
            // 
            // 机器号
            // 
            this.机器号.AutoSize = true;
            this.机器号.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.机器号.Location = new System.Drawing.Point(196, 38);
            this.机器号.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.机器号.Name = "机器号";
            this.机器号.Size = new System.Drawing.Size(17, 18);
            this.机器号.TabIndex = 11;
            this.机器号.Text = ".";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 18);
            this.label6.TabIndex = 7;
            this.label6.Text = "Value:";
            // 
            // chart波形3
            // 
            chartArea5.CursorX.IsUserEnabled = true;
            chartArea5.Name = "ChartArea1";
            this.chart波形3.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart波形3.Legends.Add(legend5);
            this.chart波形3.Location = new System.Drawing.Point(440, 280);
            this.chart波形3.Margin = new System.Windows.Forms.Padding(4);
            this.chart波形3.Name = "chart波形3";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chart波形3.Series.Add(series5);
            this.chart波形3.Size = new System.Drawing.Size(842, 218);
            this.chart波形3.TabIndex = 20;
            this.chart波形3.Text = "chart2";
            // 
            // chart波形2
            // 
            chartArea6.CursorX.IsUserEnabled = true;
            chartArea6.Name = "ChartArea1";
            this.chart波形2.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chart波形2.Legends.Add(legend6);
            this.chart波形2.Location = new System.Drawing.Point(440, 25);
            this.chart波形2.Name = "chart波形2";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.chart波形2.Series.Add(series6);
            this.chart波形2.Size = new System.Drawing.Size(842, 212);
            this.chart波形2.TabIndex = 19;
            this.chart波形2.Text = "chart1";
            // 
            // 时钟2
            // 
            this.时钟2.Enabled = true;
            this.时钟2.Tick += new System.EventHandler(this.时钟2_Tick);
            // 
            // 时钟
            // 
            this.时钟.Interval = 1000;
            this.时钟.Tick += new System.EventHandler(this.时钟_Tick);
            // 
            // 横坐标2
            // 
            this.横坐标2.AutoSize = true;
            this.横坐标2.Location = new System.Drawing.Point(402, 379);
            this.横坐标2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.横坐标2.Name = "横坐标2";
            this.横坐标2.Size = new System.Drawing.Size(26, 18);
            this.横坐标2.TabIndex = 23;
            this.横坐标2.Text = "NA";
            // 
            // 横坐标1
            // 
            this.横坐标1.AutoSize = true;
            this.横坐标1.Location = new System.Drawing.Point(407, 136);
            this.横坐标1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.横坐标1.Name = "横坐标1";
            this.横坐标1.Size = new System.Drawing.Size(26, 18);
            this.横坐标1.TabIndex = 22;
            this.横坐标1.Text = "NA";
            // 
            // SensorData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1299, 526);
            this.Controls.Add(this.横坐标2);
            this.Controls.Add(this.横坐标1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chart波形3);
            this.Controls.Add(this.chart波形2);
            this.Name = "SensorData";
            this.Text = "SensorData";
            this.Load += new System.EventHandler(this.SensorData_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart波形3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart波形2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label 显示数值;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Sensor类型;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label 当前时间1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label 机器号;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart波形3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart波形2;
        private System.Windows.Forms.Timer 时钟2;
        public System.Windows.Forms.Timer 时钟;
        private System.Windows.Forms.Label 横坐标2;
        private System.Windows.Forms.Label 横坐标1;
    }
}