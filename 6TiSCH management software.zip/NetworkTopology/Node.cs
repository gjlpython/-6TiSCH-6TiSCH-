﻿// A Force-Directed Diagram Layout Algorithm
// Bradley Smith - 2010/07/01

using System;
using System.Collections.Generic;
using System.Drawing;

using Graphic;
using System.Windows.Forms;
using NetworkTopology;
using System.Drawing.Drawing2D;

/// <summary>
/// Represents a node that can be added to a diagram and connected to other nodes. 
/// Provides logic for drawing itself and its connections to other nodes.
/// </summary>
public abstract class Node {

	Diagram mDiagram;			// the parent diagram
	Point mLocation;			// node position, relative to the origin
	List<Node> mConnections;	// list of references to connected nodes (children)

    public panid mPanid;
    public int m_WIAPA_networks; // 0: WIAPA  1:回程网

    public List<WIAPALuYou> mWIAPALuYou;
    public List<WIAPAChaoZhen> mWIAPAChaoZhen;
    public List<WIAPALianLu> mWIAPALianLu;
    public List<StatsFlow> mStatsFlow;

    public bool BeOperNode; //是否为当前被操作的Node
    string m_ID;
    string m_strName;
    string m_GatewayIPName;
    string m_type;

    public Size m_size;

	/// <summary>
	/// Gets or sets the position of the node.
	/// </summary>
	public Point Location {
		get { return mLocation; }
		set { mLocation = value; }
	}

	/// <summary>
	/// Gets a read-only collection representing the (child) nodes that this node is connected to.
	/// </summary>
	public IList<Node> Connections {
		get { return mConnections.AsReadOnly(); }
	}
	/// <summary>
	/// Gets or sets the diagram to which this node belongs.
	/// </summary>
	public Diagram Diagram
    {
		get { return mDiagram; }
		set {
                if (mDiagram == value)
                    return;
                if (mDiagram != null)
                    mDiagram.mNodes.RemoveAt(mDiagram.mNodes.FindIndex(c=>c.M_ID == this.M_ID));
                mDiagram = value;
                if (mDiagram != null)
                    mDiagram.AddNode(this);
                //if (mDiagram == value) 
                //    return;
                ////if (mDiagram != null) 
                ////    mDiagram.RemoveNode(this);
                //mDiagram = value;
                //if (mDiagram != null)
                //    mDiagram.AddNode(this);
		}
	}
	/// <summary>
	/// Gets or sets the X coordinate of the node, relative to the origin.
	/// </summary>
	public int X {
		get { return mLocation.X; }
		set { mLocation.X = value; }
	}
	/// <summary>
	/// Gets or sets the Y coordinate of the node, relative to the origin.
	/// </summary>
	public int Y {
		get { return mLocation.Y; }
		set { mLocation.Y = value; }
	}

    /// <summary>
    /// 设置与获取Node的M_strName
    /// </summary>
    public string M_strName
    {
        get { return m_strName; }
        set { m_strName = value; }
    }

    public string M_GatewayIPName
    {
        get { return m_GatewayIPName; }
        set { m_GatewayIPName = value; }
    }

    /// <summary>
    /// 设置与获取Node的类型信息
    /// </summary>
    public string M_type
    {
        get { return m_type; }
        set { m_type = value; }
    }

    /// <summary>
    /// 设置与获取Node的ID
    /// </summary>
    public string M_ID
    {
        get { return m_ID; }
        set { m_ID = value; }
    }


	/// <summary>
	/// Gets the size of the node (for drawing purposes).
	/// </summary>
    public abstract Size Size
    {
        get;
        set;
    }

	/// <summary>
	/// Initialises a new instance of the Node class.
	/// </summary>
    public Node(string ID)
    {
        m_ID = ID;
		mLocation = Point.Empty;
		mDiagram = null;
		mConnections = new List<Node>();

        mWIAPALuYou = new List<WIAPALuYou>();
        mWIAPAChaoZhen =new List<WIAPAChaoZhen>();
        mWIAPALianLu = new List<WIAPALianLu>();
        mStatsFlow = new List<StatsFlow>();

        m_strName = "Unknown";
        m_GatewayIPName = "";

        Size = new Size(32, 32);
	}

	/// <summary>
	/// Connects the specified child node to this node.
	/// </summary>
	/// <param name="child">The child node to add.</param>
	/// <returns>True if the node was connected to this node.</returns>
    //public bool AddChild(Node child) {
    //    if (child == null) throw new ArgumentNullException("child");
    //    if ((child != this) && !this.mConnections.Contains(child))
    //    {
    //        child.Diagram = this.Diagram;
    //        this.mConnections.Add(child);
    //        return true;
    //    }
    //    else 
    //    {
    //        return false;
    //    }
    //}
    public bool AddChild(Node child, ref List<GObject> refGObjects)
    {
        if (child == null) throw new ArgumentNullException("child");
        if ((child != this) && !this.mConnections.Contains(child))
        {
            child.Diagram = this.Diagram;
            this.mConnections.Add(child);

            //添加节点
            //refGObjects.Add(new GObject(child.M_strName, (child.M_type).ToString(),
            //                        child.X, child.Y, "", child.X + 10, child.Y + 10, ""));
            //添加节点间的连线
            refGObjects.Add(new GObject(child.M_strName + "_" + this.M_strName, "Line",
                                    child.X, child.Y, child.M_strName, this.X, this.Y, this.M_strName));

            return true;
        }
        else
        {
            return false;
        }
    }

    public bool AddChild(Node child)
    {
        if (child == null) throw new ArgumentNullException("child");
        if ((child != this) && !this.mConnections.Contains(child))
        {
            child.Diagram = this.Diagram;
            this.mConnections.Add(child);

            //添加节点
            //refGObjects.Add(new GObject(child.M_strName, (child.M_type).ToString(),
            //                        child.X, child.Y, "", child.X + 10, child.Y + 10, ""));
            //添加节点间的连线
            //refGObjects.Add(new GObject(child.M_strName + "_" + this.M_strName, "Line",
            //                        child.X, child.Y, child.M_strName, this.X, this.Y, this.M_strName));

            return true;
        }
        else
        {
            return false;
        }
    }

	/// <summary>
	/// Connects this node to the specified parent node.
	/// </summary>
	/// <param name="parent">The node to connect to this node.</param>
	/// <returns>True if the other node was connected to this node.</returns>
    public bool AddParent(Node parent, ref List<GObject> refGObjects)
    {
		if (parent == null) throw new ArgumentNullException("parent");
        return parent.AddChild(this, ref refGObjects);
	}

	/// <summary>
	/// Removes any connection between this node and the specified node.
	/// </summary>
	/// <param name="other">The other node whose connection is to be removed.</param>
	/// <returns>True if a connection existed.</returns>
	public bool Disconnect(Node other) {
		bool c = this.mConnections.Remove(other);
		bool p = other.mConnections.Remove(this);
		return c || p;
	}

	/// <summary>
	/// Draws a connector between this node and the specified child node using GDI+. 
	/// The source and destination coordinates (relative to the Graphics surface) are also specified.
	/// </summary>
	/// <param name="graphics">GDI+ Graphics surface.</param>
	/// <param name="from">Source coodinate.</param>
	/// <param name="to">Destination coordinate.</param>
	/// <param name="other">The other node.</param>
	public virtual void DrawConnector(Graphics graphics, Point from, Point to, Node other)
    {
		graphics.DrawLine(Pens.DarkBlue, from, to);
	}


    public virtual void DrawConnector_Flash(Graphics graphics, Point from, Point to, Node other,double PosPercentage,int[] m_RGBPlotSetting)
    {
        LinearGradientBrush linGrBrush = new LinearGradientBrush(
                                  new Point(0, 0),
                                  new Point(50, 50),
                                  Color.FromArgb(255, m_RGBPlotSetting[0], m_RGBPlotSetting[1], m_RGBPlotSetting[2]),
                                  Color.FromArgb(255, m_RGBPlotSetting[3], m_RGBPlotSetting[4], m_RGBPlotSetting[5]));

        Pen pen2 = new Pen(linGrBrush, 3); // Pen pen2 = new Pen(Color.Red, 3);
        pen2.DashStyle = DashStyle.Custom;
        pen2.DashPattern = new float[] { 1f, 1f };

        //pen2.StartCap = LineCap.Round;
        //pen2.EndCap = LineCap.ArrowAnchor;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.DrawLine(pen2, from, to);


        Brush brush = new SolidBrush(Color.Red);//颜色
        int tempX = (int)(from.X + (to.X - from.X) * PosPercentage);
        int tempY = (int)(from.Y + (to.Y - from.Y) * PosPercentage);
        graphics.FillEllipse(brush, tempX - 5, tempY - 5, 10, 10);//画椭圆的方法，x坐标、y坐标、宽、高，如果是100，则半径为50


        //Pen pen2 = new Pen(Color.Red,3);
        //pen2.DashStyle = DashStyle.Custom;
        //pen2.DashPattern = new float[] { 2f, 2f };        

        //pen2.StartCap = LineCap.Round;
        //pen2.EndCap = LineCap.ArrowAnchor;

        //graphics.SmoothingMode = SmoothingMode.AntiAlias;
        //graphics.DrawLine(pen2, from, to);


        ////这是按照水平向左的方向画图的 ,现在要实现的是任意角度，关键的是p1,p2,p3坐标怎么算的呢， 
        ////看着真的很简单，高中知识，可是我现在解二元二次方程， 搞的我头都大了，还是不能用from，to，triangleSize来表示。
        //PointF p1 = new PointF(to.X, to.Y - triangleSize.Height / 2);
        //PointF p2 = new PointF(to.X, to.Y + triangleSize.Height / 2);
        //PointF p3 = new PointF(to.X + triangleSize.Width, to.Y);

        //Brush brush = new SolidBrush(Color.Red);
        //GraphicsPath path = new GraphicsPath();
        //path.AddLine(p1, p2);
        //path.AddLine(p2, p3);
        //path.AddLine(p3, p1);
        //graphics.FillPath(brush, path);
	}

    SizeF triangleSize;
    /// <summary>
    /// 三角形大小 ，这个是等腰三角形， 宽度表示定点到底边的距离， 高表示底边的长度
    /// </summary>
    public SizeF TriangleSize
    {
        get { return triangleSize; }
        set
        {
            if (triangleSize != value)
            {
                triangleSize = value;
                //base.Invalidate();
            }
        }
    }
    

	/// <summary>
	/// Draws the node using GDI+, within the specified bounds.
	/// </summary>
	/// <param name="graphics">GDI+ Graphics surface.</param>
	/// <param name="bounds">The bounds in which to draw the node.</param>
	public abstract void DrawNode(Graphics graphics, Rectangle bounds);

    public abstract Rectangle DrawNode(Graphics graphics, string m_type, Rectangle bounds);
}

/// <summary>
/// Provides an example implementation of the Node class. SpotNode is an 8x8 circle that is stroked and filled.
/// </summary>
public class SpotNode : Node {

	private Brush mFill;
	private Pen mStroke;

	/// <summary>
	/// Gets or sets the System.Drawing.Brush used to fill the spot.
	/// </summary>
	public Brush Fill {
		get { return mFill; }
		set {
			if (value == null) throw new ArgumentNullException("value");
			mFill = value;
		}
	}
	/// <summary>
	/// Gets the size of the spot.
	/// </summary>
	public override Size Size
    {
        get { return m_size; } //new Size(32, 32);  
        set
        {
            if (value == null) throw new ArgumentNullException("value");
            m_size = value;
        }
	}
	/// <summary>
	/// Gets or sets the System.Drawing.Pen used to stroke the spot.
	/// </summary>
	public Pen Stroke {
		get { return mStroke; }
		set {
			if (value == null) throw new ArgumentNullException("value");
			mStroke = value;
		}
	}

	/// <summary>
	/// Initalises a new instance of the SpotNode class using default values.
	/// </summary>
	public SpotNode() : this("-1",Color.Black) { }

	/// <summary>
	/// Initalises a new instance of the SpotNode class using the specified fill color.
	/// </summary>
	/// <param name="color">The System.Drawing.Color to fill the spot with.</param>
	public SpotNode(string ID,Color color) : base(ID)
    {
        //M_ID = ID;
		mFill = new SolidBrush(color);
		mStroke = Pens.Black;
	}

	/// <summary>
	/// Draws the node using GDI+.
	/// </summary>
	/// <param name="graphics">GDI+ Graphics surface.</param>
	/// <param name="bounds">The bounds in which to draw the node.</param>
	public override void DrawNode(Graphics graphics, Rectangle bounds) 
    {
		graphics.FillEllipse(mFill, bounds);
		graphics.DrawEllipse(mStroke, bounds);
	}

    public override Rectangle DrawNode(Graphics graphics, string m_type, Rectangle bounds)
    {
        Rectangle ModifyBounds = new Rectangle();
        if (m_type == "0x0000" || m_type == "0x0001" || m_type == "0x0002" || m_type == "0x0003")
        {
            Image ObjImg;
            ObjImg = this.Diagram.FindGObjectTypeImage(m_type);
            ModifyBounds = bounds;
            graphics.DrawImage(ObjImg, ModifyBounds);

            //ModifyBounds.X = bounds.X - bounds.Width;
            //ModifyBounds.Y = bounds.Y - bounds.Height;
            //ModifyBounds.Width = 3 * bounds.Width;
            //ModifyBounds.Height = 3 * bounds.Height;
            //graphics.DrawImage(ObjImg, ModifyBounds);
        }
        else
        {
            //graphics.FillEllipse(mFill, bounds);
            //graphics.DrawEllipse(mStroke, bounds);
            Image ObjImg;
            ObjImg = this.Diagram.FindGObjectTypeImage(m_type);
            ModifyBounds = bounds;
            graphics.DrawImage(ObjImg, ModifyBounds);
            //ModifyBounds.X = bounds.X - bounds.Width;
            //ModifyBounds.Y = bounds.Y - bounds.Height;
            //ModifyBounds.Width = 3 * bounds.Width;
            //ModifyBounds.Height = bounds.Height;
            //graphics.DrawImage(ObjImg, ModifyBounds);
        }
        return ModifyBounds;
	}

    

}