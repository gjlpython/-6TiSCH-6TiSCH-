using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;


namespace Graphic
{
    public class GObject
    {
        public string m_ID;
        public string Name;
        public string m_GatewayIPName;
        public string PlotType;
        public string m_type;
        public int x1;
        public int y1;
        public string Lnk1;
        public int x2;
        public int y2;
        public string Lnk2;

        public GObject()
        {
            m_ID = "";
            Name = "";
            m_GatewayIPName = "";
            PlotType = "";
            m_type = "-1";
            Lnk1 = "";
            Lnk2 = "";
            x1 = 0;
            y1 = 0;
            x2 = 0;
            y2 = 0;
        }

        public GObject(string ObjID, string ObjName, string ObjGatewayIPName, string ObjPlotType, string ObjType,int ObjX1, int ObjY1, string LNK1, int ObjX2, int ObjY2, string LNK2)
        {
            m_ID = ObjID;
            Name = ObjName;
            m_GatewayIPName = ObjGatewayIPName;
            PlotType = ObjPlotType;
            m_type = ObjType;

            Lnk1 = LNK1;
            Lnk2 = LNK2;
            x1 = ObjX1;
            y1 = ObjY1;
            x2 = ObjX2;
            y2 = ObjY2;
        }

        public GObject(string ObjName, string ObjType, int ObjX1, int ObjY1, string LNK1, int ObjX2, int ObjY2, string LNK2)
        {
            Name = ObjName;
            PlotType = ObjType;

            m_ID = "";
            m_GatewayIPName = "";
            PlotType = "";

            Lnk1 = LNK1;
            Lnk2 = LNK2;
            x1 = ObjX1;
            y1 = ObjY1;
            x2 = ObjX2;
            y2 = ObjY2;
        }

        public GObject(string ObjName, string ObjType, Point Obj1, string LNK1, Point Obj2, string LNK2)
        {
            Name = ObjName;
            PlotType = ObjType;

            m_ID = "";
            m_GatewayIPName = "";
            PlotType = "";

            Lnk1 = LNK1;
            Lnk2 = LNK2;
            x1 = Obj1.X;
            y1 = Obj1.Y;
            x2 = Obj2.X;
            y2 = Obj2.Y;
        }

        public void Clear()
        {
            Name = "";
            PlotType = "";
            Lnk1 = "";
            Lnk2 = "";
            x1 = 0;
            y1 = 0;
            x2 = 0;
            y2 = 0;
        }
    }

    public class GScenario
    {
       
        //public int Nobj;
        public int CurrObjIndx;
        //public GObject[] GObjects;
        public List<GObject> GObjects;
        private const double PrcLineDist = 0.01;

        public GScenario(int Nobjects)
        {

                CurrObjIndx = 0;
                //Nobj = Nobjects;

                //GObjects = new GObject[Nobjects];
                //for (int i = 0; i < Nobjects; i++)
                //{
                //    GObjects[i] = new GObject();
                //}
                GObjects = new List<GObject>();
                for (int i = 0; i < Nobjects; i++)
                {
                    GObjects.Add(new GObject());
                }
        }

        public GScenario()
        {
            CurrObjIndx = -1;
            //Nobj = 0;
            GObjects = new List<GObject>();
        }

        public void Clear()
        {
            // Nobj remains unaffected !
            CurrObjIndx = -1;
            //for (int i = 0; i < Nobj; i++)
            //{
            //    GObjects[i].Clear();
            //}
            GObjects.Clear();
        }

        public int FindContainerObject(int X, int Y, ref GObject GContainer, bool NoLineFlag)
        {
            GObject CurrObj;
            bool inside = false;
            int retval = -1;
            double m = 0;
            double q = 0;
            double d = 0;
            double dmax = 0;
            double e = 0;
            for (int i = 0; i < GObjects.Count; i++)  //for (int i = 0; i < Nobj; i++)
            {
                CurrObj = GObjects[i];
                if (CurrObj.PlotType != "Line")
                {
                    //
                    //   module of (x2,y2) is always > (x1,y1)
                    //
                    inside = (X >= CurrObj.x1) && (Y >= CurrObj.y1);
                    inside = inside && (X <= CurrObj.x2);
                    inside = inside && (Y <= CurrObj.y2);
                }
                else
                {
                    //
                    //   due to mobile links can be (x2,y2) > or < di (x1,y1)
                    //   in this case we don't consider the container
                    //   but only if we are next to the line
                    //
                    m = (double)(CurrObj.y2 - CurrObj.y1) / (CurrObj.x2 - CurrObj.x1);
                    q = (double)CurrObj.y1 - m * CurrObj.x1;
                    d = System.Math.Abs(Y - m * X - q) / System.Math.Sqrt(1 + m * m);
                    dmax = CommFnc.module(X,Y);
                    e = d / dmax;
                    inside = (e < PrcLineDist);
                    if (NoLineFlag == true) inside = false;
                }
                if (inside == true)
                {
                    GContainer = CurrObj;
                    retval = i;
                }
            }
            return retval;
        }

        public void AddGObject(string ObjName, string ObjType,int x1, int y1, int x2, int y2)
        {
            GObject ObjToAdd = new GObject();
            ObjToAdd.x1 = x1;
            ObjToAdd.y1 = y1;
            ObjToAdd.Lnk1 = "";
            ObjToAdd.x2 = x2;
            ObjToAdd.y2 = y2;
            ObjToAdd.Lnk2 = "";
            ObjToAdd.Name = ObjName;
            ObjToAdd.PlotType = ObjType;

            GObjects.Add(ObjToAdd);

            GObjects[CurrObjIndx] = ObjToAdd;
            //CurrObjIndx++;
        }

        public void ModifyGObject(GObject OldGObject, GObject NewGObject)
        {            //
            //      Adjust all the references
            //
            for (int i = 0; i < GObjects.Count; i++) //for (int i = 0; i < Nobj; i++)
            {
                if (GObjects[i].Lnk1 == OldGObject.Name)
                {
                    GObjects[i].Lnk1 = NewGObject.Name;
                }
                if (GObjects[i].Lnk2 == OldGObject.Name)
                {
                    GObjects[i].Lnk2 = NewGObject.Name;
                }
            }
            //
            //      Adjust Object properties
            //
            OldGObject.x1 = NewGObject.x1;
            OldGObject.y1 = NewGObject.y1;
            OldGObject.Lnk1 = NewGObject.Lnk1;
            OldGObject.x2 = NewGObject.x2;
            OldGObject.y2 = NewGObject.y2;
            OldGObject.Lnk2 = NewGObject.Lnk2;
            OldGObject.Name = NewGObject.Name;
            OldGObject.PlotType = NewGObject.PlotType;
        }

        public void DeleteGObject(GObject GObjectToDelete)
        {
            if (CurrObjIndx ==0)
            {
                //
                //  There's no objects!
                //
            }
            else
            {
                //
                //      Find the index of the object to delete
                //
                int IndexToDelete = 0;
                FindGObjectIndxByName(GObjectToDelete.Name, ref IndexToDelete);
                //
                //      Adjust (nullify) all the references
                //
                for (int i = 0; i < GObjects.Count; i++) //for (int i = 0; i < Nobj; i++)
                {
                    if (GObjects[i].Lnk1 == GObjectToDelete.Name)
                    {
                        GObjects[i].Lnk1 = "";
                    }
                    if (GObjects[i].Lnk2 == GObjectToDelete.Name)
                    {
                        GObjects[i].Lnk2 = "";
                    }
                }
                //
                //      Nullify Object properties
                //
                GObjectToDelete.x1 = 0;
                GObjectToDelete.y1 = 0;
                GObjectToDelete.Lnk1 = "";
                GObjectToDelete.x2 = 0;
                GObjectToDelete.y2 = 0;
                GObjectToDelete.Lnk2 = "";
                GObjectToDelete.Name = "";
                GObjectToDelete.PlotType = "";
                //
                //      Left Shift of the GObjects vector
                //
                int j = IndexToDelete;
                while (j < GObjects.Count - 1) //while (j < Nobj - 1)
                {
                    GObjects[j] = GObjects[j + 1];
                    j++;
                }
                CurrObjIndx--;
            }
        }

        public void FindGObjectIndxByName(string ObjName, ref int GObjIndx)
        {
            for (int i = 0; i < GObjects.Count; i++)  // for (int i = 0; i < Nobj; i++)
            {
                if (GObjects[i].Name == ObjName)
                {
                    GObjIndx = i;
                }
            }
        }

        public void FindGObjectByName(string ObjLnkName, ref GObject GObj)
        {
            for (int i = 0; i < GObjects.Count; i++)  //for (int i = 0; i < Nobj; i++)
            {
                if (GObjects[i].Name == ObjLnkName)
                {
                    GObj = GObjects[i];
                }
            }
        }

        public void AdjustLinkedTo(string ObjLnkName)
        {
            GObject GObjLinked = new GObject();
            FindGObjectByName(ObjLnkName, ref GObjLinked);
            for (int i = 0; i < GObjects.Count; i++) //for (int i = 0; i < Nobj; i++)
            {
                if (GObjects[i].PlotType == "Line")
                {
                    if (GObjects[i].Lnk1 == ObjLnkName)
                    {
                        GObjects[i].x1 = (GObjLinked.x1 + GObjLinked.x2) / 2;
                        GObjects[i].y1 = (GObjLinked.y1 + GObjLinked.y2) / 2;
                    }
                    //
                    if (GObjects[i].Lnk2 == ObjLnkName)
                    {
                        GObjects[i].x2 = (GObjLinked.x1 + GObjLinked.x2) / 2;
                        GObjects[i].y2 = (GObjLinked.y1 + GObjLinked.y2) / 2;
                    }
                }
            }
        }

        public int LastIndexOfGObject(string Type)
        {
            int retval = 0;
            for (int i = 0; i < GObjects.Count; i++) //for (int i = 0; i < Nobj; i++)
            {
                if (GObjects[i].PlotType == Type)
                {
                    retval++;
                }
            }
            return retval;
        }

        public bool LoadFile(string FileFullPath, ref string sErrFileMsg)
        {
            string sVariable = "";
            string sValue = "";
            string cFirst = "";
            int i = 0;
            int iLine = 0;
            
            GObject NewGObj = new GObject();
            sErrFileMsg = "";
            try
            {
                using (StreamReader sr = new StreamReader(FileFullPath))
                {
                    // ��ȡ����
                    String sLine = "";
                    while (sLine != "end network file.")
                    {
                        sLine = sr.ReadLine();
                        iLine++;
                        if (sLine=="end object.")
                        {
                            sLine = sr.ReadLine();
                            iLine++;
                        }
                        if (sLine == "")
                        {
                            cFirst = "*";
                        }
                        else
                        {
                            cFirst = sLine.Substring(0, 1);
                        }
                        if (cFirst == "*")
                        {
                            // null o *-beginning lines are like comments
                        }
                        else
                        {
                            while ((sLine != "end object.") && (sLine != "end network file."))
                            {
                                CommFnc.RowDecode(sLine, ref sVariable, ref sValue);
                                switch (sVariable)
                                {
                                    case "object":
                                        NewGObj.Name = sValue;
                                        break;
                                    case "type":
                                        NewGObj.PlotType = sValue;
                                        break;
                                    case "lnk1":
                                        NewGObj.Lnk1 = sValue;
                                        break;
                                    case "lnk2":
                                        NewGObj.Lnk2 = sValue;
                                        break;
                                    case "x1":
                                        NewGObj.x1 = System.Convert.ToInt32(sValue);
                                        break;
                                    case "x2":
                                        NewGObj.x2 = System.Convert.ToInt32(sValue);
                                        break;
                                    case "y1":
                                        NewGObj.y1 = System.Convert.ToInt32(sValue);
                                        break;
                                    case "y2":
                                        NewGObj.y2 = System.Convert.ToInt32(sValue);
                                        break;
                                    default:
                                        break;
                                }
                                sLine = sr.ReadLine();
                                iLine++;
                            }
                            if (sLine == "end object.") 
                            {
                                //GObjects[i] = new GObject(NewGObj.Name, NewGObj.Type, 
                                //    NewGObj.x1, NewGObj.y1, NewGObj.Lnk1, NewGObj.x2, NewGObj.y2, NewGObj.Lnk2);

                                GObjects.Add(new GObject(NewGObj.Name, NewGObj.PlotType,
                                    NewGObj.x1, NewGObj.y1, NewGObj.Lnk1, NewGObj.x2, NewGObj.y2, NewGObj.Lnk2));
                                i++;
                                CurrObjIndx = i;
                            }
                        } 
                    }
                 }
                return true;
            }
            catch (Exception e)
            {
                sErrFileMsg = "Error reading file : " + e.Message + " line = "+ i.ToString() + "\n";
                return false;
            }
        }

        public bool SaveFile(string FileFullPath, ref string sErrFileMsg)
        {
            sErrFileMsg = "";
            try
            {
                using (StreamWriter sw = new StreamWriter(FileFullPath))
                {
                    String sLine;
                    for (int i = 0; i < GObjects.Count; i++) //for (int i = 0; i < Nobj; i++)
                    {
                        if (GObjects[i].Name != "")
                        {
                            sLine = "object=" + GObjects[i].Name + ";";
                            sw.WriteLine(sLine);
                            sLine = "type=" + GObjects[i].PlotType + ";";
                            sw.WriteLine(sLine);
                            sLine = "x1=" + GObjects[i].x1.ToString() + ";";
                            sw.WriteLine(sLine);
                            sLine = "y1=" + GObjects[i].y1.ToString() + ";";
                            sw.WriteLine(sLine);
                            sLine = "lnk1=" + GObjects[i].Lnk1 + ";";
                            sw.WriteLine(sLine);
                            sLine = "x2=" + GObjects[i].x2.ToString() + ";";
                            sw.WriteLine(sLine);
                            sLine = "y2=" + GObjects[i].y2.ToString() + ";";
                            sw.WriteLine(sLine);
                            sLine = "lnk2=" + GObjects[i].Lnk2 + ";";
                            sw.WriteLine(sLine);
                            sLine = "end object.";
                            sw.WriteLine(sLine);
                            sw.WriteLine();
                        }
                    }
                    sw.WriteLine("end network file.");
                }
                return true;
            }
            catch (Exception e)
            {
                sErrFileMsg = "Error writing file : " + e.Message + "\n";
                return false;
            }
        }

    }
       
}
