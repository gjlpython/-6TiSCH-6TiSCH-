﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Collections;
//using Microsoft.Office.Core;
using System.Reflection;
using Excel = Microsoft.Office.Interop.Excel;

namespace ForceDirected
{
    struct DataBaseInfo
    {
        public string DataBaseUserName;
        public string Servername;
        public int AuthenticationType;
        public string DataBaseName;
        public string UserName;
        public string Password;
        public string OnLineServer;
        public int OnLineServerPort;
        public int iBit;
    }

    class ExcelOper
    {
       // 0 is Export mode  只写

　　//1 is Import mode   只读

　　//2 is Linked mode (full update capabilities)  读写

     //   HDR ( HeaDer Row )设置

　　//若指定值为Yes，代表 Excel 档中的工作表第一行是栏位名称

　　//若指定值為 No，代表 Excel 档中的工作表第一行就是資料了，沒有栏位名称
       // F:\\风电资料\\程序\\WindCon\\WindCon\\bin\\Debug\\
        string strConn ="Provider=Microsoft.Jet.OLEDB.4.0;Data Source="+System.Environment.CurrentDirectory+"\\DBINFO.xls;Extended Properties='Excel 8.0;HDR=Yes;IMEX=2;'";

        public void ReadExcel(string filePath, ref float[] fdata, int nStart)
        {
            string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";

            string[] strFile = filePath.Split('\\');
            string[] sheet = strFile[strFile.Length - 1].Split('.');
            // string strSheetName = "A1_1";
            string strSheetName = sheet[0];
            string strExcel = "select Data from  [" + strSheetName + "$] ";
            OleDbConnection myConn = new OleDbConnection(strConn);
            
            try
            {

                myConn.Open();
                OleDbCommand myCmd = new OleDbCommand(strExcel, myConn);
                OleDbDataReader myReader = myCmd.ExecuteReader();

                int len = fdata.Length;
                int i = 0;
                while (myReader.Read())
                {
                    if (i >= nStart)
                        fdata[i - nStart] = float.Parse(myReader[0].ToString().Trim());
                    i++;
                    if (i - nStart == len)
                        break;
                }
                myReader.Close();
            }
            catch (OleDbException OleLexc)
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            

            myConn.Close();
        }


        //读取数据库名
        public void ReadDataBaseName(ArrayList al)
        {
            string strCmd = "select DataBaseUserName from [DataBaseInfo$]";
            OleDbConnection myConn = new OleDbConnection(strConn);
            try
            {

                myConn.Open();
                OleDbCommand myCmd = new OleDbCommand(strCmd, myConn);
                 OleDbDataReader myReader = myCmd.ExecuteReader();
                while (myReader.Read())
                {
                   al.Add(myReader.GetString(0));
                }
                myReader.Close();
            }
            catch (OleDbException OleLexc)
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            
            myConn.Close();
        }
        //读取数据库详细信息
        public void ReadDataBaseInfo(ArrayList al)
        {
            string strCmd = "select *  from [DataBaseInfo$]";
            OleDbConnection myConn = new OleDbConnection(strConn);
           
            try
            {

                myConn.Open();
                OleDbCommand myCmd = new OleDbCommand(strCmd, myConn);
                 OleDbDataReader myReader = myCmd.ExecuteReader();
                DataBaseInfo dbi = new DataBaseInfo();
                while (myReader.Read())
                {
                    dbi.DataBaseUserName = myReader[0].ToString();
                    dbi.Servername = myReader[1].ToString();
                    dbi.DataBaseName = myReader[3].ToString();
                    dbi.OnLineServer = myReader[6].ToString();
                   
                    al.Add(dbi);
                }
                myReader.Close();
            }
            catch (OleDbException OleLexc)
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            
            myConn.Close();

        }

        //读取一条数据库记录
        public void ReadCertainDataBaseInfo(ref DataBaseInfo dbi,string strDatabasename)
        {
            string strCmd = "select *  from [DataBaseInfo$] where DataBaseUserName='"+strDatabasename+"'";
            OleDbConnection myConn = new OleDbConnection(strConn);
            
            try
            {
                myConn.Open();
                OleDbCommand myCmd = new OleDbCommand(strCmd, myConn);
                 OleDbDataReader myReader = myCmd.ExecuteReader();
                //DataBaseInfo dbi = new DataBaseInfo();
                while (myReader.Read())
                {
                    dbi.DataBaseUserName = myReader[0].ToString();
                    dbi.Servername = myReader[1].ToString();
                    dbi.AuthenticationType = Int32.Parse(myReader[2].ToString());
                    dbi.DataBaseName = myReader[3].ToString();
                    dbi.UserName = myReader[4].ToString();
                    dbi.Password = myReader[5].ToString();
                    dbi.OnLineServer = myReader[6].ToString();
                    dbi.OnLineServerPort = Int32.Parse(myReader[7].ToString());
                    dbi.iBit = Int32.Parse(myReader[9].ToString());
                }
                myReader.Close();
            }
            catch (OleDbException OleLexc)
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            
            myConn.Close();

        }
        //删除一条数据库信息
        public void DelCertainDataBaseInfo(string strDatabasename)
        {
/*
            string strCmd = "delete from [DataBaseInfo$] where DataBaseUserName='" + strDatabasename + "'";

            OleDbConnection myConn = new OleDbConnection(strConn);
            try
            {
                myConn.Open();
                OleDbCommand myCmd = new OleDbCommand(strCmd, myConn);
                myCmd.ExecuteNonQuery();
            }
            catch (OleDbException OleLexc)
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            myConn.Close();
*/
           // Excel.ApplicationClassobjApp = new Excel.ApplicationClass(); 
            string strPath = System.Environment.CurrentDirectory + "\\DBINFO.xls";
            Excel.Application myExcel=new Excel.Application();
             Excel.Workbook m_Workbook = null; 
            Excel.Worksheet m_Worksheet = null;

             object objOpt = System.Reflection.Missing.Value;
             m_Workbook = myExcel.Workbooks.Open(strPath, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt);
             m_Worksheet = (Excel.Worksheet)m_Workbook.Worksheets.get_Item(1);
            //XlDeleteShiftDirection
            // m_Worksheet.Rows.Delete(Keys.Shift);
           //  m_Worksheet.Delete();
            
            Excel.Range range=m_Worksheet.get_Range(m_Worksheet.Cells[3,1],m_Worksheet.Cells[3,8]);
             //m_Worksheet.Rows.Delete()
            range.Activate();
            range.EntireRow.Delete(Keys.Shift);
           //m_Worksheet.
          
        }

        //删除一条数据库信息
        public void DelCertainDataBaseInfo(int index)
        {

            //string strCmd = "delete from [DataBaseInfo$] where DataBaseUserName='" + strDatabasename + "'";

            //OleDbConnection myConn = new OleDbConnection(strConn);
            //try
            //{
            //    myConn.Open();
            //    OleDbCommand myCmd = new OleDbCommand(strCmd, myConn);
            //    myCmd.ExecuteNonQuery();
            //}
            //catch (OleDbException OleLexc)
            //{
            //    MessageBox.Show("错误：" + OleLexc);
            //}
            //myConn.Close();
            // Excel.ApplicationClassobjApp = new Excel.ApplicationClass(); 
            string strPath = System.Environment.CurrentDirectory + "\\DBINFO.xls";
           // string strPath = "F:\\风电资料\\程序\\WindCon\\WindCon\\bin\\Debug\\DBINFO.xls";
            Excel.Application myExcel = new Excel.Application();
            myExcel.Visible = false;
            Excel.Workbook m_Workbook = null;
            Excel.Worksheet m_Worksheet = null;

            object objOpt = System.Reflection.Missing.Value;
            m_Workbook = myExcel.Workbooks.Open(strPath, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt, objOpt);
            m_Worksheet = (Excel.Worksheet)m_Workbook.Worksheets.get_Item(1);             

            Excel.Range range = m_Worksheet.get_Range(m_Worksheet.Cells[index, 1], m_Worksheet.Cells[index, 10]); 
            range.Activate();
            range.EntireRow.Delete(Keys.Shift);

            m_Workbook.Save();
            m_Workbook.Close(objOpt, objOpt, objOpt);

            myExcel.Workbooks.Close();
            myExcel.Quit();
           

        }
        //编辑一条数据库信息
        public int EditCertainDataBaseInfo(DataBaseInfo dbi,string strDatabasename)
        {
           
            string strCmd = "update [DataBaseInfo$] set DataBaseUserName='" + dbi.DataBaseUserName +
                "' ,Servername='" + dbi.Servername + "',AuthenticationType=" + dbi.AuthenticationType +
                ",DataBaseName='" + dbi.DataBaseName + "',UserName='" + dbi.UserName + "',UserPassword='" + dbi.Password + "',OnLineServer='" + dbi.OnLineServer + "',OnLineServerPort=" + dbi.OnLineServerPort +
                " where DataBaseUserName='" + strDatabasename + "'";
            string strCmd1 = "select * from [DataBaseInfo$] where DataBaseUserName='" + dbi.DataBaseUserName + "'";
            OleDbDataReader myReader;
            int iFlag = 0;

            OleDbConnection myConn = new OleDbConnection(strConn);
            try
            {
                myConn.Open();
                //先检查数据库名是否重复
                OleDbCommand myCmd;
                if (dbi.DataBaseUserName != strDatabasename)
                {

                    myCmd = new OleDbCommand(strCmd1, myConn);
                    myReader = myCmd.ExecuteReader();
                    if (myReader.Read())
                    {
                        iFlag = 1;
                    }
                }
                if (iFlag == 0)
                {
                    myCmd = new OleDbCommand(strCmd, myConn);
                    myCmd.ExecuteNonQuery();
                }
            }
            catch(OleDbException OleLexc)                
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            myConn.Close();
            return iFlag;

        }
        //添加一条数据库信息
        public int AddDataBaseInfo(DataBaseInfo dbi)
        {
            string strCmd = "insert into [DataBaseInfo$] values('" + dbi.DataBaseUserName + "','" + dbi.Servername + "'," + dbi.AuthenticationType + ",'" + dbi.DataBaseName + "','" + dbi.UserName + "','" + dbi.Password + "','" + dbi.OnLineServer + "'," + dbi.OnLineServerPort + ",0,4)";

            string strCmd1 = "select * from [DataBaseInfo$] where DataBaseUserName='" + dbi.DataBaseUserName + "'";
            OleDbConnection myConn = new OleDbConnection(strConn);
            OleDbDataReader myReader;
            int iFlag = 0;
            try
            {
                myConn.Open();
                //先检查数据库名是否重复
                OleDbCommand myCmd = new OleDbCommand(strCmd1, myConn);
                myReader = myCmd.ExecuteReader();
                if (myReader.Read())
                {
                    iFlag = 1;
                }
                if (iFlag==0)
                {
                    myCmd = new OleDbCommand(strCmd, myConn);
                    myCmd.ExecuteNonQuery();
                }
                
            }
            catch (OleDbException OleLexc)
            {
                MessageBox.Show("错误：" + OleLexc);
            }
            myConn.Close();
            return iFlag;
        }

        //读取所有数据库信息
        public void ReadDataBaseInfo(ref OleDbDataAdapter myAdapter, ref DataTable dt, ref DataView dv)
        {
            string strCmd = "select *  from [DataBaseInfo$]";

            myAdapter = new OleDbDataAdapter(strCmd, strConn);
            OleDbCommandBuilder myBuilder = new OleDbCommandBuilder(myAdapter);
            dt = new DataTable(); 
            myAdapter.Fill(dt);
            dv = new DataView(dt);

  /*    
               
*/
        }

    }
}
