﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;

namespace NetworkTopology
{
    public partial class StatInfoForm : Form
    {
        private int moveCurPosX;
        private int moveCurPosY;

        // public String _title;
        private String NetName = "Whole Network"; //避免更改各处

        public List<Node> mNodes;
        private int m_ShowType; //  0:显示所有节点
        private bool beFirstRun;
        //private bool m_beLegendFlag;

        public DataTable tblDatas;

        public StatInfoForm()
        {
            InitializeComponent();
        }

        public StatInfoForm(List<Node> Nodes)
        {
            InitializeComponent();

            mNodes = Nodes;
            m_ShowType = 0;
            beFirstRun = true;
        }

        private void StatInfoForm_Load(object sender, EventArgs e)
        {
            comboBox_ShowType.Items.Clear();
            comboBox_ShowType.Items.Add(NetName); 
            //List<Node> partNodes = mNodes.FindAll(c => c.M_GatewayIPName.Length > 0);
            //foreach (Node node in partNodes)
            //    comboBox_ShowType.Items.Add(node.M_GatewayIPName);


            checkBox1.Checked = true;
            setControlsPos();
        }

        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            //TDD:Add your code here

            comboBox_ShowType.SelectedIndex = 0;
            computeAndPaintRealize();

            beFirstRun = false;
        }

        void setControlsPos()
        {
            //checkBox1.Left = this.ClientRectangle.Right - checkBox1.Width;

            //ct_coll.Left = this.ClientRectangle.Left;
            //ct_coll.Top = this.ClientRectangle.Top + 40;
            //ct_coll.Width = this.ClientRectangle.Width;
            //ct_coll.Height = this.ClientRectangle.Height;

            //checkBox1.Left = splitContainer1.Panel1.Right - checkBox1.Width;

            //ct_coll.Left = splitContainer1.Panel2.Left;
            //ct_coll.Top = splitContainer1.Panel2.Top;
            //ct_coll.Width = splitContainer1.Panel2.Width;
            //ct_coll.Height = splitContainer1.Panel2.Height;

            //splitContainer1.SplitterDistance = 25;
        }


        private void comboBox_ShowType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!beFirstRun)
                computeAndPaintRealize();
        }

        //private void computeAndPaint()
        //{
            
        //    //Cursor = Cursors.WaitCursor;
        //    //Thread bg_StatInfo = new Thread(computeAndPaintRealize);
        //    //bg_StatInfo.IsBackground = true;
        //    //bg_StatInfo.Start();
        //    //bg_StatInfo.Join();
        //    //bg_StatInfo.Abort();

        //    //Cursor = Cursors.Default;
        //}

        private void computeAndPaintRealize()
        {
            Cursor = Cursors.WaitCursor;
           
            GetNetStatInfo();
            ViewChart(tblDatas, "_title");

            Cursor = Cursors.Default;
        }

        private void GetNetStatInfo()
        {
            int[] typeNo = new int[5];
            if (comboBox_ShowType.Text == NetName)
            {
                //int temp = mNodes.FindAll(c => c.M_ID.StartsWith("HC_")).Count;
                //typeNo[0] = 0; //一级节点
                //typeNo[1] = temp - 1; //二级节点

                //三级节点
                typeNo[0] = mNodes.FindAll(c => c.M_type == "0x0001").Count;

                //四级节点
                typeNo[1] = mNodes.FindAll(c => c.M_type == "0x0002").Count; //主要二级节点的类型也为2

                //五级节点
                typeNo[2] = mNodes.FindAll(c => c.M_type == "0x0003").Count; //主要一级节点的类型也为3
            }
            //else
            //{
            //    typeNo[0] = 0; //一级节点
            //    typeNo[1] = 0; //二级节点

            //    Node tempNode = mNodes.Find(c => c.M_GatewayIPName == comboBox_ShowType.Text);
            //    String m_PartID = tempNode.M_ID.Substring(0, tempNode.M_ID.IndexOf('_'));

            //    //三级节点
            //    typeNo[2] = mNodes.FindAll(c => c.M_type == "0x0001").Count;

            //    //四级节点
            //    typeNo[3] = mNodes.FindAll(c => c.M_type == "0x0002").Count;

            //    //五级节点
            //    typeNo[4] = mNodes.FindAll(c => c.M_type == "0x0003").Count;
            //}

            if (tblDatas != null)
                tblDatas.Clear();
            tblDatas =new DataTable("Datas");

            DataColumn columnname = new DataColumn("columnname", typeof(String));   //数据类型为 整形
            DataColumn columndata = new DataColumn("columndata", typeof(String)); //数据类型为 时间
            tblDatas.Columns.Add(columnname);
            tblDatas.Columns.Add(columndata);



            //tblDatas.Columns.Add("columnname");  //, System.Type.GetType("System.String")
            //tblDatas.Columns[0].AutoIncrement = true;
            //tblDatas.Columns[0].AutoIncrementSeed = 1;
            //tblDatas.Columns[0].AutoIncrementStep = 1;
            //tblDatas.Columns.Add("columndata"); //, System.Type.GetType("System.String")

            for (int i = 0; i < typeNo.Length; i++)
            {
                //    tblDatas.Rows.Add(new object[] { Convert.ToString(i + 1) + "类节点", Convert.ToString(typeNo[i]) });
                DataRow dr2 = tblDatas.NewRow();
                dr2["columnname"] = Convert.ToString(i + 1) + "类节点"; //通过名称赋值
                dr2["columndata"] = Convert.ToString(typeNo[i]); //通过名称赋值
                tblDatas.Rows.Add(dr2);
            }
        }


        //饼图   dt数据结构为 columndata(数据)  columnname(文本) 这两列  
        private void ViewChart(DataTable _dt, string _title)
        {
            this.ct_coll.Series.Clear();
            this.ct_coll.Legends.Clear();

            this.ct_coll.Series.Add(new Series("Data"));
            this.ct_coll.Legends.Add(new Legend("Stores")); //右边标签列  

            this.ct_coll.Series["Data"].ChartType = SeriesChartType.Pie;
            this.ct_coll.Series["Data"]["PieLabelStyle"] = "Outside";//Inside 数值显示在圆饼内 Outside 数值显示在圆饼外 Disabled 不显示数值  

            this.ct_coll.Series["Data"]["PieLineColor"] = "Blue"; // Black


            //this.ct_coll.Series["Data"].IsValueShownAsLabel = true;
            //this.ct_coll.Series["Data"].IsVisibleInLegend = true;
            //this.ct_coll.Series["Data"].ShadowOffset = 1;//阴影偏移量
            this.ct_coll.Series["Data"].ToolTip = "#VAL{D} 个";//鼠标移动到上面显示的文字  
            this.ct_coll.Series["Data"].BackSecondaryColor = Color.DarkCyan;
            this.ct_coll.Series["Data"].BorderColor = Color.DarkOliveGreen;
            this.ct_coll.Series["Data"].LabelBackColor = Color.Transparent;

            foreach (DataRow dr in _dt.Rows)
            {
                if (Convert.ToDouble(dr["columndata"].ToString()) < 1)
                    continue;
                int ptIdx = this.ct_coll.Series["Data"].Points.AddY(Convert.ToDouble(dr["columndata"].ToString()));
                DataPoint pt = this.ct_coll.Series["Data"].Points[ptIdx];
                pt.LegendText = dr["columnname"].ToString() + " " + "#PERCENT{P2}" + " [ " + "#VAL{D} 个" + " ]";//右边标签列显示的文字  
                pt.Label = dr["columnname"].ToString() + " " + "#PERCENT{P2}" + " [ " + "#VAL{D} 个" + " ]"; //圆饼外显示的信息  

                //  pt.LabelToolTip = "#PERCENT{P2}";  
                //pt.LabelBorderColor = Color.Red;//文字背景色   
            }

            // this.ct_coll.Series["Data"].Label = "#PERCENT{P2}"; //  
            this.ct_coll.Series["Data"].Font = new Font("Segoe UI", 8.0f, FontStyle.Bold);
            this.ct_coll.Series["Data"].Legend = "Stores"; //右边标签列显示信息  


            this.ct_coll.Legends["Stores"].Enabled = checkBox1.Checked;
            if (checkBox1.Checked)
            {
                this.ct_coll.Legends["Stores"].Alignment = StringAlignment.Center;
                this.ct_coll.Legends["Stores"].Alignment = StringAlignment.Center;
                this.ct_coll.Legends["Stores"].HeaderSeparator = System.Windows.Forms.DataVisualization.Charting.LegendSeparatorStyle.ThickLine;
            }

            this.ct_coll.Titles.Clear();
            //if (this.ct_coll.Titles.Count > 0)
            //    this.ct_coll.Titles[0].Text = _title;
            //this.ct_coll.ChartAreas["ChartArea1"].AxisX.IsMarginVisible = false;
            //this.ct_coll.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;

            //int int_count = _dt.AsEnumerable().Select(t => t.Field<int>("columndata")).Sum();
            //if (this.ct_coll.Titles.Count > 0)
            //    this.ct_coll.Titles[1].Text = "总个数: " + int_count.ToString("0.00") + " 个";

 /*
  #VALX      显示当前图例的X轴的对应文本(或数据) 
  #VAL, #VALY,  显示当前图例的Y轴的对应文本(或数据) 
  #VALY2, #VALY3, 显示当前图例的辅助Y轴的对应文本(或数据) 
  #SER:      显示当前图例的名称 
  #LABEL       显示当前图例的标签文本 
  #INDEX      显示当前图例的索引 
  #PERCENT       显示当前图例的所占的百分比 
  #TOTAL      总数量 
  #LEGENDTEXT      图例文本
  * 
 */
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (tblDatas != null)
                ViewChart(tblDatas, "_title");
        }

        private void StatInfoForm_Resize(object sender, EventArgs e)
        {
            setControlsPos();
        }

        private void ct_coll_SizeChanged(object sender, EventArgs e)
        {
            panel1.Top = this.ClientRectangle.Top;
            panel1.Left = this.ClientRectangle.Left;
            panel1.Width = this.ClientRectangle.Width;

            ct_coll.Top = panel1.Bottom;
            ct_coll.Left = this.ClientRectangle.Left;
            ct_coll.Width = this.ClientRectangle.Width;
            ct_coll.Height = this.ClientRectangle.Bottom - ct_coll.Top;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                moveCurPosX = e.X;
                moveCurPosY = e.Y;
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + (e.X - moveCurPosX), this.Location.Y + (e.Y - moveCurPosY));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;//最小化
        }
    }
}
