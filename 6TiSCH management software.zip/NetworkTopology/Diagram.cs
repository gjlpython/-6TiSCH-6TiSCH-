﻿// A Force-Directed Diagram Layout Algorithm
// Bradley Smith - 2010/07/01

using System;
using System.Collections.Generic;
using System.Drawing;
using ForceDirected;

using Graphic;
using System.Windows.Forms;
using NetworkTopology;
using System.Data;
using System.Reflection;

/// <summary>
/// Represents a simple diagram consisting of nodes and connections, implementing a 
/// force-directed algorithm for automatically arranging the nodes.
/// </summary>
public class Diagram
{

    public bool beSimulationFlag = false;
    public bool beEnableRecoredOper = false;
    public bool beEffectiveData = false;

    public bool beShowDiaoDu = false;
    public String src_comboBoxText;
    public String dst_comboBoxText;

    public List<Node> mNodes;
    public List<NodePair> mRouteNode;

    //public ScreenInfo si; //绘图设置
    public ScreenSettingInfo screenSettingInfo; //绘图设置

    public int m_dGV_MaterialShowType; // 0：路由 1：超帧  2：链路  3：交换机流表

    //动画显示用
    public double PosPercIncrement = 0.05;
    public double PosPercentage = 0;
    public int RGBIncrement = 20;

    public int[] m_RGBPlotSetting;

    public DataLinkInfo linkSet;
    public bool m_beArrangeWithForceDirect;

    List<panid> mpanidList;

    private string[] RouteFormArr = { "RouteID", "src", "dst", "next" };
    private string[] SuperframeFormArr = { "SuperframeID", "ActiveFlag", "ActiveSlot", "NumberSlots", "SuperframeMultiple" };
    private string[] LinkFormArr = { "LinkID", "LinkType", "ChannelIndex", "LinkSuperFrameNum", "SuperframeID", "RelativeSlotNumber", "ActiveFlag", "NeighborID" };
    private string[] StatsFlowFormArr = { "dpid", "actions", "idle_timeout", "cookie", "packet_count", "hard_timeout", "byte_count", "duration_sec", "duration_nsec", "priority", "length", "flags", "table_id", "match" };


    private String OperationInfoHeader; //路由表 超帧 链路 交换机流表 

    public DataTable RouteDt;
    public DataTable SuperframeDt;
    public DataTable LinkFormDt;

    public DataTable StatsFlowDt;

    public int OperationToDo;
    public DataTable partOperDt;

    private const double ATTRACTION_CONSTANT = 0.1;		// spring constant
    private const double REPULSION_CONSTANT = 10000;	// charge constant
    public const double DEFAULT_DAMPING = 0.5;
    public const int DEFAULT_SPRING_LENGTH = 100;
    public const int DEFAULT_MAX_ITERATIONS = 5000;
    //CommonSettings m_settings = new CommonSettings();

    /// <summary>
    /// Gets a read-only collection of the nodes in this Diagram.
    /// </summary>
    public IList<Node> Nodes
    {
        get
        {
            return mNodes.AsReadOnly();
        }
    }


    //public GScenario GTopology;
    public GScenario GPlotTopology;
    public int CurrObjDragIndx = -1;



    private const int XTextPixelOffset = 0;
    private const int YTextPixelOffset = 0; //80
    private const int XManageFormPixelOffset = 10;
    private const int YManageFormPixelOffset = 10;
    //private int CurrObjDragIndx = 0;
    private int Xdown = 0;
    private int Ydown = 0;
    private DateTime Tdown;
    //private int DragTimeMin = 100; // milliseconds
    private bool Dragging = false;

    Rectangle m_GrapBounds; // 绘图区域大小
    Rectangle m_logicalBounds;// 逻辑绘图区域大小

    Point m_GrapCenter; // 绘图区域中心


    private double m_PlotingScaleX = 1.0;
    private double m_PlotingScaleY = 1.0;

    private double m_PlotingMoveX = 0;
    private double m_PlotingMoveY = 0;
    private double m_PlotingEdgeSpace = 25;  //边界空白留多大



    internal System.Windows.Forms.ImageList DiagramImageList;

    private bool m_reInitializeFlag = true;

    //路由表 超帧 链路 交换机流表 
    public String M_OperationInfoHeader
    {
        get { return OperationInfoHeader; }
        set { OperationInfoHeader = value; }
    }

    /// <summary>
    /// 设置与获取graphics的区域大小
    /// </summary>
    public Rectangle M_GrapBounds
    {
        get { return m_GrapBounds; }
        set { m_GrapBounds = value; }
    }

    public Rectangle logicalBounds
    {
        get { return m_logicalBounds; }
        set { m_logicalBounds = value; }
    }

    /// <summary>
    /// 设置与获取graphics的区域大小
    /// </summary>
    public Point M_GrapCenter
    {
        get { return new Point(0, 0); }
        //get { return new Point(M_GrapBounds.X + (M_GrapBounds.Width / 2), M_GrapBounds.Y + (M_GrapBounds.Height / 2)); }
    }

    /// <summary>
    /// 力导向计算过程，是否进行随机初始化
    /// </summary>
    public bool M_reInitializeFlag
    {
        get { return m_reInitializeFlag; }
        set { m_reInitializeFlag = value; }
    }



    ///// <summary>
    ///// 设置与获取绘图比例
    ///// </summary>
    //public double M_PlotingScale
    //{
    //    get { return m_PlotingScale; }
    //    set { m_PlotingScale = value; }
    //}


    /// <summary>
    /// Initialises a new instance of the Diagram class.
    /// </summary>
    public Diagram()
    {
        mNodes = new List<Node>();
        mRouteNode = new List<NodePair>();

        screenSettingInfo.beLegend = true;
        screenSettingInfo.beNodeConnectorName = true;
        screenSettingInfo.beNodeName = true;

        m_dGV_MaterialShowType = 0; //dataGridView_Material 显示数据类型
        m_RGBPlotSetting = new int[6];
        Random rnd = new Random();
        m_RGBPlotSetting[0] = rnd.Next(0, 255);
        m_RGBPlotSetting[1] = rnd.Next(0, 255);
        m_RGBPlotSetting[2] = rnd.Next(0, 255);
        m_RGBPlotSetting[3] = rnd.Next(0, 255);
        m_RGBPlotSetting[4] = rnd.Next(0, 255);
        m_RGBPlotSetting[5] = rnd.Next(0, 255);

        mpanidList = new List<panid>();


        RouteDt = new DataTable();
        foreach (string str in RouteFormArr)
            RouteDt.Columns.Add(str, typeof(string));

        SuperframeDt = new DataTable();
        foreach (string str in SuperframeFormArr)
            SuperframeDt.Columns.Add(str, typeof(string));

        LinkFormDt = new DataTable();
        foreach (string str in LinkFormArr)
            LinkFormDt.Columns.Add(str, typeof(string));

        StatsFlowDt = new DataTable();
        foreach (string str in StatsFlowFormArr)
            StatsFlowDt.Columns.Add(str, typeof(string));


        linkSet.ServerName = "192.168.1.102";
        linkSet.ServerPort = "8080";

        //linkSet.SDNIPName = "192.168.1.102";
        //linkSet.SDNPort = "8080";


        //GTopology = new GScenario();
        //GTopology.Clear();
        //GTopology.CurrObjIndx = -1;
        GPlotTopology = new GScenario();
        GPlotTopology.Clear();
        GPlotTopology.CurrObjIndx = -1;


        // m_GrapBounds = Rectangle.FromLTRB(-50, -50, 100, 100);
        // m_GrapBounds = Rectangle.FromLTRB(0, 0, 100, 100);

        // Construct the ImageList.
        DiagramImageList = new ImageList();
    }

    /// <summary>
    /// Adds the specified Node to this Diagram.
    /// </summary>
    /// <param name="node">The Node to add to the diagram.</param>
    /// <returns>True if the node was added, false if the node is already on this Diagram.</returns>
    public bool AddNode(Node node) //ref List<GObject> refGObjects
    {
        if (node == null) throw new ArgumentNullException("node");

        if (!mNodes.Contains(node))
        {
            // add node, associate with diagram, then add all connected nodes
            mNodes.Add(node);
            node.Diagram = this;

            //GTopology.GObjects.Add(new GObject(node.M_strName, (node.M_type).ToString(),
            //                        node.X, node.Y, "", node.X + 10, node.Y + 10, ""));


            foreach (Node child in node.Connections) AddNode(child);
            return true;
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// Runs the force-directed layout algorithm on this Diagram, using the default parameters.
    /// </summary>
    public void Arrange()
    {
        if (beEffectiveData)
        {
            if (m_beArrangeWithForceDirect)
                ArrangeWithForceDirect(DEFAULT_DAMPING, DEFAULT_SPRING_LENGTH, DEFAULT_MAX_ITERATIONS, true);
            else
                ArrangeBySpecfifyPos();
        }
    }

    /// <summary>
    /// Runs the force-directed layout algorithm on this Diagram, offering the option of a random or deterministic layout.
    /// </summary>
    /// <param name="deterministic">Whether to use a random or deterministic layout.</param>
    public void ArrangeWithForceDirect(bool deterministic)
    {
        ArrangeWithForceDirect(DEFAULT_DAMPING, DEFAULT_SPRING_LENGTH, DEFAULT_MAX_ITERATIONS, deterministic);
    }


    public void GetSchedulingLinkInfo()
    {
        String srcID = src_comboBoxText;
        String dstID = dst_comboBoxText;
        Node srcNode = mNodes.Find(c => c.M_ID == srcID);
        Node dstNode = mNodes.Find(c => c.M_ID == dstID);


        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;

        tcpOper.GetSchedulingLinkInfo(linkSet, srcNode, dstNode, ref mRouteNode);
    }

    public void GetObjLuYouBiao()
    {
        //mNodes[CurrObjDragIndx].mWIAPALuYou.Clear();
        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode == null)
            return;

        operNode.mWIAPALuYou.Clear();

        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;

        //获取panid
        int networkInfoType = 4;
        tcpOper.GetObjLuYouBiao(networkInfoType, linkSet, operNode.M_ID, ref operNode.mWIAPALuYou);
    }


    public void GetObjStatsFlowBiao()
    {
        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode == null)
            return;

        operNode.mStatsFlow.Clear();

        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;

        //获取panid
        int networkInfoType = 7;
        tcpOper.GetObjStatsFlowBiao(networkInfoType, linkSet, operNode.M_ID, ref operNode.mStatsFlow);
    }

    public void GetObjChaoZhenBiao()
    {
        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode == null)
            return;

        operNode.mWIAPAChaoZhen.Clear();

        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;

        //获取panid
        int networkInfoType = 4;
        tcpOper.GetObjChaoZhenBiao(networkInfoType, linkSet, operNode.M_ID, ref operNode.mWIAPAChaoZhen);
    }

    public void GetObjLianLuBiao()
    {
        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode == null)
            return;

        operNode.mWIAPALianLu.Clear();

        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;

        //获取panid
        int networkInfoType = 4;
        tcpOper.GetObjLianLuBiao(networkInfoType, linkSet, operNode.M_ID, ref operNode.mWIAPALianLu);
    }

    public void SetObjLuYouBiao()
    {
        if (RouteDt.IsInitialized)
        {
            RouteDt = new DataTable();
            foreach (string str in RouteFormArr)
                RouteDt.Columns.Add(str, typeof(string));
        }

        //RouteDt.Clear();

        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode == null)
            return;
        foreach (WIAPALuYou LuYouInfo in operNode.mWIAPALuYou)
        {
            DataRow dr = RouteDt.NewRow();
            //for (int i = 0; i<strArr.Count;i++)
            dr["RouteID"] = LuYouInfo.RoutedID;
            dr["src"] = LuYouInfo.partWIAPALuYou.src;
            dr["dst"] = LuYouInfo.partWIAPALuYou.dst;
            dr["next"] = LuYouInfo.partWIAPALuYou.next;
            RouteDt.Rows.Add(dr);
        }
    }


    public void SetObjStatsFlowBiao()
    {
        if (StatsFlowDt.IsInitialized)
        {
            StatsFlowDt = new DataTable();
            foreach (string str in StatsFlowFormArr)
                StatsFlowDt.Columns.Add(str, typeof(string));
        }

        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode != null)
        {
            foreach (StatsFlow StatsFlowInfo in operNode.mStatsFlow)
            {
                DataRow dr = StatsFlowDt.NewRow();
                //for (int i = 0; i<strArr.Count;i++)
                dr["dpid"] = StatsFlowInfo.dpid;
                dr["actions"] = "[\r\"" + String.Join("\",\r", StatsFlowInfo.partStatsFlow.actions) + "\"\r]"; //字符串数组转字符串
                dr["idle_timeout"] = StatsFlowInfo.partStatsFlow.idle_timeout;
                dr["cookie"] = StatsFlowInfo.partStatsFlow.cookie;
                dr["packet_count"] = StatsFlowInfo.partStatsFlow.packet_count;
                dr["hard_timeout"] = StatsFlowInfo.partStatsFlow.hard_timeout;

                dr["byte_count"] = StatsFlowInfo.partStatsFlow.byte_count;
                dr["duration_sec"] = StatsFlowInfo.partStatsFlow.duration_sec;
                dr["duration_nsec"] = StatsFlowInfo.partStatsFlow.duration_nsec;


                dr["priority"] = StatsFlowInfo.partStatsFlow.priority;
                dr["length"] = StatsFlowInfo.partStatsFlow.length;
                dr["flags"] = StatsFlowInfo.partStatsFlow.flags;

                dr["table_id"] = StatsFlowInfo.partStatsFlow.table_id;
                dr["match"] = StatsFlowInfo.partStatsFlow.match;

                StatsFlowDt.Rows.Add(dr);
            }
        }
    }


    public void SetWIAPABiao(int OperationToDo, int subOperationToDo, DataTable partOperDt)
    {
        this.OperationToDo = OperationToDo;
        this.partOperDt = partOperDt;

        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;

        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode != null)
        {
            if (OperationToDo == 0)
                tcpOper.setLuYouBiao(linkSet, operNode.M_ID, partOperDt);
            else if (OperationToDo == 1)
                tcpOper.setChaoZhenBiao(linkSet, operNode.M_ID, partOperDt);
            else if (OperationToDo == 2)
                tcpOper.setLianLuBiao(linkSet, operNode.M_ID, partOperDt);
            else if (OperationToDo == 3)
                tcpOper.setStatsFlowBiao(linkSet, operNode.M_ID, subOperationToDo, partOperDt);
            else
                tcpOper.setLianLuBiao(linkSet, operNode.M_ID, partOperDt);
        }
    }


    public void SetObjChaoZhenBiao()
    {
        if (SuperframeDt.IsInitialized)
        {
            SuperframeDt = new DataTable();
            foreach (string str in SuperframeFormArr)
                SuperframeDt.Columns.Add(str, typeof(string));
        }

        //SuperframeDt.Clear();

        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode != null)
        {
            foreach (WIAPAChaoZhen LuYouInfo in operNode.mWIAPAChaoZhen)
            {
                DataRow dr = SuperframeDt.NewRow();
                //for (int i = 0; i<strArr.Count;i++)
                dr["SuperframeID"] = LuYouInfo.SuperframeID;
                dr["ActiveFlag"] = LuYouInfo.partWIAPAChaoZhen.ActiveFlag;
                dr["ActiveSlot"] = LuYouInfo.partWIAPAChaoZhen.ActiveSlot;
                dr["NumberSlots"] = LuYouInfo.partWIAPAChaoZhen.NumberSlots;
                dr["SuperframeMultiple"] = LuYouInfo.partWIAPAChaoZhen.SuperframeMultiple;
                SuperframeDt.Rows.Add(dr);
            }
        }
    }

    public void SetObjLianLuBiao()
    {
        if (LinkFormDt.IsInitialized)
        {
            LinkFormDt = new DataTable();
            foreach (string str in LinkFormArr)
                LinkFormDt.Columns.Add(str, typeof(string));
        }

        // LinkFormDt.Clear();
        Node operNode = mNodes.Find(c => c.M_ID == GPlotTopology.GObjects[CurrObjDragIndx].m_ID);
        if (operNode != null)
        {
            foreach (WIAPALianLu LuYouInfo in operNode.mWIAPALianLu)
            {
                DataRow dr = LinkFormDt.NewRow();
                //for (int i = 0; i<strArr.Count;i++)
                dr["LinkID"] = LuYouInfo.LinkID;
                dr["LinkType"] = LuYouInfo.partWIAPALianLu.LinkType;
                dr["ChannelIndex"] = LuYouInfo.partWIAPALianLu.ChannelIndex;
                dr["LinkSuperFrameNum"] = LuYouInfo.partWIAPALianLu.LinkSuperFrameNum;
                dr["SuperframeID"] = LuYouInfo.partWIAPALianLu.SuperframeID;
                dr["RelativeSlotNumber"] = LuYouInfo.partWIAPALianLu.RelativeSlotNumber;
                dr["ActiveFlag"] = LuYouInfo.partWIAPALianLu.ActiveFlag;
                dr["NeighborID"] = LuYouInfo.partWIAPALianLu.NeighborID;

                LinkFormDt.Rows.Add(dr);
            }
        }
    }

        /// <summary>
    /// 获取网络节点信息
    /// </summary>
    public void GetNetworkTopology_recvData(String recvData)
    {
        this.Clear();
        //lock (mNodes)
        //{
        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;
        tcpOper.beEnableRecoredOper = this.beEnableRecoredOper;


        //解析拓扑信息
        List<WIAPATopology2> WIAPATopologyList = new List<WIAPATopology2>();
        tcpOper.getTopology_networksTopologyList_recvData(ref WIAPATopologyList, recvData);
        TopologyListToNode_recvData(WIAPATopologyList);

        if (mNodes.Count < 50)
            m_beArrangeWithForceDirect = false;
        //}
        beEffectiveData = true;
    }

    /// <summary>
    /// 获取网络节点信息
    /// </summary>
    public void GetNetworkTopology()
    {
        this.Clear();
        //lock (mNodes)
        //{
        TCPOper tcpOper = new TCPOper();
        tcpOper.beSimulationFlag = this.beSimulationFlag;
        tcpOper.beEnableRecoredOper = this.beEnableRecoredOper;

        //获取panid
        mpanidList = new List<panid>();
        tcpOper.getWIAPAPanidList(linkSet, ref mpanidList);

        //获取WIA-PA拓扑信息
        List<WIAPATopology2> WIAPATopologyList;
        int networkInfoType = 2;
        if (mpanidList.Count > 0)
        {
            foreach (panid m_panid in mpanidList)
            {
                WIAPATopologyList = new List<WIAPATopology2>();
                tcpOper.getWIAPATopology_networksTopologyList(networkInfoType, linkSet, m_panid.PanidID, ref WIAPATopologyList);
                TopologyListToNode(m_panid, WIAPATopologyList);
            }
        }


        //获取回程网络拓扑信息
        networkInfoType = 3;
        WIAPATopologyList = new List<WIAPATopology2>();
        tcpOper.getWIAPATopology_networksTopologyList(networkInfoType, linkSet, "", ref WIAPATopologyList);
        panid temppanid = new panid();
        temppanid.PanidID = "HC";
        temppanid.GatewayIP = "";
        HuiChengWangTopologyListToNode(temppanid, WIAPATopologyList);

        if (mNodes.Count < 50)
            m_beArrangeWithForceDirect = false;
        //}
        beEffectiveData = true;
    }

    private Color GetNodeColor(string category)
    {
        Color temp = Color.DeepSkyBlue;
        switch (category)
        {
            case "1":
                temp = Color.Red;
                break;
            case "2":
                temp = Color.Green;
                break;
            case "3":
                temp = Color.Blue;
                break;
        }
        return temp;
    }

    private void TopologyListToNode_recvData(List<WIAPATopology2> WIAPATopologyList)
    {
        //int nodeID = Nodes.Count + 1;
        Node tempNodeSrc = null;
        Node tempNodeDst = null;
        foreach (WIAPATopology2 topnode in WIAPATopologyList)
        {
            tempNodeSrc = mNodes.Find(c => c.M_ID == topnode.src.address);

            if (tempNodeSrc == null)
            {
                Node child = new SpotNode(topnode.src.address, GetNodeColor(topnode.src.category));
                child.M_strName = topnode.src.address;
                //child.M_GatewayIPName = mPanid.GatewayIP;
                child.M_type = topnode.src.category;

                child.m_WIAPA_networks = 0;
                //child.mPanid = null;
                this.AddNode(child);

                tempNodeDst = mNodes.Find(c => c.M_ID == topnode.dst.address);
                if (tempNodeDst == null)
                {
                    Node grandchild = new SpotNode(topnode.dst.address, GetNodeColor(topnode.dst.category));
                    grandchild.M_strName = topnode.dst.address;
                    grandchild.M_type = topnode.dst.category;

                    grandchild.m_WIAPA_networks = 1;
                    //grandchild.mPanid = null;
                    child.AddChild(grandchild);
                }
                else
                {
                    tempNodeDst.m_WIAPA_networks = 1;
                    //tempNodeDst.mPanid = null;

                    child.AddChild(tempNodeDst);
                }
            }
            else
            {
                tempNodeDst = mNodes.Find(c => c.M_ID == topnode.dst.address);

                if (tempNodeDst == null)
                {
                    Node grandchild = new SpotNode(topnode.dst.address, GetNodeColor(topnode.dst.category));
                    grandchild.M_strName = topnode.dst.address;
                    grandchild.M_type = topnode.dst.category;

                    grandchild.m_WIAPA_networks = 1;
                    //grandchild.mPanid = mPanid;
                    tempNodeSrc.AddChild(grandchild);
                }
                else
                {
                    tempNodeDst.m_WIAPA_networks = 1;
                    //tempNodeDst.mPanid = mPanid;
                    tempNodeSrc.AddChild(tempNodeDst);
                }
            }
        }
    }

    private void TopologyListToNode(panid mPanid, List<WIAPATopology2> WIAPATopologyList)
    {
        //int nodeID = Nodes.Count + 1;
        Node tempNodeSrc = null;
        Node tempNodeDst = null;
        foreach (WIAPATopology2 topnode in WIAPATopologyList)
        {
            tempNodeSrc = mNodes.Find(c => c.M_ID == mPanid.PanidID + "_" + topnode.src.address);

            if (tempNodeSrc == null)
            {
                Node child = new SpotNode(mPanid.PanidID + "_" + topnode.src.address, GetNodeColor(topnode.src.category));
                child.M_strName = topnode.src.address;
                child.M_GatewayIPName = mPanid.GatewayIP;
                child.M_type = topnode.src.category;

                child.m_WIAPA_networks = 0;
                child.mPanid = mPanid;
                this.AddNode(child);

                tempNodeDst = mNodes.Find(c => c.M_ID == mPanid.PanidID + "_" + topnode.dst.address);
                if (tempNodeDst == null)
                {
                    Node grandchild = new SpotNode(mPanid.PanidID + "_" + topnode.dst.address, GetNodeColor(topnode.dst.category));
                    grandchild.M_strName = topnode.dst.address;
                    grandchild.M_type = topnode.dst.category;

                    grandchild.m_WIAPA_networks = 1;
                    grandchild.mPanid = mPanid;
                    child.AddChild(grandchild);
                }
                else
                {
                    tempNodeDst.m_WIAPA_networks = 1;
                    tempNodeDst.mPanid = mPanid;

                    child.AddChild(tempNodeDst);
                }
            }
            else
            {
                tempNodeDst = mNodes.Find(c => c.M_ID == mPanid.PanidID + "_" + topnode.dst.address);

                if (tempNodeDst == null)
                {
                    Node grandchild = new SpotNode(mPanid.PanidID + "_" + topnode.dst.address, GetNodeColor(topnode.dst.category));
                    grandchild.M_strName = topnode.dst.address;
                    grandchild.M_type = topnode.dst.category;

                    grandchild.m_WIAPA_networks = 1;
                    grandchild.mPanid = mPanid;
                    tempNodeSrc.AddChild(grandchild);
                }
                else
                {
                    tempNodeDst.m_WIAPA_networks = 1;
                    tempNodeDst.mPanid = mPanid;
                    tempNodeSrc.AddChild(tempNodeDst);
                }
            }
        }
    }


    private void HuiChengWangTopologyListToNode(panid mPanid, List<WIAPATopology2> WIAPATopologyList)
    {
        Node tempNodeSrc = null;
        Node tempNodeDst = null;
        foreach (WIAPATopology2 topnode in WIAPATopologyList)
        {
            if (topnode.src.category == "3")
                tempNodeSrc = mNodes.Find(c => c.M_GatewayIPName == topnode.src.address);
            else
                tempNodeSrc = mNodes.Find(c => c.M_ID == mPanid.PanidID + "_" + topnode.src.address);
            if (tempNodeSrc == null)
            {
                Node child = new SpotNode(mPanid.PanidID + "_" + topnode.src.address, GetNodeColor(topnode.src.category));
                child.M_strName = topnode.src.address;
                //child.M_GatewayIPName = mPanid.GatewayIP;
                child.M_type = topnode.src.category;

                child.m_WIAPA_networks = 1;
                child.mPanid = mPanid;
                this.AddNode(child);


                if (topnode.dst.category == "3")
                    tempNodeDst = mNodes.Find(c => c.M_GatewayIPName == topnode.dst.address);
                else
                    tempNodeDst = mNodes.Find(c => c.M_ID == mPanid.PanidID + "_" + topnode.dst.address);
                if (tempNodeDst == null)
                {
                    Node grandchild = new SpotNode(mPanid.PanidID + "_" + topnode.dst.address, GetNodeColor(topnode.dst.category));
                    grandchild.M_strName = topnode.dst.address;
                    grandchild.M_type = topnode.dst.category;

                    grandchild.m_WIAPA_networks = 1;
                    grandchild.mPanid = mPanid;
                    child.AddChild(grandchild);
                }
                else
                {
                    tempNodeDst.m_WIAPA_networks = 1;
                    tempNodeDst.mPanid = mPanid;
                    child.AddChild(tempNodeDst);
                }
            }
            else
            {
                if (topnode.dst.category == "3")
                    tempNodeDst = mNodes.Find(c => c.M_GatewayIPName == topnode.dst.address);
                else
                    tempNodeDst = mNodes.Find(c => c.M_ID == mPanid.PanidID + "_" + topnode.dst.address);
                if (tempNodeDst == null)
                {
                    Node grandchild = new SpotNode(mPanid.PanidID + "_" + topnode.dst.address, GetNodeColor(topnode.dst.category));
                    grandchild.M_strName = topnode.dst.address;
                    grandchild.M_type = topnode.dst.category;

                    grandchild.m_WIAPA_networks = 1;
                    grandchild.mPanid = mPanid;
                    tempNodeSrc.AddChild(grandchild);
                }
                else
                {
                    tempNodeDst.m_WIAPA_networks = 1;
                    tempNodeDst.mPanid = mPanid;
                    tempNodeSrc.AddChild(tempNodeDst);
                }
            }
        }
    }


    /// <summary>
    /// 直接根据节点类型进行排列
    /// </summary>
    public void ArrangeBySpecfifyPos()
    {
        int[] typeNo = null;
        List<Node>[] nodeList = null;

        //获取每一类型的
        GetNetStatInfo(ref nodeList, ref typeNo);

        // 确定有效的level数目
        int EffecLevels = 0;
        foreach (int num in typeNo)
        {
            if (num > 0)
                EffecLevels++;
        }

        
        for (int index = 0; index < typeNo.Length; index++)
        {
            if (nodeList[index].Count == 0)
                continue;

            //if (index == 2 || typeNo[index] <= 0)
            //    continue;

                //按照m_ID进行排序
                nodeListArray(ref nodeList[index]);

                //Node tempNode = null;
                //String str1 = null;
                //String str2 = null;

                //for (int i = 0; i < nodeList[index].Count - 1; i++)
                //{
                //    for (int j = nodeList[index].Count - 1; j > i; j--)
                //    {
                //        str1 = nodeList[index][i].M_ID;
                //        if (str1.Contains("HC_"))
                //            str1 = str1.Remove(0, 3);
                //        else
                //            str1 = str1.Remove(str1.IndexOf('_'), 1);

                //        str2 = nodeList[index][j].M_ID;
                //        if (str2.Contains("HC_"))
                //            str2 = str2.Remove(0, 3);
                //        else
                //            str2 = str2.Remove(str2.IndexOf('_'), 1);

                //        if (Convert.ToInt32(str1) > Convert.ToInt32(str2))
                //        {
                //            tempNode = nodeList[index][j];
                //            nodeList[index][j] = nodeList[index][i];
                //            nodeList[index][i] = tempNode;
                //        }
                //    }
                //}
                nodeListposSetting(ref nodeList[index], EffecLevels, index); 
        }


        List<Node> tempNodeList = mNodes.FindAll(c => c.M_ID.StartsWith("0x") && c.M_ID != "0x0000");
        List<Node> reorderList = new List<Node>();
        foreach (Node node in nodeList[2])
        {
            bool foundFlag = false;
            for (int j = 0; j < tempNodeList.Count; j++)
            {
                for (int k = 0; k < tempNodeList[j].Connections.Count; k++)
                {
                    if (node.M_ID == tempNodeList[j].Connections[k].M_ID)
                    {
                        if (reorderList.FindAll(c => c.M_ID == tempNodeList[j].M_ID).Count <= 0)
                            reorderList.Add(tempNodeList[j]);
                        foundFlag = true;
                        break;
                    }
                }
                if (foundFlag)
                    break;
            }
        }


        List<Node> unConnectedNodeList = new List<Node>();
        foreach (Node node in tempNodeList)
        {
            if (reorderList.FindAll(c => c.M_ID == node.M_ID).Count < 1)
                unConnectedNodeList.Add(node);
        }
        reorderList.InsertRange((int)(reorderList.Count/2.0), unConnectedNodeList);

        nodeList[1] = reorderList;
        nodeListposSetting(ref nodeList[1], EffecLevels, 1); 

        // center the diagram around the origin
        //Rectangle logicalBounds = GetDiagramBounds();
        //Point midPoint = new Point(logicalBounds.X + (logicalBounds.Width / 2), logicalBounds.Y + (logicalBounds.Height / 2));
        //foreach (Node node in mNodes)
        //{
        //    node.Location -= (Size)midPoint;
        //}
    }

    private void nodeListArray(ref List<Node> nodeList)
    {
        Node tempNode = null;
        String str1 = null;
        String str2 = null;

        for (int i = 0; i < nodeList.Count - 1; i++)
        {
            for (int j = nodeList.Count - 1; j > i; j--)
            {
                str1 = nodeList[i].M_ID;
                if (str1.Contains("0x"))
                    str1 = str1.Remove(0, 2);

                str2 = nodeList[j].M_ID;
                if (str2.Contains("0x"))
                    str2 = str2.Remove(0, 2);

                //str1 = nodeList[i].M_ID;
                //if (str1.Contains("HC_"))
                //    str1 = str1.Remove(0, 3);
                //else
                //    str1 = str1.Remove(str1.IndexOf('_'), 1);

                //str2 = nodeList[j].M_ID;
                //if (str2.Contains("HC_"))
                //    str2 = str2.Remove(0, 3);
                //else
                //    str2 = str2.Remove(str2.IndexOf('_'), 1);

                //if (str2.Contains("::"))
                //    str2 = str2.Remove(str2.IndexOf("::"), 2);

                if (Convert.ToInt32(str1) > Convert.ToInt32(str2))
                {
                    tempNode = nodeList[j];
                    nodeList[j] = nodeList[i];
                    nodeList[i] = tempNode;
                }
            }
        }
    }

    private void nodeListposSetting(ref List<Node> nodeList, int EffecLevels,int index)
    {
        if (EffecLevels <= 0)
            return;

        //将屏幕绘图范围换算成Node.Location的取值范围
        Point pt1 = new Point((int)(M_GrapBounds.Left + m_PlotingEdgeSpace), (int)(M_GrapBounds.Top + m_PlotingEdgeSpace));
        Point pt2 = new Point((int)(M_GrapBounds.Left + M_GrapBounds.Width - 2 * m_PlotingEdgeSpace), (int)(M_GrapBounds.Top + M_GrapBounds.Height - 2 * m_PlotingEdgeSpace));

        int HeightIncrement = (pt2.Y - pt1.Y) / EffecLevels;
        int HeightStartPos = HeightIncrement / 2 + index * HeightIncrement;

        int WightIncrement = (pt2.X - pt1.X) / nodeList.Count;
        int WightStartPos = WightIncrement / 2;

        //分配坐标
        foreach (Node node in nodeList)
        {
            node.Location = new Point(WightStartPos, HeightStartPos);
            WightStartPos += WightIncrement;
        }

        //HeightStartPos += HeightIncrement;
    }

    private void GetNetStatInfo(ref List<Node>[] nodeList, ref int[] typeNo)
    {
        typeNo = new int[5];
        nodeList = new List<Node>[5];

        nodeList[0] = mNodes.FindAll(c => c.M_ID == "HC_2016::5");
        typeNo[0] = nodeList[0].Count; //一级节点

        nodeList[1] = mNodes.FindAll(c => c.M_ID.StartsWith("HC_") && c.M_ID != "HC_2016::5");
        typeNo[1] = nodeList[1].Count;  //二级节点

        //三级节点
        nodeList[2] = mNodes.FindAll(c => c.M_type == "0x0001");
        typeNo[2] = nodeList[2].Count;

        //四级节点
        nodeList[3] = mNodes.FindAll(c => c.M_type == "0x0002");
        typeNo[3] = nodeList[3].Count;

        //五级节点
        nodeList[4] = mNodes.FindAll(c => c.M_type == "0x0003");
        typeNo[4] = nodeList[4].Count;
    }

    /// <summary>
    /// Runs the force-directed layout algorithm on this Diagram, using the specified parameters.
    /// </summary>
    /// <param name="damping">Value between 0 and 1 that slows the motion of the nodes during layout.</param>
    /// <param name="springLength">Value in pixels representing the length of the imaginary springs that run along the connectors.</param>
    /// <param name="maxIterations">Maximum number of iterations before the algorithm terminates.</param>
    /// <param name="deterministic">Whether to use a random or deterministic layout.</param>
    public void ArrangeWithForceDirect(double damping, int springLength, int maxIterations, bool deterministic)
    {
        // random starting positions can be made deterministic by seeding System.Random with a constant
        Random rnd = deterministic ? new Random(0) : new Random();

        // copy nodes into an array of metadata and randomise initial coordinates for each node
        NodeLayoutInfo[] layout = new NodeLayoutInfo[mNodes.Count];


        //将屏幕绘图范围换算成Node.Location的取值范围
        Point pt1 = new Point((int)(M_GrapBounds.Left + m_PlotingEdgeSpace), (int)(M_GrapBounds.Top + m_PlotingEdgeSpace));
        Point pt2 = new Point((int)(M_GrapBounds.Left + M_GrapBounds.Width - 2 * m_PlotingEdgeSpace), (int)(M_GrapBounds.Top + M_GrapBounds.Height - 2 * m_PlotingEdgeSpace));
        //Point pt1 = ScreenToObjLocation(M_GrapBounds.Left, M_GrapBounds.Top);
        //Point pt2 = ScreenToObjLocation(M_GrapBounds.Left + M_GrapBounds.Width, M_GrapBounds.Top + M_GrapBounds.Height);


        for (int i = 0; i < mNodes.Count; i++)
        {
            if (M_reInitializeFlag)
            {
                layout[i] = new NodeLayoutInfo(mNodes[i], new Vector(), Point.Empty);
                //layout[i].Node.Location = new Point(rnd.Next(-50, 50), rnd.Next(-50, 50));
                layout[i].Node.Location = new Point(rnd.Next(pt1.X, pt2.X), rnd.Next(pt1.Y, pt2.Y));
            }
            else
            {
                layout[i] = new NodeLayoutInfo(mNodes[i], new Vector(), Point.Empty);
                //layout[i].Node.Location = new Point(rnd.Next(-50, 50), rnd.Next(-50, 50));
                //layout[i].Node.Location = new Point(mNodes[i].X, mNodes[i].Y);
            }
        }

        int stopCount = 0;
        int iterations = 0;

        while (true)
        {
            double totalDisplacement = 0;

            for (int i = 0; i < layout.Length; i++)
            {
                NodeLayoutInfo current = layout[i];

                // express the node's current position as a vector, relative to the origin
                Vector currentPosition = new Vector(CalcDistance(Point.Empty, current.Node.Location), GetBearingAngle(Point.Empty, current.Node.Location));
                Vector netForce = new Vector(0, 0);

                // determine repulsion between nodes
                foreach (Node other in mNodes)
                {
                    if (other != current.Node) netForce += CalcRepulsionForce(current.Node, other);
                }

                // determine attraction caused by connections
                foreach (Node child in current.Node.Connections)
                {
                    netForce += CalcAttractionForce(current.Node, child, springLength);
                }
                foreach (Node parent in mNodes)
                {
                    if (parent.Connections.Contains(current.Node)) netForce += CalcAttractionForce(current.Node, parent, springLength);
                }

                // apply net force to node velocity
                current.Velocity = (current.Velocity + netForce) * damping;

                // apply velocity to node position
                current.NextPosition = (currentPosition + current.Velocity).ToPoint();
            }

            // move nodes to resultant positions (and calculate total displacement)
            for (int i = 0; i < layout.Length; i++)
            {
                NodeLayoutInfo current = layout[i];

                totalDisplacement += CalcDistance(current.Node.Location, current.NextPosition);
                current.Node.Location = current.NextPosition;
            }

            iterations++;
            if (totalDisplacement < 10) stopCount++;
            if (stopCount > 15) break;
            if (iterations > maxIterations) break;
        }

        // center the diagram around the origin
        Rectangle logicalBounds = GetDiagramBounds();
        Point midPoint = new Point(logicalBounds.X + (logicalBounds.Width / 2), logicalBounds.Y + (logicalBounds.Height / 2));
        foreach (Node node in mNodes)
        {
            node.Location -= (Size)midPoint;
        }

        //int kk = 0;
        //foreach (Node node in mNodes)
        //{
        //    if (node.Location.X < this.m_GrapBounds.Left || node.Location.Y < this.m_GrapBounds.Top || node.Location.X > this.m_GrapBounds.Left + this.m_GrapBounds.Width || node.Location.Y > this.m_GrapBounds.Top + this.m_GrapBounds.Height)
        //        kk++;
        //}
    }

    /// <summary>
    /// Calculates the attraction force between two connected nodes, using the specified spring length.
    /// </summary>
    /// <param name="x">The node that the force is acting on.</param>
    /// <param name="y">The node creating the force.</param>
    /// <param name="springLength">The length of the spring, in pixels.</param>
    /// <returns>A Vector representing the attraction force.</returns>
    private Vector CalcAttractionForce(Node x, Node y, double springLength)
    {
        int proximity = Math.Max(CalcDistance(x.Location, y.Location), 1);

        // Hooke's Law: F = -kx
        double force = ATTRACTION_CONSTANT * Math.Max(proximity - springLength, 0);
        double angle = GetBearingAngle(x.Location, y.Location);

        return new Vector(force, angle);
    }

    /// <summary>
    /// Calculates the distance between two points.
    /// </summary>
    /// <param name="a">The first point.</param>
    /// <param name="b">The second point.</param>
    /// <returns>The pixel distance between the two points.</returns>
    public static int CalcDistance(Point a, Point b)
    {
        double xDist = (a.X - b.X);
        double yDist = (a.Y - b.Y);
        return (int)Math.Sqrt(Math.Pow(xDist, 2) + Math.Pow(yDist, 2));
    }

    /// <summary>
    /// Calculates the repulsion force between any two nodes in the diagram space.
    /// </summary>
    /// <param name="x">The node that the force is acting on.</param>
    /// <param name="y">The node creating the force.</param>
    /// <returns>A Vector representing the repulsion force.</returns>
    private Vector CalcRepulsionForce(Node x, Node y)
    {
        int proximity = Math.Max(CalcDistance(x.Location, y.Location), 1);

        // Coulomb's Law: F = k(Qq/r^2)
        double force = -(REPULSION_CONSTANT / Math.Pow(proximity, 2));
        double angle = GetBearingAngle(x.Location, y.Location);

        return new Vector(force, angle);
    }

    /// <summary>
    /// Removes all nodes and connections from the diagram.
    /// </summary>
    public void Clear()
    {
        mNodes.Clear();
        mRouteNode.Clear();

        //GTopology.GObjects.Clear();
        GPlotTopology.GObjects.Clear();
    }

    /// <summary>
    /// Determines whether the diagram contains the specified node.
    /// </summary>
    /// <param name="node">The node to test.</param>
    /// <returns>True if the diagram contains the node.</returns>
    public bool ContainsNode(Node node)
    {
        return mNodes.Contains(node);
    }

    /// <summary>
    /// 初始化绘图相关设置，主要是设置m_PlotingScale
    /// </summary>
    public void Pre_Draw()
    {
        // determine the scaling factor
        logicalBounds = GetDiagramBounds();

        m_PlotingMoveX = (M_GrapBounds.X + M_GrapBounds.Width / 2) - (logicalBounds.X + logicalBounds.Width / 2);
        m_PlotingMoveY = (M_GrapBounds.Y + M_GrapBounds.Height / 2) - (logicalBounds.Y + logicalBounds.Height / 2);

        //应该根据logicalBounds以及绘图窗口的比例来设置scale
        if (logicalBounds.Width == 1 && logicalBounds.Height == 1)
        {
            m_PlotingScaleX = 1.0;
            m_PlotingScaleY = 1.0;
        }
        else
        {
            if (logicalBounds.Width != 0)
                m_PlotingScaleX = (double)(M_GrapBounds.Width - 2 * m_PlotingEdgeSpace) / (double)logicalBounds.Width;

            if (logicalBounds.Height != 0)
                m_PlotingScaleY = (double)(M_GrapBounds.Height - 2 * m_PlotingEdgeSpace) / (double)logicalBounds.Height;

            //if (logicalBounds.Width / (M_GrapBounds.Width - 2 * m_PlotingEdgeSpace) >= logicalBounds.Height / (M_GrapBounds.Height - 2 * m_PlotingEdgeSpace))
            //{
            //    if (logicalBounds.Width != 0)
            //        m_PlotingScale = (double)(M_GrapBounds.Width - 2 * m_PlotingEdgeSpace) / (double)logicalBounds.Width;
            //}
            //else
            //{
            //    if (logicalBounds.Height != 0)
            //        m_PlotingScale = (double)(M_GrapBounds.Height - 2 * m_PlotingEdgeSpace) / (double)logicalBounds.Height;
            //}
        }


    }

    /// <summary>
    /// Draws the diagram using GDI+, centering and scaling within the specified bounds.
    /// </summary>
    /// <param name="graphics">GDI+ Graphics surface.</param>
    /// <param name="bounds">Bounds in which to draw the diagram.</param>
    public void Draw(Graphics graphics) // Rectangle bounds
    {
        //if (mNodes != null && mNodes.Count > 0)
        //{
        lock (graphics)
        {
            GPlotTopology.GObjects.Clear();

            // Image ObjImg;
            int xm = 0;
            int ym = 0;
            StringFormat textFormat = new StringFormat();
            //textFormat.Alignment = StringAlignment.Center; //居中
            textFormat.Alignment = StringAlignment.Far; //右对齐
            textFormat.LineAlignment = StringAlignment.Center;

            Font CurrFont = new Font("Arial", 8);

            //Point center = new Point(bounds.X + (bounds.Width / 2), bounds.Y + (bounds.Height / 2));
            //Point center = new Point(M_GrapBounds.X + (M_GrapBounds.Width / 2), M_GrapBounds.Y + (M_GrapBounds.Height / 2));


            //绘制图例
            if (screenSettingInfo.beLegend) // mNodes != null && mNodes.Count > 0
            {
                int LegendNodeWidth = (int)(mNodes[0].Size.Width / 2.0);
                int LegendNodeHeight = (int)(mNodes[0].Size.Height / 2.0);

                int Yncreasement = (int)(LegendNodeHeight * 1.2);
                int XBase = (int)(M_GrapBounds.X + M_GrapBounds.Width - (LegendNodeWidth / 2) - 10);// - m_PlotingEdgeSpace
                int YBase = (int)(M_GrapBounds.Y + (LegendNodeHeight / 2) + 10); // + m_PlotingEdgeSpace

                Rectangle nodeBounds;
                Node node;
                ////Node node = mNodes.Find(c => c.M_ID.Contains("HC_") && c.M_type == "3");
                //Node node = mNodes.Find(c => c.M_type == "0x0000");
                //if (node != null)
                //{
                //    nodeBounds = new Rectangle(XBase - LegendNodeWidth / 2, YBase - LegendNodeHeight / 2, LegendNodeWidth, LegendNodeHeight);
                //    node.DrawNode(graphics, "0x0000", nodeBounds);

                //    // 添加文字说明
                //    AddText(graphics, (int)(XBase - 3 * LegendNodeWidth / 4.0), YBase, "控制器", true, textFormat, CurrFont);
                //    YBase += Yncreasement;
                //}

                ////node = mNodes.Find(c => c.M_ID.Contains("HC_") && c.M_type == "2");
                //node = mNodes.Find(c => c.M_type == "0x0002");
                //if (node != null)
                //{
                //    nodeBounds = new Rectangle(XBase - LegendNodeWidth / 2, YBase - LegendNodeHeight / 2, LegendNodeWidth, LegendNodeHeight);
                //    node.DrawNode(graphics, "0x0005", nodeBounds);

                //    // 添加文字说明
                //    AddText(graphics, (int)(XBase - 3 * LegendNodeWidth / 4.0), YBase, "交换机", true, textFormat, CurrFont);
                //    YBase += Yncreasement;
                //}

                for (int indexer = 1; indexer <= 5; indexer++)
                {
                    node = mNodes.Find(c => c.M_type == "0x000" + indexer.ToString());
                    if (node != null)
                    {
                        nodeBounds = new Rectangle(XBase - LegendNodeWidth / 2, YBase - LegendNodeHeight / 2, LegendNodeWidth, LegendNodeHeight);
                        node.DrawNode(graphics, "0x000" + indexer.ToString(), nodeBounds);
                        String strName;
                        if (indexer == 1)
                            strName = "网关";
                        else if (indexer == 2)
                            strName = "路由";
                        else if (indexer == 3)
                            strName = "传感器节点";
                        else if (indexer == 4)
                            strName = "交换机";
                        else
                            strName = "控制器";

                        // 添加文字说明
                        AddText(graphics, (int)(XBase - 3 * LegendNodeWidth / 4.0), YBase, strName, true, textFormat, CurrFont);
                        YBase += Yncreasement;
                    }
                }
            }


            textFormat.Alignment = StringAlignment.Center; //居中
            // draw all of the connectors first
            foreach (Node node in mNodes)
            {
                Point source = ScalePoint(node.Location);

                // connectors
                foreach (Node other in node.Connections)
                {
                    Point destination = ScalePoint(other.Location);

                    int beflag = 0; //0 表示没有 1表示正向  2表示反向
                    if (mRouteNode.Count > 0)
                    {
                        bool flag1, flag2;
                        foreach (NodePair nodepair in mRouteNode)
                        {
                            flag1 = nodepair.srcNode.M_ID == node.M_ID && nodepair.dstNode.M_ID == other.M_ID;
                            flag2 = nodepair.srcNode.M_ID == other.M_ID && nodepair.dstNode.M_ID == node.M_ID;
                            if (flag1)
                            {
                                beflag = 1;
                                break;
                            }
                            else if (flag2)
                            {
                                beflag = 2;
                                break;
                            }
                        }
                    }

                    if (beflag == 1)
                        node.DrawConnector_Flash(graphics, M_GrapCenter + (Size)source, M_GrapCenter + (Size)destination, other, PosPercentage, m_RGBPlotSetting);
                    else if (beflag == 2)
                        node.DrawConnector_Flash(graphics, M_GrapCenter + (Size)destination, M_GrapCenter + (Size)source, other, PosPercentage, m_RGBPlotSetting);
                    else
                        node.DrawConnector(graphics, M_GrapCenter + (Size)source, M_GrapCenter + (Size)destination, other);

                    // 加入GPlotTopology.GObjects序列，便于图形化操作
                    GPlotTopology.GObjects.Add(new GObject(node.M_strName + other.M_strName, "Line",
                                        M_GrapCenter + (Size)source, node.M_strName, M_GrapCenter + (Size)destination, other.M_strName));

                    //添加文字说明
                    if (screenSettingInfo.beNodeConnectorName)
                    {
                        xm = ((M_GrapCenter + (Size)source).X + (M_GrapCenter + (Size)destination).X) / 2;
                        ym = ((M_GrapCenter + (Size)source).Y + (M_GrapCenter + (Size)destination).Y) / 2;
                        AddText(graphics, xm, ym, node.M_strName + "-" + other.M_strName, false, textFormat, CurrFont);
                    }
                }
            }

            // then draw all of the nodes
            foreach (Node node in mNodes)
            {
                Point destination = ScalePoint(node.Location);

                Size nodeSize = node.Size;
                Rectangle nodeBounds = new Rectangle(M_GrapCenter.X + destination.X - (nodeSize.Width / 2), M_GrapCenter.Y + destination.Y - (nodeSize.Height / 2), nodeSize.Width, nodeSize.Height);

                //node.DrawNode(graphics, nodeBounds);
                Rectangle ModifyBounds;
                //if (node.M_ID == "HC_2016::5") //当名称为2016：：5时，表示电脑
                //    ModifyBounds = node.DrawNode(graphics, "0", nodeBounds);
                //else if (node.M_ID.IndexOf("HC_") >= 0) //当2 5这一类时
                //    ModifyBounds = node.DrawNode(graphics, "5", nodeBounds);
                //else
                //    ModifyBounds = node.DrawNode(graphics, node.M_type, nodeBounds);
                ModifyBounds = node.DrawNode(graphics, node.M_type, nodeBounds);


                if (node.BeOperNode) //为当前被操作的节点
                {
                    Pen pen = new Pen(Color.Red, 1);
                    graphics.DrawRectangle(pen, nodeBounds);
                }

                // 加入GPlotTopology.GObjects序列，便于图形化操作
                GObject temp = new GObject(node.M_ID, node.M_strName, node.M_GatewayIPName, "Node" + node.M_type.ToString(), node.M_type,
                                    ModifyBounds.Left, ModifyBounds.Top, "", ModifyBounds.Right, ModifyBounds.Bottom, "");
                //GObject(string ObjID, string ObjName, string ObjGatewayIPName, string ObjPlotType, int ObjType,int ObjX1, int ObjY1, string LNK1, int ObjX2, int ObjY2, string LNK2)
                GPlotTopology.GObjects.Add(temp);


                // 添加文字说明
                if (screenSettingInfo.beNodeName)
                {
                    int tempX = ModifyBounds.Left + ModifyBounds.Width / 2;
                    int tempY = ModifyBounds.Top + ModifyBounds.Height;
                    if (string.IsNullOrEmpty(node.M_GatewayIPName))
                        AddText(graphics, tempX, tempY, node.M_strName, true, textFormat, CurrFont);
                    else
                        AddText(graphics, tempX, tempY, node.M_strName + "(" + node.M_GatewayIPName + ")", true, textFormat, CurrFont);
                }
            }
        }
        //}
        //else
        //{
        //    StringFormat textFormat = new StringFormat();
        //    textFormat.Alignment = StringAlignment.Center; //居中
        //    //textFormat.Alignment = StringAlignment.Far; //右对齐
        //    textFormat.LineAlignment = StringAlignment.Center;
        //    Font CurrFont = new Font("Arial", 24);

        //    AddText(graphics, M_GrapBounds.Width / 2, M_GrapBounds.Height / 2, "必选先加载节点数据信息!", true, textFormat, CurrFont);
        //}

    }

    public void ScreenToObjLocation(int ScreenX, int ScreenY, GObject GToDrag)
    {
        int index = mNodes.FindIndex(c => c.M_ID == GToDrag.m_ID);
        if (index >= 0)
        {
            foreach (Node node in mNodes)
                node.BeOperNode = false;
            mNodes[index].BeOperNode = true;



            Size nodeSize = mNodes[index].Size;

            //int LocationX = (int)((double)(ScreenX + (nodeSize.Width / 2) - M_GrapCenter.X) / m_PlotingScale);
            //int LocationY = (int)((double)(ScreenY + (nodeSize.Height / 2) - M_GrapCenter.Y) / m_PlotingScale);
            int LocationX = (int)((double)(ScreenX + (nodeSize.Width / 2) - M_GrapBounds.X - m_PlotingEdgeSpace) / m_PlotingScaleX + logicalBounds.X);
            int LocationY = (int)((double)(ScreenY + (nodeSize.Height / 2) - M_GrapCenter.Y - m_PlotingEdgeSpace) / m_PlotingScaleY + logicalBounds.Y);

            mNodes[index].X = LocationX;
            mNodes[index].Y = LocationY;
        }
    }

    //public Point ScreenToObjLocation(int ScreenX, int ScreenY)
    //{
    //    int LocationX = (int)((double)(ScreenX + (8 / 2) - M_GrapCenter.X) / m_PlotingScale);
    //    int LocationY = (int)((double)(ScreenY + (8 / 2) - M_GrapCenter.Y) / m_PlotingScale);
    //    return new Point(LocationX, LocationY);
    //}

    public void ModifyGObject(GObject GToDrag, string newGObjName)
    {
        if (GToDrag.PlotType != "Line")
        {
            int index = mNodes.FindIndex(c => c.M_strName == GToDrag.Name);
            mNodes[index].M_strName = newGObjName;
        }
    }


    public void DeleteGObject(GObject GToDrag)
    {
        if (GToDrag.PlotType != "Line")
        {
            int index = mNodes.FindIndex(c => c.M_strName == GToDrag.Name);
            RemoveNode(mNodes[index]);
        }
    }

    public void AddText(Graphics g, int Xbase, int Ybase, string Msg, bool UseOffset, StringFormat textFormat, Font CurrFont)
    {
        //Graphics g = pictureBox1.CreateGraphics();
        //Font CurrFont = new Font("Arial", 8);
        int x = 0;
        int y = 0;
        if (UseOffset == true)
        {
            x = Xbase + XTextPixelOffset;
            y = Ybase + YTextPixelOffset;
        }
        else
        {
            x = Xbase;
            y = Ybase;
        }

        g.DrawString(Msg, CurrFont, new SolidBrush(Color.Black), x, y, textFormat);
    }

    public Image FindGObjectTypeImage(int ObjType)
    {
        Image RetImg = null;
        switch (ObjType)
        {
            case 0:
                RetImg = DiagramImageList.Images[0];
                break;
            case 1:
                RetImg = DiagramImageList.Images[1];
                break;
            case 2:
                RetImg = DiagramImageList.Images[2];
                break;
            case 3:
                RetImg = DiagramImageList.Images[3];
                break;
            case 4:
                RetImg = DiagramImageList.Images[4];
                break;
            case 5:
                RetImg = DiagramImageList.Images[5];
                break;
        }
        return RetImg;
    }

    public Image FindGObjectTypeImage(string ObjType)
    {
        Image RetImg = null;
        switch (ObjType)
        {
            case "Network":
            case "0x0000":
                RetImg = DiagramImageList.Images[0];
                break;
            case "Router":
            case "0x0001":
                RetImg = DiagramImageList.Images[1];
                break;
            case "Emitter":
            case "0x0002":
                RetImg = DiagramImageList.Images[2];
                break;
            case "Receiver":
            case "0x0003":
                RetImg = DiagramImageList.Images[3];
                break;
            case "Shape_ST":
            case "0x0004":
                RetImg = DiagramImageList.Images[4];
                break;
        }
        return RetImg;
    }

    //public Image LoadGObjectTypeImage(int ObjType)
    //{
    //    Image RetImg = null;
    //    switch (ObjType)
    //    {
    //        case 1:
    //            RetImg = Image.FromFile("C:\\Users\\ZYan\\Desktop\\NetworkTopology\\NetworkTopology\\NetworkTopology\\Receiver.png");
    //            break;
    //        case 2:
    //            RetImg = Image.FromFile("C:\\Users\\ZYan\\Desktop\\NetworkTopology\\NetworkTopology\\NetworkTopology\\Router.png");
    //            break;
    //        case 3:
    //            RetImg = Image.FromFile("C:\\Users\\ZYan\\Desktop\\NetworkTopology\\NetworkTopology\\NetworkTopology\\Shape_T.png");
    //            break;
    //        case 4:
    //            RetImg = Image.FromFile("C:\\Users\\ZYan\\Desktop\\NetworkTopology\\NetworkTopology\\NetworkTopology\\Sender.png");
    //            break;
    //        case 5:
    //            RetImg = Image.FromFile("C:\\Users\\ZYan\\Desktop\\NetworkTopology\\NetworkTopology\\NetworkTopology\\Sender.png");
    //            break;
    //    }
    //    return RetImg;
    //}

    /// <summary>
    /// Calculates the bearing angle from one point to another.
    /// </summary>
    /// <param name="start">The node that the angle is measured from.</param>
    /// <param name="end">The node that creates the angle.</param>
    /// <returns>The bearing angle, in degrees.</returns>
    private double GetBearingAngle(Point start, Point end)
    {
        Point half = new Point(start.X + ((end.X - start.X) / 2), start.Y + ((end.Y - start.Y) / 2));

        double diffX = (double)(half.X - start.X);
        double diffY = (double)(half.Y - start.Y);

        if (diffX == 0) diffX = 0.001;
        if (diffY == 0) diffY = 0.001;

        double angle;
        if (Math.Abs(diffX) > Math.Abs(diffY))
        {
            angle = Math.Tanh(diffY / diffX) * (180.0 / Math.PI);
            if (((diffX < 0) && (diffY > 0)) || ((diffX < 0) && (diffY < 0))) angle += 180;
        }
        else
        {
            angle = Math.Tanh(diffX / diffY) * (180.0 / Math.PI);
            if (((diffY < 0) && (diffX > 0)) || ((diffY < 0) && (diffX < 0))) angle += 180;
            angle = (180 - (angle + 90));
        }

        return angle;
    }

    /// <summary>
    /// Determines the logical bounds of the diagram. This is used to center and scale the diagram when drawing.
    /// </summary>
    /// <returns>A System.Drawing.Rectangle that fits exactly around every node in the diagram.</returns>
    private Rectangle GetDiagramBounds()
    {
        int minX = Int32.MaxValue, minY = Int32.MaxValue;
        int maxX = Int32.MinValue, maxY = Int32.MinValue;
        foreach (Node node in mNodes)
        {
            if (node.X < minX)
                minX = node.X;
            if (node.X > maxX)
                maxX = node.X;
            if (node.Y < minY)
                minY = node.Y;
            if (node.Y > maxY)
                maxY = node.Y;
        }

        return Rectangle.FromLTRB(minX, minY, maxX, maxY);
    }

    /// <summary>
    /// Removes the specified node from the diagram. Any connected nodes will remain on the diagram.
    /// </summary>
    /// <param name="node">The node to remove from the diagram.</param>
    /// <returns>True if the node belonged to the diagram.</returns>
    public bool RemoveNode(Node node)
    {
        node.Diagram = null;
        foreach (Node other in mNodes)
        {
            if ((other != node) && other.Connections.Contains(node))
                other.Disconnect(node);
        }
        return mNodes.Remove(node);
    }

    /// <summary>
    /// Applies a scaling factor to the specified point, used for zooming.
    /// </summary>
    /// <param name="point">The coordinates to scale.</param>
    /// <param name="scale">The scaling factor.</param>
    /// <returns>A System.Drawing.Point representing the scaled coordinates.</returns>
    private Point ScalePoint(Point point, double scale)
    {
        double X = (point.X - logicalBounds.X) * m_PlotingScaleX + M_GrapBounds.X + m_PlotingEdgeSpace;
        double Y = (point.Y - logicalBounds.Y) * m_PlotingScaleY + M_GrapBounds.Y + m_PlotingEdgeSpace;
        return new Point((int)X, (int)Y);

        //return new Point((int)((double)point.X * scale), (int)((double)point.Y * scale));
    }

    // Pre_Draw里面已经考虑了m_PlotingEdgeSpace的问题
    private Point ScalePoint(Point point)
    {
        double X = (point.X - logicalBounds.X) * m_PlotingScaleX + M_GrapBounds.X + m_PlotingEdgeSpace;
        double Y = (point.Y - logicalBounds.Y) * m_PlotingScaleY + M_GrapBounds.Y + m_PlotingEdgeSpace;
        return new Point((int)X, (int)Y);
    }

    /// <summary>
    /// Private inner class used to track the node's position and velocity during simulation.
    /// </summary>
    private class NodeLayoutInfo
    {

        public Node Node;			// reference to the node in the simulation
        public Vector Velocity;		// the node's current velocity, expressed in vector form
        public Point NextPosition;	// the node's position after the next iteration

        /// <summary>
        /// Initialises a new instance of the Diagram.NodeLayoutInfo class, using the specified parameters.
        /// </summary>
        /// <param name="node"></param>
        /// <param name="velocity"></param>
        /// <param name="nextPosition"></param>
        public NodeLayoutInfo(Node node, Vector velocity, Point nextPosition)
        {
            Node = node;
            Velocity = velocity;
            NextPosition = nextPosition;
        }
    }

}