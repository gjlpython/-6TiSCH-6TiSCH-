using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NetworkTopology;
using System.Runtime.InteropServices;

namespace Graphic
{
    public partial class FrmManageObject : Form
    {
        private int moveCurPosX;
        private int moveCurPosY;

        public string m_ID;
        public string m_strName;
        public string m_GatewayIPName;
        public string m_type;
        public string m_plotType;


        public int OperationToDo; // ����һ������в�����·�ɡ���֡����·������������
        public int subOperationToDo; // �Ա����к��ֲ����� 0�����ã�·�ɡ���֡����·���������ӣ������������� 1��ɾ�����������ڽ�����������

        //public int OperationID;


        public DataTable OperDt;
        public DataTable partOperDt;

        public DataTable RouteDt;
        public DataTable SuperframeDt;
        public DataTable LinkFormDt;
        public DataTable StatsFlowDt;


        public FrmManageObject()
        {
            InitializeComponent();

            RouteDt = new DataTable();
            SuperframeDt = new DataTable();
            LinkFormDt = new DataTable();
            StatsFlowDt = new DataTable();
        }

        public FrmManageObject(DataTable inRouteDt, DataTable inSuperframeDt, DataTable inLinkFormDt, DataTable inStatsFlowDt)
        {
            InitializeComponent();

            RouteDt = inRouteDt;
            if (RouteDt.Rows.Count > 0)
                cmbOperType.Items.Add("·�ɱ�");

            SuperframeDt = inSuperframeDt;
            if (SuperframeDt.Rows.Count > 0)
                cmbOperType.Items.Add("��֡��");

            LinkFormDt = inLinkFormDt;
            if (LinkFormDt.Rows.Count > 0)
                cmbOperType.Items.Add("��·��");

            StatsFlowDt = inStatsFlowDt;
            if (StatsFlowDt.Rows.Count > 0)
                cmbOperType.Items.Add("����������");
        }

        public void InitSetting(string GContainerm_ID, string GContainerName, string GContainerm_GatewayIPName, string GContainerm_type, string GContainerPlotType, int inOperationToDo, int inOperationID)
        {
            m_ID = GContainerm_ID;
            m_strName = GContainerName;
            m_GatewayIPName = GContainerm_GatewayIPName;
            m_type = GContainerm_type;
            m_plotType = GContainerPlotType;

            //OperationToDo = inOperationToDo;
            //OperationID = inOperationID;
            if (cmbOperType.Items.Count>0)
                cmbOperType.SelectedIndex = inOperationToDo;
            if (cmbOperID.Items.Count > 0)
                cmbOperID.SelectedIndex = inOperationID;
        }

        private void FrmManageObject_Load(object sender, EventArgs e)
        {
            panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(Form1_MouseDown);
            panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(Form_MouseMove);
            panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(Form_MouseUp);

            //this.BackColor = Color.White;
            //this.TransparencyKey = Color.White; /*��2��Ϊ����͸��*/

            label1.Parent = panel1;
            label1.BackColor = Color.Transparent;
            label2.Parent = panel1;
            label2.BackColor = Color.Transparent;
            label3.Parent = panel1;
            label3.BackColor = Color.Transparent;
            label4.Parent = panel1;
            label4.BackColor = Color.Transparent;
            label_ID.Parent = panel1;
            label_ID.BackColor = Color.Transparent;


            dataGridView.AllowUserToAddRows = false;

            cmbAddress.Text = m_strName;
            cmbcategory.Text = m_type.ToString();
            cmbPlotType.Text = m_plotType.ToString();


            // SetcmbOperationType();
        }

        /// <summary>
        /// ����OperationToDo��������cmbOperType
        /// </summary>
        //private void SetcmbOperationType()
        //{
        //if (!string.IsNullOrEmpty(OperationToDo))
        //{
        //    int i = 0;
        //    int selectedIndex = 0;
        //    for (i = 0; i < cmbOperType.Items.Count; i++)
        //    {
        //        if (cmbOperType.Items[i].ToString() == OperationToDo)
        //        {
        //            selectedIndex = i;
        //            break;
        //        }
        //    }
        //    cmbOperType.SelectedIndex = selectedIndex;
        //}
        //else
        //    cmbOperType.SelectedIndex = 0;
        //}

        //private void SetcmbOperID( )
        //{
        //    cmbOperID.Items.Clear();
        //    foreach (DataRow dr in OperDt.Rows)
        //        cmbOperID.Items.Add(dr[0].ToString());


        //    if (!string.IsNullOrEmpty(OperationID))
        //    {
        //        int i = 0;
        //        int selectedIndex = 0;
        //        for (i = 0; i < cmbOperID.Items.Count; i++)
        //        {
        //            if (cmbOperID.Items[i].ToString() == OperationID)
        //            {
        //                selectedIndex = i;
        //                break;
        //            }
        //        }
        //        cmbOperID.SelectedIndex = selectedIndex;
        //    }
        //    else
        //        cmbOperID.SelectedIndex = 0;
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbOperType.Text.Trim() == String.Empty || cmbOperType.Text.Trim() == String.Empty)
                return;

            // ��ȡdatagridview�����ݵ�datatable
            partOperDt.Rows[0][0] = cmbOperID.Text.ToString();

            switch(cmbOperType.Text.Trim())
            {
                case "·�ɱ�":
                    OperationToDo = 0;
                    break;
                case "��֡��":
                    OperationToDo = 1;
                    break;
                case "��·��":
                    OperationToDo = 2;
                    break;
                case "����������":
                    OperationToDo = 3;
                    break;
            }

            ////
            ////   Valutate if something has modified
            ////
            //bool SomethingHasModified = false;
            //SomethingHasModified = (textBox1.Text != m_strName);
            //if (SomethingHasModified == true)
            //{
            //    //OperationToDo = "Modify";
            //}

            ////
            ////   Load eventually modified Fields into public variables
            ////
            //m_strName = textBox1.Text;
            ////
            ////   Exit
            ////

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cmbOperType.SelectedIndex == 3)
            {
                partOperDt.Rows[0][0] = cmbOperID.Text.ToString();
                OperationToDo = cmbOperType.SelectedIndex;
                subOperationToDo = 1;

                this.DialogResult = DialogResult.OK;
            }
            else
                this.DialogResult = DialogResult.No;

            this.Close();

            //if (MessageBox.Show("Are you sure ?","Delete Confimation",MessageBoxButtons.YesNo,MessageBoxIcon.Question)
            //    == DialogResult.Yes)
            //    {
            //        // OperationToDo = "Delete";
            //    }
            ////
            ////   Exit
            ////
            //this.Close();
        }

        

        private void cmbOperID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbOperType.Text.Trim() == String.Empty)
                return;
            //OperationID = cmbOperID.SelectedText;

            //if (cmbOperType.SelectedText == "·�ɱ�")
            //{
            //    OperDt = RouteDt.Clone();
            //    OperDt.Rows.Add(RouteDt.Rows[cmbOperID.SelectedIndex]);
            //}
            //else if (cmbOperType.SelectedText == "��֡��")
            //{
            //    OperDt = SuperframeDt.Clone();
            //    OperDt.Rows.Add(SuperframeDt.Rows[cmbOperID.SelectedIndex]);
            //}
            //else if (cmbOperType.SelectedText == "��·��")
            //{
            //    OperDt = LinkFormDt.Clone();
            //    OperDt.Rows.Add(LinkFormDt.Rows[cmbOperID.SelectedIndex]);
            //}
            //else
            //{
            //    OperDt = RouteDt.Clone();
            //    OperDt.Rows.Add(RouteDt.Rows[cmbOperID.SelectedIndex]);
            //}

            partOperDt = OperDt.Clone();
            DataRow dr = partOperDt.NewRow();
            for (int i = 0; i < OperDt.Columns.Count; i++)
                dr[i] = OperDt.Rows[cmbOperID.SelectedIndex][i];
            partOperDt.Rows.Add(dr);

            dataGridView.DataSource = partOperDt;
            dataGridView.Columns[0].Visible = false;
            dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView.Invalidate();
        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string text = dataGridView[e.ColumnIndex, e.RowIndex].Value.ToString(); ;
                CellEditForm form = new CellEditForm();
                form.StartPosition = FormStartPosition.CenterParent;
                form.editText = text;
                if (form.ShowDialog() == DialogResult.OK)
                {
                    dataGridView[e.ColumnIndex, e.RowIndex].Value = form.editText;
                }
            }
            catch
            {
                System.Diagnostics.Debug.Assert(false, "˫������Чcell��");
            }


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {


        }

        #region �ޱ߿����϶�
        //-------------------�ޱ߿����϶�---------------------------  
        Point mouseOff;//����ƶ�λ�ñ���  
        bool leftFlag;//��ǩ�Ƿ�Ϊ���  
        private void Form_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseOff = new Point(-e.X, -e.Y); //�õ�������ֵ  
                leftFlag = true;                  //����������ʱ��עΪtrue;  
            }
        }
        private void Form_MouseMove(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                Point mouseSet = Control.MousePosition;
                mouseSet.Offset(mouseOff.X, mouseOff.Y);  //�����ƶ����λ��  
                (((System.Windows.Forms.PictureBox)sender).Parent).Location = mouseSet;
            }
        }
        private void Form_MouseUp(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                leftFlag = false;//�ͷ������עΪfalse;  
            }
        }

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }

        private void FrmManageObject_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                moveCurPosX = e.X;
                moveCurPosY = e.Y;
            }
        }

        private void FrmManageObject_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + (e.X - moveCurPosX), this.Location.Y + (e.Y - moveCurPosY));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;//��С��
        }

        private void cmbOperType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //OperationToDo = cmbOperType.SelectedIndex;
            if (cmbOperType.Text.Trim() == String.Empty)
                return;

            if (cmbOperType.Text == "·�ɱ�")
            {
                OperDt = RouteDt;
                label_ID.Text = "RouteID";
                button2.Text = "ȡ��";
            }
            else if (cmbOperType.Text == "��֡��")
            {
                OperDt = SuperframeDt;
                label_ID.Text = "SuperframeID";
                button2.Text = "ȡ��";
            }
            else if (cmbOperType.Text == "��·��")
            {
                OperDt = LinkFormDt;
                label_ID.Text = "LinkID";
                button2.Text = "ȡ��";
            }
            else if (cmbOperType.Text == "����������")
            {
                OperDt = StatsFlowDt;
                label_ID.Text = "StatsFlowID";

                button2.Text = "ɾ��";
            }

            cmbOperID.Items.Clear();
            foreach (DataRow dr in OperDt.Rows)
                cmbOperID.Items.Add(dr[0].ToString());

            if (cmbOperID.Items.Count > 0)
                cmbOperID.SelectedIndex = 0;
        }
        //------------------------end �ޱ߿����϶�-----------------------------------  
        #endregion

    }
}