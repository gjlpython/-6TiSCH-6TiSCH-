﻿using System;
using System.Windows.Forms;
using NetworkTopology;

namespace ForceDirected {
	static class Program {
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() {
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

            DataLinkInfo linkSet = new DataLinkInfo();
            DialogResult dgRst = (new Demo(linkSet)).SetLinkInfo(ref linkSet);
            if (dgRst != DialogResult.No)
            {
                Application.Run(new Demo(linkSet));
            }
		}
	}
}
