﻿// A Force-Directed Diagram Layout Algorithm
// Bradley Smith - 2010/07/01

// uncomment the following line to animate the iterations of the force-directed algorithm:
#define ANIMATE

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

using System.Data;

using Graphic;
using NetworkTopology;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.IO;
using System.Drawing.Printing;
using System.ComponentModel;
using NetworkRealTime;
using System.Collections;
using System.Text.RegularExpressions;



namespace ForceDirected
{

    //[DllImport("DwmApi.dll")] 
    //public static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref MARGINS pMarinset); 
    //[StructLayout(LayoutKind.Sequential)] 
    //public struct MARGINS 
    //{ 
    //    public int Right; 
    //    public int left; 
    //    public int Top; 
    //    public int Bottom; 
    //}

    //定义一个枚举，表示拖动方向
    public enum MouseDirection
    {
        Herizontal,//水平方向拖动，只改变窗体的宽度        
        Vertical,//垂直方向拖动，只改变窗体的高度 
        Declining,//倾斜方向，同时改变窗体的宽度和高度        
        None//不做标志，即不拖动窗体改变大小 
    }

    public partial class Demo : Form
    {

        private BackgroundWorker BkWorker = new BackgroundWorker();
        private System.Windows.Forms.Timer BkTimer = new System.Windows.Forms.Timer();
        int BkWorkerType; //0：获取网络结构  1：网络布局优化
        bool beToolStripButton_MouseMove = false;

         

        GridPrinter gridPrinter;//声明打印类  datagridview
        PrintListView listView__Material = new PrintListView();//声明带打印功能的ListView类

        private int checkPrint; // richtextbox

        bool isMouseDown = false; //表示鼠标当前是否处于按下状态，初始值为否 
        MouseDirection direction = MouseDirection.None;//表示拖动的方向，起始为None，表示不拖动


        private int moveCurPosX;
        private int moveCurPosY;

        //记录splitContainer1 在折叠panel2之前的SplitterDistance  //记录最下化之前splitcontainer1的splitDistance位置
        int PreviousSplitterDistance = 450;
        int PreviousSplitterDistance_Topology_Info = 450;

        //DataLinkInfo linkSet;

        Diagram mDiagram;
        Random mRandom;

        //private const int Nmax = 50;
        //public GScenario GNetwork;
        private const int XTextPixelOffset = 0;
        private const int YTextPixelOffset = 0;
        private const int XManageFormPixelOffset = 10;
        private const int YManageFormPixelOffset = 10;
        //private int CurrObjDragIndx = 0;
        private int Xdown = 0;
        private int Ydown = 0;
        private DateTime Tdown;
        //private int DragTimeMin = 100; // milliseconds
        private bool Dragging = false;


        public class SocketPacket //服务器端socket
        {
            public SocketPacket(Socket socket, int clientNumber)
            {
                m_currentSocket = socket;//设备IP地址和端口号
                m_clientNumber = clientNumber;//用户号/连接请求？
                string_RemoteEndPoint = socket.RemoteEndPoint;
            }
            public Socket m_currentSocket;
            public int m_clientNumber;
            public byte[] dataBuffer = new byte[10240*5];//数据缓冲区
            public EndPoint string_RemoteEndPoint;
        }

        public delegate void UpdateRichEditCallback(string text);//更新控件回调
        public delegate void UpdateClientListCallback();//更新客户端列表回调
        private AsyncCallback pfnWorkerCallBack;//异步回调委托
        private Socket m_mainSocket;
        private ArrayList m_workerSocketList = ArrayList.Synchronized(new System.Collections.ArrayList());//动态数组
        private int m_clientCount = 0;//客户端计算   


        protected override void OnClosing(CancelEventArgs e)//结束通信
        {
            if (m_mainSocket != null)//通信未结束
            {
                m_mainSocket.Close();
                m_mainSocket = null;//结束通信
            }	
        }

        public Demo(DataLinkInfo linkSet)
        {
            InitializeComponent();

            listView__Material.Parent = splitContainer2.Panel2;

            listView__Material.View = View.Details;
            listView__Material.FullRowSelect = true;
            listView__Material.BeginUpdate();
            listView__Material.Columns.Clear();
            listView__Material.Columns.Add("No", 60, HorizontalAlignment.Left); //添加标题
            listView__Material.Columns[0].Text = "序号";
            listView__Material.Columns.Add("Shidu", 60, HorizontalAlignment.Left); //添加标题
            listView__Material.Columns[1].Text = "湿度";
            listView__Material.Columns.Add("Wendu", 60, HorizontalAlignment.Left); //添加标题
            listView__Material.Columns[2].Text = "温度";
            listView__Material.Columns.Add("Time", 120, HorizontalAlignment.Left); //添加标题
            listView__Material.Columns[3].Text = "时间";
            listView__Material.Columns.Add("IPv6", 60, HorizontalAlignment.Left); //添加标题
            listView__Material.Columns[4].Text = "IPv6";
            listView__Material.Columns.Add("LongAddress", 200, HorizontalAlignment.Left); //添加标题
            listView__Material.Columns[5].Text = "长地址";



            

            mDiagram = new Diagram();
            mDiagram.DiagramImageList = this.imageList1;
            mDiagram.M_GrapBounds = Rectangle.FromLTRB(pictureBox1.Left, pictureBox1.Top, pictureBox1.Width, pictureBox1.Height); //初始化范围

            PreviousSplitterDistance = splitContainer1.SplitterDistance;

            //GNetwork = new GScenario();
            //GNetwork.Clear();
            //GNetwork.CurrObjIndx = 0;

            mRandom = new Random();
            mDiagram.linkSet = linkSet;

            

            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//设置该属性 为false
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            // draw with anti-aliasing and a 12 pixel border
            //e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //mDiagram.Draw(e.Graphics, Rectangle.FromLTRB(12, 12, ClientSize.Width - 12, ClientSize.Height - 12));
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            // redraw on resize
            //Invalidate();

            pictureBox1.Invalidate();

        }

        private void pictureBox1_Paint_1(object sender, PaintEventArgs e)
        {
            if (mDiagram.beEffectiveData && mDiagram.mNodes.Count > 0)
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                //mDiagram.Draw(e.Graphics, Rectangle.FromLTRB(pictureBox1.Left + 10, pictureBox1.Top + 10, pictureBox1.Width - 20, pictureBox1.Height - 20));
                mDiagram.M_GrapBounds = Rectangle.FromLTRB(pictureBox1.Left, pictureBox1.Top, pictureBox1.Width, pictureBox1.Height); //初始化范围
                mDiagram.Pre_Draw();
                mDiagram.Draw(e.Graphics);
                // ReDrawAll(e.Graphics);
            }
            else
            {
                StringFormat textFormat = new StringFormat();
                textFormat.Alignment = StringAlignment.Center; //居中
                //textFormat.Alignment = StringAlignment.Far; //右对齐
                textFormat.LineAlignment = StringAlignment.Center;
                Font CurrFont = new Font("Arial", 24);

                mDiagram.M_GrapBounds = Rectangle.FromLTRB(pictureBox1.Left, pictureBox1.Top, pictureBox1.Width, pictureBox1.Height); //初始化范围
                mDiagram.AddText(e.Graphics, mDiagram.M_GrapBounds.Width / 2, mDiagram.M_GrapBounds.Height / 2, "必须先加载有效数据信息!", true, textFormat, CurrFont);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {

            mDiagram.M_reInitializeFlag = false;
            mDiagramArrangeAlgorithm();

            //mDiagram.Clear();
            //// create a basic, random diagram that is between 2 and 4 levels deep 
            //// and has between 1 and 10 leaf nodes per branch
            //Node node = new SpotNode(Color.Black);
            //mDiagram.AddNode(node);

            //for (int i = 0; i < mRandom.Next(1, 10); i++)
            //{
            //    Node child = new SpotNode(Color.Navy);
            //    node.AddChild(child);

            //    for (int j = 0; j < mRandom.Next(0, 10); j++)
            //    {
            //        Node grandchild = new SpotNode(Color.Blue);
            //        child.AddChild(grandchild);

            //        //for (int k = 0; k < mRandom.Next(0, 10); k++) {
            //        //    Node descendant = new SpotNode(Color.CornflowerBlue);
            //        //    grandchild.AddChild(descendant);
            //        //}
            //    }
            //}

            // run the force-directed algorithm (async)
            //mDiagramArrangeAlgorithm();
        }

        ///   <summary>
        ///   运行force-directed算法      
        ///   </summary>
        private void mDiagramArrangeAlgorithm()
        {
            Cursor = Cursors.WaitCursor;
            //progressBar1.Value = 0;
            LiDaoXiang.Enabled = false;

            progressBar1.MarqueeAnimationSpeed = 50;//设置字幕动画的速度（单位是毫秒）
            progressBar1.Style = ProgressBarStyle.Marquee;
            //progressBar1.Value = progressBar1.Minimum;

            Thread bg = new Thread(mDiagram.Arrange);
            //Thread cha = new Thread(new ThreadStart(threadchange));

            lock (mDiagram.mNodes)
            {
                bg.IsBackground = true;
                bg.Start();
                //cha.Start();
                

#if ANIMATE
                while (bg.IsAlive)
                {
                    pictureBox1.Invalidate();
                    Application.DoEvents(); //让系统在百忙之中来响应其他事件
                    Thread.Sleep(10);
                }
#else
			bg.Join();
#endif

                LiDaoXiang.Enabled = true;

                //timer1.Enabled = false;
                bg.Abort();
                //cha.Abort();
            }

            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = progressBar1.Minimum;
            //if (!progressBar1.IsDisposed)
            //{
            //    progressBar1.Value = progressBar1.Maximum;
            //    System.Threading.Thread.Sleep(20);
            //    progressBar1.Value = progressBar1.Minimum;
            //    progressBar1.Invalidate();
            //}

            Cursor = Cursors.Default;

            //Invalidate();
            pictureBox1.Invalidate();
        }

        private void change()
        {
            progressBar1.PerformStep();
            if (progressBar1.Value >= progressBar1.Maximum)
                progressBar1.Value = progressBar1.Minimum;
        }

        private void threadchange()   //通过委托处理
        {
            MethodInvoker In = new MethodInvoker(change);
            this.BeginInvoke(In);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //int i = 100;
            //progressBar1.Value = progressBar1.Value + 1;
            //i = 100 - progressBar1.Value;
            //if (i == 0)
            //{
            //    timer1.Enabled = false;
            //}

            //生成新的节点位置信息
            mDiagram.PosPercentage += mDiagram.PosPercIncrement;
            if (mDiagram.PosPercentage >= 1)
                mDiagram.PosPercentage = 0;

            //R
            mDiagram.m_RGBPlotSetting[0] += mDiagram.RGBIncrement;
            if (mDiagram.m_RGBPlotSetting[0] < 0)
                mDiagram.m_RGBPlotSetting[0] = 255;
            else if (mDiagram.m_RGBPlotSetting[0] > 255)
                mDiagram.m_RGBPlotSetting[0] = 0;

            //G
            mDiagram.m_RGBPlotSetting[1] += mDiagram.RGBIncrement;
            if (mDiagram.m_RGBPlotSetting[1] < 0)
                mDiagram.m_RGBPlotSetting[1] = 255;
            else if (mDiagram.m_RGBPlotSetting[1] > 255)
                mDiagram.m_RGBPlotSetting[1] = 0;

            //B
            mDiagram.m_RGBPlotSetting[2] -= mDiagram.RGBIncrement;
            if (mDiagram.m_RGBPlotSetting[2] < 0)
                mDiagram.m_RGBPlotSetting[2] = 255;
            else if (mDiagram.m_RGBPlotSetting[2] > 255)
                mDiagram.m_RGBPlotSetting[2] = 0;



            //R
            mDiagram.m_RGBPlotSetting[3] -= mDiagram.RGBIncrement;
            if (mDiagram.m_RGBPlotSetting[3] < 0)
                mDiagram.m_RGBPlotSetting[3] = 255;
            else if (mDiagram.m_RGBPlotSetting[3] > 255)
                mDiagram.m_RGBPlotSetting[3] = 0;
            //G
            mDiagram.m_RGBPlotSetting[4] -= mDiagram.RGBIncrement;
            if (mDiagram.m_RGBPlotSetting[4] < 0)
                mDiagram.m_RGBPlotSetting[4] = 255;
            else if (mDiagram.m_RGBPlotSetting[4] > 255)
                mDiagram.m_RGBPlotSetting[4] = 0;
            //B
            mDiagram.m_RGBPlotSetting[5] += mDiagram.RGBIncrement;
            if (mDiagram.m_RGBPlotSetting[5] < 0)
                mDiagram.m_RGBPlotSetting[5] = 255;
            else if (mDiagram.m_RGBPlotSetting[5] > 255)
                mDiagram.m_RGBPlotSetting[5] = 0;

            pictureBox1.Invalidate();
        }


        private void Demo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Demo_Load(object sender, EventArgs e)
        {
            // 读取历史数据，并加入下面列表中
            string s;
            HomePage CNewFile = new HomePage();
            CNewFile.CreateNewFile_c();
            StreamReader sr = new StreamReader(Common.SensorDataFilePath);
            s = sr.ReadToEnd();
            sr.Close();
            //string[] sentence = s.Split('\n');
            int xsjs = 0;  //项数计数
            string[] another = s.Split(new char[2] { '\t', '\n' });
            string[] jlsz = new string[] { " ", " ", " ", " " };//记录数字


            foreach (string ss in another)
            {
                string[] words = ss.Split(' ');
                jlsz[xsjs] = words[0];
                xsjs++;

                if (xsjs == 4)
                {
                    ListViewItem item1 = new ListViewItem();
                    item1.Text = jlsz[0];
                    item1.SubItems.Add(jlsz[1]);
                    item1.SubItems.Add(jlsz[2]);
                    item1.SubItems.Add(jlsz[3]);
                    listView__Material.Items.Add(item1);
                    xsjs = 0;
                }
            }

            listView__Material.Visible = true;
            if (this.listView__Material.Items.Count > 0)
                this.listView__Material.Items[this.listView__Material.Items.Count - 1].EnsureVisible();


            LiDaoXiang.Enabled = false;
            checkBox_CMD.Checked = true;

            // 根据引导窗口信息，补充主界面控件信息
            textBox2.Text = mDiagram.linkSet.ServerPort;

            comboBox3.Items.Clear();
            comboBox3.Items.Add("IPv6Any");
            // zhangyan 20200615
            if (!Socket.OSSupportsIPv6) MessageBox.Show("系统不支持IPv6地址或IPv6地址未启用！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            for (int i = 0; i < Dns.GetHostEntry(Dns.GetHostName()).AddressList.Length; i++)//获取主机的IP地址列表及列表长度
            {
                if (Dns.GetHostEntry(Dns.GetHostName()).AddressList[i].ToString().Contains(":"))//如果":"存在于IP地址列表的标准表示中（详见IPV6的标准语法）
                {
                    this.comboBox3.Items.Add(Dns.GetHostEntry(Dns.GetHostName()).AddressList[i].ToString());//将地址列表标准表示法添加到comboBox1的集合
                }
            }
            int index = 0;
            for(index = 0; index < comboBox3.Items.Count;index++)
                if (comboBox3.Items[index].ToString()==mDiagram.linkSet.ServerName)
                    break;
            if (index >= comboBox3.Items.Count) // 表示没有匹配的，基本不可能发生
                comboBox3.SelectedIndex = 0;
            else
                comboBox3.SelectedIndex = index;


            ConnectAction(); // 进行连接
            if (!string.IsNullOrEmpty(mDiagram.linkSet.ServerName) && !string.IsNullOrEmpty(mDiagram.linkSet.ServerPort))
                LinkInfoLabel.Text = "连接目标: " + mDiagram.linkSet.ServerName + ":" + mDiagram.linkSet.ServerPort;
            else
                LinkInfoLabel.Text = "连接目标: Null";

            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = progressBar1.Minimum;

            this.MaximumSize = new Size(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);
            this.WindowState = FormWindowState.Maximized;



            //skinEngine1.SkinFile = System.Environment.CurrentDirectory + "\\Skins\\XPBlue.ssk";  //选择皮肤文件

            //dataGridView_Material.AllowUserToAddRows = false;
            //dataGridView_Material.CurrentCellDirtyStateChanged += new EventHandler(dataGridView_Material_CurrentCellDirtyStateChanged);
            //dataGridView_Material.CellValueChanged += new DataGridViewCellEventHandler(dataGridView_Material_CellValueChanged);

            //this.BackgroundImage = null;
            //MARGINS margins = new MARGINS();
            //margins.left = -1;       
            //margins.Right = -1;       
            //margins.Top = -1;       
            //margins.Bottom = -1;       
            //IntPtr hwnd = Handle;       
            //int result = DwmExtendFrameIntoClientArea(hwnd, ref margins);      
            //this.BackColor = Color.Black;       
            //this.label1.Text = "。。。";       
            //this.label1.BackColor = Color.Transparent;      
            //this.label1.ForeColor = Color.White; 


            //GNetwork = new GScenario(Nmax);


            //Request_NodeInfo();
            //mDiagramArrangeAlgorithm();

            //CellEditForm opj = new CellEditForm();
            ////FrmManageObject opj = new FrmManageObject();
            //opj.ShowDialog();
            //return;



            //String subStr_read = "dfgdgZhangYanReceive1\r\n2016年8月24日 - C# 去除首尾字符或字符串的方法时间: 2016-08-24来源ZhangYanReceive2\r\n";

            //String flagStr = "ZhangYanReceive1\r\n";
            //int index1 = subStr_read.IndexOf(flagStr) + flagStr.Length;
            //int index2 = subStr_read.IndexOf("ZhangYanReceive2");

            //String receiveString = subStr_read.Substring(index1, index2 - index1);
            //receiveString.Trim();


            //清空txt文件内容
            //string path = System.Environment.CurrentDirectory + "\\SendReceivedData.txt";//文件的路径，保证文件存在。
            //FileStream stream2 = File.Open(path, FileMode.OpenOrCreate, FileAccess.Write);
            //stream2.Seek(0, SeekOrigin.Begin);
            //stream2.SetLength(0); //清空txt文件
            //stream2.Close();

            //path = System.Environment.CurrentDirectory + "\\BoxDataTest.txt";//文件的路径，保证文件存在。
            //stream2 = File.Open(path, FileMode.OpenOrCreate, FileAccess.Write);
            //stream2.Seek(0, SeekOrigin.Begin);
            //stream2.SetLength(0); //清空txt文件
            //stream2.Close();


            //comboBox2.Items.Clear();
            //comboBox2.Items.Add("Sensor10");
            //comboBox2.Items.Add("Sensor11");
            //comboBox2.Items.Add("Sensor12");
            //comboBox2.Items.Add("Sensor13");
            //comboBox2.Items.Add("Sensor14");
            //comboBox2.Items.Add("Sensor15");
            //comboBox2.Items.Add("Sensor16");
            //comboBox2.Items.Add("Sensor17");
            //comboBox2.Items.Add("Sensor18");
            //comboBox2.Items.Add("Sensor19");
            //comboBox2.Items.Add("Sensor20");
        }

        //void dataGridView_Material_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        //{
        //    if (dataGridView_Material.IsCurrentCellDirty)
        //    {
        //        dataGridView_Material.CommitEdit(DataGridViewDataErrorContexts.Commit);
        //    }
        //}

        //void dataGridView_Material_CellValueChanged(object sender, DataGridViewCellEventArgs e)  
        //{  
        //     if (dataGridView_Material.Rows.Count > 0)  
        //     {
        //         //if (dataGridView_Material.SelectedRows.Count > 0)
        //         //{
        //         //    int index = dataGridView_Material.SelectedRows[0].Index;
        //         //    String str = dataGridView_Material.Rows[index].Cells["dst"].Value.ToString();
        //         //}

        //         //for (int i = 0; i < dataGridView_Material.Rows.Count; i++)
        //         //{
        //         //    string _selectValue = dataGridView_Material.Rows[i].Cells["Column_CheckBox"].EditedFormattedValue.ToString();
        //         //    if (_selectValue == "True")  //如果CheckBox已选中，则在此处继续编写代码
        //         //        str = dataGridView_Material.Rows[i].Cells["dst"].Value.ToString();
        //         //}

        //         if ((bool)dataGridView_Material.Rows[e.RowIndex].Cells[0].EditedFormattedValue == true)
        //         {
        //             dataGridView_Material.Rows[e.RowIndex].Cells[0].Value = false;

        //             mDiagram.mRouteNode.Clear();
        //         }
        //         else
        //         {
        //             dataGridView_Material.Rows[e.RowIndex].Cells[0].Value = true;

        //             mDiagram.mRouteNode.Clear();
        //             if (mDiagram.m_dGV_MaterialShowType == 0)
        //             {
        //                 NodePair pairItem = new NodePair();
        //                 pairItem.srcNode = mDiagram.mNodes.Find(c=> c.M_ID == dataGridView_Material.Rows[e.RowIndex].Cells["src"].ToString());
        //                 pairItem.dstNode = mDiagram.mNodes.Find(c=> c.M_ID == dataGridView_Material.Rows[e.RowIndex].Cells["next"].ToString());
        //                 mDiagram.mRouteNode.Add(pairItem);

        //                 pairItem = new NodePair();
        //                 pairItem.srcNode = mDiagram.mNodes.Find(c => c.M_ID == dataGridView_Material.Rows[e.RowIndex].Cells["next"].ToString());
        //                 pairItem.dstNode = mDiagram.mNodes.Find(c => c.M_ID == dataGridView_Material.Rows[e.RowIndex].Cells["dst"].ToString());
        //                 mDiagram.mRouteNode.Add(pairItem);
        //             }

        //         }

        //         pictureBox1.Invalidate();
        //      }  
        //}

        /// <summary>
        /// </summary>
        public DialogResult SetLinkInfo(ref DataLinkInfo linkSet)
        {
            //if (!(new TCPOper()).CheckConnectionEffectiveness(mDiagram.linkSet))
            //{
            FormNew dbe = new FormNew();
            dbe.StartPosition = FormStartPosition.CenterScreen;
            DialogResult dgRst = dbe.ShowDialog();
            if (dgRst == DialogResult.OK)
            {
                linkSet = dbe.linkSet;
            }
            else if (dgRst == DialogResult.Cancel || dgRst == DialogResult.No)
            {
                linkSet = new DataLinkInfo();
                linkSet.ServerName = null;
                linkSet.ServerPort = null;

                //mDiagram.linkSet.SDNIPName = null;
                //mDiagram.linkSet.SDNPort = null;

                //if (string.IsNullOrEmpty(mDiagram.linkSet.ServerName) || string.IsNullOrEmpty(mDiagram.linkSet.ServerPort))
                //    LinkInfoLabel.Text = "未进行连接设置";
                //else
            }
            return dgRst;
        }

        private void performOper_BkMode()
        {
            progressBar1.Value = 0;
            progressBar1.Maximum = 200;
            progressBar1.Step = 1;
            BkTimer.Interval = 100;
            BkTimer.Tick += new EventHandler(BkTimer_Tick);

            BkWorker.WorkerReportsProgress = true;
            BkWorker.DoWork += new DoWorkEventHandler(worker_DoWork);
            BkWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
            BkWorker.RunWorkerAsync();

            BkTimer.Start();
            Cursor = Cursors.WaitCursor;
        }

        void BkTimer_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < progressBar1.Maximum)
            {
                progressBar1.PerformStep();
            }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (BkWorkerType == 0)
                mDiagram.GetNetworkTopology();
            else if (BkWorkerType == 1)
                mDiagram.Arrange();
        }


        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            BkTimer.Stop();
            progressBar1.Value = progressBar1.Maximum;

            Thread.Sleep(20);
            progressBar1.Value = progressBar1.Minimum;
        }

        private void getNetworkTopology_recvData(String recvData)
        {
            LiDaoXiang.Enabled = false;
            Cursor = Cursors.WaitCursor;

            //progressBar1.Value = progressBar1.Minimum;
            progressBar1.MarqueeAnimationSpeed = 50;//设置字幕动画的速度（单位是毫秒）
            progressBar1.Style = ProgressBarStyle.Marquee;

            lock (mDiagram.mNodes)
            {
                mDiagram.GetNetworkTopology_recvData(recvData);
            }

            //Thread bg_GetTopology = new Thread(mDiagram.GetNetworkTopology);

            //lock (mDiagram.mNodes)
            //{
            //    bg_GetTopology.IsBackground = true;
            //    bg_GetTopology.Start();
            //    //cha.Start();
            //    //BkTimer.Start();


            //    //Graphics g = CreateGraphics();


            //    //#if ANIMATE
            //    //                while (bg_GetTopology.IsAlive)
            //    //                {
            //    //                    pictureBox1.Invalidate();
            //    //                    Application.DoEvents(); //让系统在百忙之中来响应其他事件
            //    //                    Thread.Sleep(10);
            //    //                }
            //    //#else
            //    bg_GetTopology.Join();
            //    //cha.Join();
            //    //#endif

            //    bg_GetTopology.Abort();
            //    //cha.Abort();
            //}

            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = progressBar1.Minimum;
            Cursor = Cursors.Default;
            LiDaoXiang.Enabled = true;

            //comboBox_NodeInfo 用于查看节点信息
            comboBox_NodeInfo.Items.Clear();
            foreach (Node node in mDiagram.mNodes)
            {
                if (node.M_type == "0x0003")
                    src_comboBox.Items.Add(node.M_ID);
            }
            if (src_comboBox.Items.Count > 0)
                src_comboBox.SelectedIndex = 0;
        }

        /// <summary>
        /// 获取panid，获取WIA-PA拓扑信息，获取回程网络拓扑信息
        /// </summary>
        private void getNetworkTopology()
        {
            //LiDaoXiang.Enabled = false;
            //BkWorkerType = 0;
            //performOper_BkMode();
            //LiDaoXiang.Enabled = true;

            LiDaoXiang.Enabled = false;
            Cursor = Cursors.WaitCursor;

            //progressBar1.Value = progressBar1.Minimum;
            progressBar1.MarqueeAnimationSpeed = 50;//设置字幕动画的速度（单位是毫秒）
            progressBar1.Style = ProgressBarStyle.Marquee;

            Thread bg_GetTopology = new Thread(mDiagram.GetNetworkTopology);
            //Thread cha = new Thread(new ThreadStart(threadchange));
            //BkTimer.Interval = 50;
            //BkTimer.Tick += new EventHandler(BkTimer_Tick);

            lock (mDiagram.mNodes)
            {
                bg_GetTopology.IsBackground = true;
                bg_GetTopology.Start();
                //cha.Start();
                //BkTimer.Start();


                //Graphics g = CreateGraphics();


                //#if ANIMATE
                //                while (bg_GetTopology.IsAlive)
                //                {
                //                    pictureBox1.Invalidate();
                //                    Application.DoEvents(); //让系统在百忙之中来响应其他事件
                //                    Thread.Sleep(10);
                //                }
                //#else
                bg_GetTopology.Join();
                //cha.Join();
                //#endif

                bg_GetTopology.Abort();
                //cha.Abort();
            }

            //BkTimer.Stop();
            //progressBar1.Value = progressBar1.Maximum;
            //System.Threading.Thread.Sleep(20);
            //progressBar1.Value = progressBar1.Minimum;
            //progressBar1.Invalidate();

            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = progressBar1.Minimum;
            Cursor = Cursors.Default;
            LiDaoXiang.Enabled = true;


            //src 和 dst加入可选节点
            src_comboBox.Items.Clear();
            foreach (Node node in mDiagram.mNodes)
            {
                if (!(node.M_ID.Contains("HC_") || node.M_type == "1"))
                    src_comboBox.Items.Add(node.M_ID);
            }
            if (src_comboBox.Items.Count > 0)
                src_comboBox.SelectedIndex = 0;

            dst_comboBox.Items.Clear();
            foreach (Node node in mDiagram.mNodes)
            {
                if (!(node.M_ID.Contains("HC_") || node.M_type == "1"))
                    dst_comboBox.Items.Add(node.M_ID);
            }
            if (dst_comboBox.Items.Count > 0)
                dst_comboBox.SelectedIndex = dst_comboBox.Items.Count - 1;
        }


        ///   <summary>          
        ///   请求相关节点信息,设置dataGridView_Material数据     
        ///   </summary>         
        private void Request_NodeInfo()
        {
            mDiagram.Clear();
            dataGridView_Material.Columns.Clear();


            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(Int32));
            dt.Columns.Add("M_strName", typeof(string));
            dt.Columns.Add("节点类型", typeof(Int32));
            dt.Columns.Add("附加信息", typeof(string));


            // create a basic, random diagram that is between 2 and 4 levels deep 
            // and has be
            //  10 leaf nodes per branch

            int nodeID = mDiagram.Nodes.Count + 1;
            Node node = new SpotNode(nodeID.ToString(), Color.Red);
            node.M_strName = "Node:" + nodeID;
            node.M_type = "1";
            mDiagram.AddNode(node);

            DataRow dr = dt.NewRow();
            dr["ID"] = nodeID;
            dr["M_strName"] = node.M_strName;
            dr["节点类型"] = node.M_type;
            dt.Rows.Add(dr);


            for (int i = 0; i < mRandom.Next(1, 20); i++)
            {
                nodeID = mDiagram.Nodes.Count + 1;
                Node child = new SpotNode(nodeID.ToString(), Color.Green);
                child.M_strName = "Node:" + nodeID;
                child.M_type = "2";
                //node.AddChild(child,ref node.Diagram.GTopology.GObjects);
                node.AddChild(child);

                dr = dt.NewRow();
                dr["ID"] = nodeID;
                dr["M_strName"] = child.M_strName;
                dr["节点类型"] = child.M_type;
                dt.Rows.Add(dr);

                for (int j = 0; j < mRandom.Next(0, 5); j++)
                {
                    nodeID = mDiagram.Nodes.Count + 1;
                    Node grandchild = new SpotNode(nodeID.ToString(), Color.Blue);
                    grandchild.M_strName = "Node:" + nodeID;
                    grandchild.M_type = "3";
                    //child.AddChild(grandchild, ref child.Diagram.GTopology.GObjects);
                    child.AddChild(grandchild);

                    dr = dt.NewRow();
                    dr["ID"] = nodeID;
                    dr["M_strName"] = grandchild.M_strName;
                    dr["节点类型"] = grandchild.M_type;
                    dt.Rows.Add(dr);

                    for (int k = 0; k < mRandom.Next(0, 50); k++)
                    {
                        nodeID = mDiagram.Nodes.Count + 1;
                        Node descendant = new SpotNode(nodeID.ToString(), Color.Yellow);
                        descendant.M_strName = "Node:" + nodeID;
                        descendant.M_type = "4";
                        //grandchild.AddChild(descendant, ref grandchild.Diagram.GTopology.GObjects);
                        grandchild.AddChild(descendant);

                        dr = dt.NewRow();
                        dr["ID"] = nodeID;
                        dr["M_strName"] = descendant.M_strName;
                        dr["节点类型"] = descendant.M_type;
                        dt.Rows.Add(dr);
                    }
                }
            }

            for (int k = 0; k < mDiagram.Nodes.Count; k++)
            {
                if (string.Equals(mDiagram.Nodes[k].M_ID, 2))
                {
                    int nodeIDtemp = mDiagram.Nodes.Count + 1;
                    Node child = new SpotNode(nodeIDtemp.ToString(), Color.Green);
                    child.M_strName = "Node:" + nodeIDtemp;
                    child.M_type = mDiagram.Nodes[k].M_type + 1;
                    //mDiagram.Nodes[k].AddChild(child, ref mDiagram.Nodes[k].Diagram.GTopology.GObjects);
                    mDiagram.Nodes[k].AddChild(child);


                    dr = dt.NewRow();
                    dr["ID"] = nodeID;
                    dr["M_strName"] = child.M_strName;
                    dr["节点类型"] = child.M_type;
                    dt.Rows.Add(dr);
                }
            }


            dataGridView_Material.DataSource = dt;

            System.Windows.Forms.DataGridViewCheckBoxColumn Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            Column1.HeaderText = "Column_CheckBox";
            Column1.Name = "Column_CheckBox";
            //Column1.ReadOnly = true;
            dataGridView_Material.Columns.Insert(0, Column1);
            dataGridView_Material.Columns[0].Width = 40;
            dataGridView_Material.Columns[0].MinimumWidth = 30;

            //mDiagram.Clear();
            //// create a basic, random diagram that is between 2 and 4 levels deep 
            //// and has between 1 and 10 leaf nodes per branch
            //Node node = new SpotNode(Color.Black);
            //mDiagram.AddNode(node);

            //for (int i = 0; i < mRandom.Next(1, 10); i++)
            //{
            //    Node child = new SpotNode(Color.Navy);
            //    node.AddChild(child);

            //    for (int j = 0; j < mRandom.Next(0, 10); j++)
            //    {
            //        Node grandchild = new SpotNode(Color.Blue);
            //        child.AddChild(grandchild);

            //        //for (int k = 0; k < mRandom.Next(0, 10); k++) {
            //        //    Node descendant = new SpotNode(Color.CornflowerBlue);
            //        //    grandchild.AddChild(descendant);
            //        //}
            //    }
            //}
        }



        ///   <summary>          
        ///   根据内容，设置dataGridView_Material行背景色
        ///   </summary>  
        private void dataGridView_Material_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            //Color[] colorArr = { Color.Black, Color.Navy, Color.Blue, Color.CornflowerBlue, Color.DarkGreen, Color.Orange };

            //if (dataGridView_Material.Rows.Count > 1)
            //{
            //    int callType = Convert.ToInt32(dataGridView_Material.Rows[e.RowIndex].Cells["节点类型"].Value);
            //    switch (callType)
            //    {
            //        case 1://未接
            //            dataGridView_Material.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Red;
            //            break;
            //        case 2://已接
            //            dataGridView_Material.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Green;
            //            break;
            //        case 3://打出
            //            dataGridView_Material.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Blue;
            //            break;
            //    }
            //}

        }

        private void randomTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.BackgroundImage = null;
            //MARGINS margins = new MARGINS();
            //margins.left = -1;       
            //margins.Right = -1;       
            //margins.Top = -1;       
            //margins.Bottom = -1;       
            //IntPtr hwnd = Handle;       
            //int result = DwmExtendFrameIntoClientArea(hwnd, ref margins);      
            //this.BackColor = Color.Black;       
            //this.label1.Text = "。。。";       
            //this.label1.BackColor = Color.Transparent;      
            //this.label1.ForeColor = Color.White; 


            Request_NodeInfo();

            mDiagram.M_reInitializeFlag = true;
            mDiagramArrangeAlgorithm();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //string LoadFileName = "";
            //string ErrLoading = "";
            //LoadFileName = CommFnc.FindFileToOpen();
            //GNetwork.Clear();
            //if (GNetwork.LoadFile(LoadFileName, ref ErrLoading) == true)
            //{
            //    toolStripStatusLabel1.Text = "File loaded in memory.";
            //    pictureBox1.Refresh();
            //}
            //else
            //{
            //    toolStripStatusLabel1.Text = ErrLoading;
            //}
        }

        private void ReDrawAll(Graphics g)
        {
            //Graphics g = pictureBox1.CreateGraphics();
            //e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //mDiagram.Draw(e.Graphics, Rectangle.FromLTRB(pictureBox1.Left, pictureBox1.Top, pictureBox1.Width, pictureBox1.Height));

            //Graphics g = pictureBox1.CreateGraphics();
            //g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            GObject CurrObj = new GObject();
            Rectangle Rct = new Rectangle();
            Pen p = new Pen(Color.Blue);
            Image ObjImg;
            int xm = 0;
            int ym = 0;
            string IsLine = "";


            for (int i = 0; i < mDiagram.GPlotTopology.GObjects.Count; i++)  //for (int i=0; i < GNetwork.Nobj;i++ )
            {
                CurrObj = mDiagram.GPlotTopology.GObjects[i];
                //
                if (CurrObj.PlotType == "") IsLine = "N/D";
                if (CurrObj.PlotType == "Line") IsLine = "Y";
                if ((CurrObj.PlotType != "Line") && (CurrObj.PlotType != "")) IsLine = "N";
                //
                switch (IsLine)
                {
                    case "Y":
                        g.DrawLine(p, CurrObj.x1, CurrObj.y1, CurrObj.x2, CurrObj.y2);
                        xm = (CurrObj.x1 + CurrObj.x2) / 2;
                        ym = (CurrObj.y1 + CurrObj.y2) / 2;
                        AddText(g, xm, ym, CurrObj.Name, false);
                        break;
                    case "N":
                        Rct.X = CurrObj.x1;
                        Rct.Y = CurrObj.y1;
                        Rct.Width = CurrObj.x2 - CurrObj.x1;
                        Rct.Height = CurrObj.y2 - CurrObj.y1;
                        if (CurrObj.PlotType != String.Empty)
                        {
                            ObjImg = FindGObjectTypeImage(CurrObj.PlotType);
                            g.DrawImage(ObjImg, Rct);
                            AddText(g, CurrObj.x1, CurrObj.y1, CurrObj.Name, true);
                            mDiagram.GPlotTopology.AdjustLinkedTo(CurrObj.Name);
                        }
                        break;
                }
            }

            //GObject CurrObj = new GObject();
            //Rectangle Rct = new Rectangle();
            //Pen p = new Pen(Color.Blue);
            //Image ObjImg;
            //int xm = 0;
            //int ym = 0;
            //string IsLine = "";
            //for (int i = 0; i < GNetwork.GObjects.Count; i++)  //for (int i=0; i < GNetwork.Nobj;i++ )
            //{
            //    CurrObj = GNetwork.GObjects[i];
            //    //
            //    if (CurrObj.Type == "") IsLine = "N/D";
            //    if (CurrObj.Type == "Line") IsLine = "Y";
            //    if ((CurrObj.Type != "Line") && (CurrObj.Type != "")) IsLine = "N";
            //    //
            //    switch (IsLine)
            //    {
            //        case "Y":
            //            g.DrawLine(p, CurrObj.x1, CurrObj.y1, CurrObj.x2, CurrObj.y2);
            //            xm = (CurrObj.x1 + CurrObj.x2) / 2;
            //            ym = (CurrObj.y1 + CurrObj.y2) / 2;
            //            AddText(g, xm, ym, CurrObj.Name, false);
            //            break;
            //        case "N":
            //            Rct.X = CurrObj.x1;
            //            Rct.Y = CurrObj.y1;
            //            Rct.Width = CurrObj.x2 - CurrObj.x1;
            //            Rct.Height = CurrObj.y2 - CurrObj.y1;
            //            if (CurrObj.Type != String.Empty)
            //            {
            //                ObjImg = FindGObjectTypeImage(CurrObj.Type);
            //                g.DrawImage(ObjImg, Rct);
            //                AddText(g, CurrObj.x1, CurrObj.y1, CurrObj.Name, true);
            //                GNetwork.AdjustLinkedTo(CurrObj.Name);
            //            }
            //            break;
            //    }
            //}
        }

        private void AddText(Graphics g, int Xbase, int Ybase, string Msg, bool UseOffset)
        {
            //Graphics g = pictureBox1.CreateGraphics();
            Font CurrFont = new Font("Arial", 8);
            int x = 0;
            int y = 0;
            if (UseOffset == true)
            {
                x = Xbase + XTextPixelOffset;
                y = Ybase + YTextPixelOffset;
            }
            else
            {
                x = Xbase;
                y = Ybase;
            }
            g.DrawString(Msg, CurrFont, new SolidBrush(Color.Black), x, y);
        }

        private Image FindGObjectTypeImage(string ObjType)
        {
            Image RetImg = null;
            switch (ObjType)
            {
                case "Network":
                    RetImg = imageList1.Images[0];
                    break;
                case "Router":
                    RetImg = imageList1.Images[1];
                    break;
                case "Emitter":
                    RetImg = imageList1.Images[2];
                    break;
                case "Receiver":
                    RetImg = imageList1.Images[3];
                    break;
                case "Shape_ST":
                    RetImg = imageList1.Images[4];
                    break;
            }
            return RetImg;
        }

        private void saveToFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string SaveFileName = "";
            string ErrSaving = "";
            SaveFileName = CommFnc.AssignFileToSave();
            if (mDiagram.GPlotTopology.SaveFile(SaveFileName, ref ErrSaving) == true)
            {
                toolStripStatusLabel1.Text = "File saved.";
            }
            else
            {
                toolStripStatusLabel1.Text = ErrSaving;
            }

            //string SaveFileName = "";
            //string ErrSaving = "";
            //SaveFileName = CommFnc.AssignFileToSave();
            //if (GNetwork.SaveFile(SaveFileName, ref ErrSaving) == true)
            //{
            //    toolStripStatusLabel1.Text = "File saved.";
            //}
            //else
            //{
            //    toolStripStatusLabel1.Text = ErrSaving;
            //}
        }

        private void emitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int X = 0;
            int Y = 25;
            AddGObject(X, Y, 0, 0, "Emitter");
        }

        private void receiverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int X = 0;
            int Y = 25;
            AddGObject(X, Y, 0, 0, "Receiver");
        }

        private void linkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int X1 = 0;
            int Y1 = 0;
            int X2 = 100;
            int Y2 = 100;
            AddGObject(X1, Y1, X2, Y2, "Line");
        }

        private void routerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int X = 0;
            int Y = 25;
            AddGObject(X, Y, 0, 0, "Router");
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int X = 0;
            int Y = 25;
            AddGObject(X, Y, 0, 0, "Shape_ST");
        }

        public void AddGObject(int x1, int y1, int x2, int y2, string ObjType)
        {
            //Graphics g = pictureBox1.CreateGraphics();
            //Rectangle ObjRct = new Rectangle();
            //Pen p = new Pen(Color.Blue);
            //Image ObjImg;
            //string ObjName = ObjType + "_" + GNetwork.LastIndexOfGObject(ObjType).ToString();
            ////
            //if (ObjType == "Line")
            //{
            //    g.DrawLine(p, x1, y1, x2, y2);
            //    int xm = (x1 + x2) / 2;
            //    int ym = (y1 + y2) / 2;
            //    AddText(g, xm, ym, ObjName, false);
            //}
            //else
            //{
            //    ObjImg = FindGObjectTypeImage(ObjType);
            //    ObjRct.X = x1;
            //    ObjRct.Y = y1;
            //    ObjRct.Height = ObjImg.Height;
            //    ObjRct.Width = ObjImg.Width;
            //    g.DrawImage(ObjImg, ObjRct);
            //    AddText(g, x1, y1, ObjName, true);
            //    x2 = x1 + ObjRct.Width;
            //    y2 = y1 + ObjRct.Height;
            //}
            ////
            //GNetwork.AddGObject(ObjName, ObjType, x1, y1, x2, y2);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (!mDiagram.beEffectiveData)
                return;

            Xdown = e.X;
            Ydown = e.Y;
            GObject GContainer = new GObject();
            int Container = mDiagram.GPlotTopology.FindContainerObject(Xdown, Ydown, ref GContainer, false);
            if (Container > -1)
            {
                Dragging = true;
                Cursor.Current = Cursors.Hand;
                //CurrObjDragIndx = Container;

                mDiagram.CurrObjDragIndx = Container;
            }
            else
            {
                // Click out of all objects
                mDiagram.CurrObjDragIndx = -1;
            }

            if (e.Button == MouseButtons.Right)
            {
                //判断哪些菜单可用
                if (mDiagram.CurrObjDragIndx == -1)
                    SetContextMenuStripType(-1);
                else
                {
                    GObject GToDrag = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx];
                    if (GToDrag.PlotType == "Line")
                        SetContextMenuStripType(-1);
                    else
                    {
                        if (GToDrag.m_ID.IndexOf("HC_") > -1)
                        {
                            if (GToDrag.m_type == "3")
                                SetContextMenuStripType(1);
                            else
                                SetContextMenuStripType(2);
                        }
                        else
                        {
                            if (GToDrag.m_type == "1")
                                SetContextMenuStripType(3);
                            else if (GToDrag.m_type == "2")
                                SetContextMenuStripType(4);
                            else if (GToDrag.m_type == "3")
                                SetContextMenuStripType(5);
                        }
                    }
                }

                contextMenuStrip1.Show(this, e.Location);
            }

            //Xdown = e.X;
            //Ydown = e.Y;
            //Tdown = DateTime.Now;
            //GObject GContainer = new GObject();
            //int Container = GNetwork.FindContainerObject(Xdown, Ydown, ref GContainer, false);
            //if (Container > -1)
            //{
            //    Dragging = true;
            //    Cursor.Current = Cursors.Hand;
            //    CurrObjDragIndx = Container;
            //}
            //else
            //{
            //    // Click out of all objects
            //}
        }

        private void SetContextMenuStripType(int type)
        {
            switch (type)
            {
                case -1:
                case 1:
                    TSM_Luyoubiao.Enabled = false;
                    TSM_Chaozhenbiao.Enabled = false;
                    TSM_Lianlubiao.Enabled = false;
                    TSM_Jiaohuanjiliubiao.Enabled = false;
                    break;
                case 2:
                    TSM_Luyoubiao.Enabled = false;
                    TSM_Chaozhenbiao.Enabled = false;
                    TSM_Lianlubiao.Enabled = false;
                    TSM_Jiaohuanjiliubiao.Enabled = true;
                    break;
                case 3:
                    TSM_Luyoubiao.Enabled = true;
                    TSM_Chaozhenbiao.Enabled = true;
                    TSM_Lianlubiao.Enabled = true;
                    TSM_Jiaohuanjiliubiao.Enabled = false;
                    break;
                case 4:
                    TSM_Luyoubiao.Enabled = true;
                    TSM_Chaozhenbiao.Enabled = true;
                    TSM_Lianlubiao.Enabled = true;
                    TSM_Jiaohuanjiliubiao.Enabled = false;
                    break;
                case 5:
                    TSM_Luyoubiao.Enabled = false;
                    TSM_Chaozhenbiao.Enabled = true;
                    TSM_Lianlubiao.Enabled = true;
                    TSM_Jiaohuanjiliubiao.Enabled = false;
                    break;
            }

            // 图标状态设置
            图例ToolStripMenuItem.Checked = mDiagram.screenSettingInfo.beLegend;
            NodeNameToolStripMenuItem.Checked = mDiagram.screenSettingInfo.beNodeName;
            ConnectorNameToolStripMenuItem1.Checked = mDiagram.screenSettingInfo.beNodeConnectorName;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            string CoordsMsg = "";
            CoordsMsg = "x = " + e.X.ToString() + " : y = " + e.Y.ToString();
            toolStripStatusLabel1.Text = CoordsMsg;


            if (!mDiagram.beEffectiveData)
                return;

            if (Dragging)
            {
                int H = 0;
                int W = 0;

                GObject GToDrag = new GObject();
                GToDrag = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx];

                if ((GToDrag.PlotType != "Line")) //|| (GNetwork.FindContainerObject(e.X, e.Y, ref GContainer, true) > -1)
                {
                    //W = GToDrag.x2 - GToDrag.x1;
                    //H = GToDrag.y2 - GToDrag.y1;
                    //GToDrag.x1 = e.X;
                    //GToDrag.y1 = e.Y;
                    //GToDrag.x2 = e.X + W;
                    //GToDrag.y2 = e.Y + H;
                    //mDiagram.GPlotTopology.AdjustLinkedTo(GToDrag.Name);

                    mDiagram.ScreenToObjLocation(e.X, e.Y, GToDrag);
                }
                Cursor.Current = Cursors.Default;
                pictureBox1.Refresh();
            }
            //string CoordsMsg = "";
            //CoordsMsg = "x = " + e.X.ToString() + " : y = " + e.Y.ToString();
            //toolStripStatusLabel1.Text = CoordsMsg;

            //if (Dragging)
            //{
            //    int H = 0;
            //    int W = 0;
            //    //GObject GContainer = new GObject();
            //    GObject GToDrag = new GObject();
            //    GToDrag = GNetwork.GObjects[CurrObjDragIndx];
            //    //double d1 = 0;
            //    //double d2 = 0;
            //    //TimeSpan DTDrag = new TimeSpan();
            //    //DTDrag = DateTime.Now.Subtract(Tdown);
            //    //if ((Dragging == true)) // && (DTDrag.Milliseconds > DragTimeMin)
            //    //{
            //    if ((GNetwork.GObjects[CurrObjDragIndx].Type != "Line")) //|| (GNetwork.FindContainerObject(e.X, e.Y, ref GContainer, true) > -1)
            //    {
            //        W = GToDrag.x2 - GToDrag.x1;
            //        H = GToDrag.y2 - GToDrag.y1;
            //        GToDrag.x1 = e.X;
            //        GToDrag.y1 = e.Y;
            //        GToDrag.x2 = e.X + W;
            //        GToDrag.y2 = e.Y + H;
            //        GNetwork.AdjustLinkedTo(GToDrag.Name);
            //    }
            //    //if ((GNetwork.GObjects[CurrObjDragIndx].Type == "Line") && (GNetwork.FindContainerObject(e.X, e.Y, ref GContainer, true) > -1)) 
            //    //{
            //    //    //
            //    //    //    What is the point of the line to link ? 
            //    //    //    The nearest to (Xdown,Ydown)
            //    //    //
            //    //    d1 = CommFnc.distance(Xdown, Ydown, GToDrag.x1, GToDrag.y1);
            //    //    d2 = CommFnc.distance(Xdown, Ydown, GToDrag.x2, GToDrag.y2);
            //    //    if (d1 <= d2)
            //    //    {
            //    //        GToDrag.x1 = (GContainer.x1 + GContainer.x2) / 2;
            //    //        GToDrag.y1 = (GContainer.y1 + GContainer.y2) / 2;
            //    //        GToDrag.Lnk1 = GContainer.Name;
            //    //    }
            //    //    else
            //    //    {
            //    //        GToDrag.x2 = (GContainer.x1 + GContainer.x2) / 2;
            //    //        GToDrag.y2 = (GContainer.y1 + GContainer.y2) / 2;
            //    //        GToDrag.Lnk2 = GContainer.Name;
            //    //    }
            //    //}
            //    //else
            //    //{
            //    //    W = GToDrag.x2 - GToDrag.x1;
            //    //    H = GToDrag.y2 - GToDrag.y1;
            //    //    GToDrag.x1 = e.X;
            //    //    GToDrag.y1 = e.Y;
            //    //    GToDrag.x2 = e.X + W;
            //    //    GToDrag.y2 = e.Y + H;
            //    //    GNetwork.AdjustLinkedTo(GToDrag.Name);
            //    //}
            //    Cursor.Current = Cursors.Default;
            //    //Dragging = false;
            //    this.Refresh();
            //    //this.Invalidate();
            //    //}
            //}
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (!mDiagram.beEffectiveData)
                return;

            //TimeSpan DTDrag = new TimeSpan();
            //DTDrag = DateTime.Now.Subtract(Tdown);
            if ((Dragging == true)) // && (DTDrag.Milliseconds > DragTimeMin)
            {
                int H = 0;
                int W = 0;
                GObject GContainer = new GObject();
                GObject GToDrag = new GObject();
                GToDrag = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx];

                double d1 = 0;
                double d2 = 0;

                if ((GToDrag.PlotType == "Line") && (mDiagram.GPlotTopology.FindContainerObject(e.X, e.Y, ref GContainer, true) > -1))
                {
                    //
                    //    What is the point of the line to link ? 
                    //    The nearest to (Xdown,Ydown)
                    //
                    d1 = CommFnc.distance(Xdown, Ydown, GToDrag.x1, GToDrag.y1);
                    d2 = CommFnc.distance(Xdown, Ydown, GToDrag.x2, GToDrag.y2);
                    if (d1 <= d2)
                    {
                        GToDrag.x1 = (GContainer.x1 + GContainer.x2) / 2;
                        GToDrag.y1 = (GContainer.y1 + GContainer.y2) / 2;
                        GToDrag.Lnk1 = GContainer.Name;
                    }
                    else
                    {
                        GToDrag.x2 = (GContainer.x1 + GContainer.x2) / 2;
                        GToDrag.y2 = (GContainer.y1 + GContainer.y2) / 2;
                        GToDrag.Lnk2 = GContainer.Name;
                    }
                }
                else if ((GToDrag.PlotType != "Line")) //|| (GNetwork.FindContainerObject(e.X, e.Y, ref GContainer, true) > -1)
                {
                    //W = GToDrag.x2 - GToDrag.x1;
                    //H = GToDrag.y2 - GToDrag.y1;
                    //GToDrag.x1 = e.X;
                    //GToDrag.y1 = e.Y;
                    //GToDrag.x2 = e.X + W;
                    //GToDrag.y2 = e.Y + H;
                    //mDiagram.GPlotTopology.AdjustLinkedTo(GToDrag.Name);
                    mDiagram.ScreenToObjLocation(e.X, e.Y, GToDrag);
                }

                Cursor.Current = Cursors.Default;

                pictureBox1.Refresh();
            }
            Dragging = false;

            //if ((Dragging == true)) // && (DTDrag.Milliseconds > DragTimeMin)
            //{
            //    int H = 0;
            //    int W = 0;
            //    GObject GContainer = new GObject();
            //    GObject GToDrag = new GObject();
            //    GToDrag = GNetwork.GObjects[CurrObjDragIndx];
            //    double d1 = 0;
            //    double d2 = 0;

            //    if ((GNetwork.GObjects[CurrObjDragIndx].Type == "Line")
            //       && (GNetwork.FindContainerObject(e.X, e.Y, ref GContainer, true) > -1))
            //    {
            //        //
            //        //    What is the point of the line to link ? 
            //        //    The nearest to (Xdown,Ydown)
            //        //
            //        d1 = CommFnc.distance(Xdown, Ydown, GToDrag.x1, GToDrag.y1);
            //        d2 = CommFnc.distance(Xdown, Ydown, GToDrag.x2, GToDrag.y2);
            //        if (d1 <= d2)
            //        {
            //            GToDrag.x1 = (GContainer.x1 + GContainer.x2) / 2;
            //            GToDrag.y1 = (GContainer.y1 + GContainer.y2) / 2;
            //            GToDrag.Lnk1 = GContainer.Name;
            //        }
            //        else
            //        {
            //            GToDrag.x2 = (GContainer.x1 + GContainer.x2) / 2;
            //            GToDrag.y2 = (GContainer.y1 + GContainer.y2) / 2;
            //            GToDrag.Lnk2 = GContainer.Name;
            //        }
            //    }
            //    else
            //    {
            //        W = GToDrag.x2 - GToDrag.x1;
            //        H = GToDrag.y2 - GToDrag.y1;
            //        GToDrag.x1 = e.X;
            //        GToDrag.y1 = e.Y;
            //        GToDrag.x2 = e.X + W;
            //        GToDrag.y2 = e.Y + H;
            //        GNetwork.AdjustLinkedTo(GToDrag.Name);
            //    }
            //    Cursor.Current = Cursors.Default;
            //    this.Refresh();
            //}
            //Dragging = false;
        }

        private void pictureBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            base.OnDoubleClick(e);
            if (e.Button == MouseButtons.Right)
                return;

            if (!mDiagram.beEffectiveData)
                return;

            int Xclicked = 0;
            int Yclicked = 0;
            Dragging = false;
            Xclicked = e.X;
            Yclicked = e.Y;
            GObject GContainer = new GObject();
            GObject GModified = new GObject();
            int Container = mDiagram.GPlotTopology.FindContainerObject(Xclicked, Yclicked, ref GContainer, false);
            if (Container > -1)
            {
                GModified = GContainer;
                mDiagram.CurrObjDragIndx = Container;

                //用于SDN 节点管理
                //int OperationToDo = 0;
                //int OperationID = 0;
                //Point IniPoint = new Point(Xclicked + XManageFormPixelOffset, Yclicked + YManageFormPixelOffset);
                //ManageObject(GContainer, OperationToDo, OperationID, IniPoint);
                ////pictureBox1.Invalidate();

                //用于6TiSCH节点信息查看
                SensorData frm = new SensorData(mDiagram.CurrObjDragIndx);
                frm.Show();
            }
            //else
            //{
            //    //
            //    //    nothing to do
            //    //
            //}
        }


        public void GetSchedulingLinkInfo()
        {
            Cursor = Cursors.WaitCursor;

            //progressBar1.Value = progressBar1.Minimum;
            progressBar1.MarqueeAnimationSpeed = 50;//设置字幕动画的速度（单位是毫秒）
            progressBar1.Style = ProgressBarStyle.Marquee;
            

            Thread bg_GetTopology = new Thread(mDiagram.GetSchedulingLinkInfo);
            //Thread cha = new Thread(new ThreadStart(threadchange));
            //BkTimer.Interval = 50;
            //BkTimer.Tick += new EventHandler(BkTimer_Tick);

            lock (mDiagram.mRouteNode)
            {
                bg_GetTopology.IsBackground = true;
                bg_GetTopology.Start();
                //cha.Start();
                //BkTimer.Start();


                //Graphics g = CreateGraphics();


                //#if ANIMATE
                //                while (bg_GetTopology.IsAlive)
                //                {
                //                    pictureBox1.Invalidate();
                //                    Application.DoEvents(); //让系统在百忙之中来响应其他事件
                //                    Thread.Sleep(10);
                //                }
                //#else
                bg_GetTopology.Join();
                //cha.Join();
                //#endif

                bg_GetTopology.Abort();
                //cha.Abort();
            }

            //BkTimer.Stop();
            //progressBar1.Value = progressBar1.Maximum;
            //System.Threading.Thread.Sleep(20);
            //progressBar1.Value = progressBar1.Minimum;
            //progressBar1.Invalidate();

            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = progressBar1.Minimum;
            Cursor = Cursors.Default;
        }

        public void getLuYouBiao_Show()
        {
            dataGridView_Material.Columns.Clear();
            mDiagram.M_OperationInfoHeader = "";

            mDiagram.GetObjLuYouBiao();
            mDiagram.SetObjLuYouBiao();
            dataGridView_Material.DataSource = mDiagram.RouteDt;

            System.Windows.Forms.DataGridViewCheckBoxColumn Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            //Column1.HeaderText = "Column1";
            //Column1.Name = "Column1";
            //Column1.ReadOnly = true;
            dataGridView_Material.Columns.Insert(0, Column1);
            dataGridView_Material.Columns[0].Width = 40;
            dataGridView_Material.Columns[0].MinimumWidth = 30;

            String text = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx].m_ID;
            if (text.Contains("HC_"))
                text = text.Substring(text.IndexOf("_") + 1);
            mDiagram.M_OperationInfoHeader = "路由表: " + text;
        }

        public void getChaoZhenBiao_Show()
        {
            dataGridView_Material.Columns.Clear();
            mDiagram.M_OperationInfoHeader = "";


            mDiagram.GetObjChaoZhenBiao();
            mDiagram.SetObjChaoZhenBiao();
            dataGridView_Material.DataSource = mDiagram.SuperframeDt;

            System.Windows.Forms.DataGridViewCheckBoxColumn Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            //Column1.HeaderText = "Column1";
            //Column1.Name = "Column1";
            //Column1.ReadOnly = true;
            dataGridView_Material.Columns.Insert(0, Column1);
            dataGridView_Material.Columns[0].Width = 40;
            dataGridView_Material.Columns[0].MinimumWidth = 30;

            String text = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx].m_ID;
            if(text.Contains("HC_"))
                text = text.Substring(text.IndexOf("_")+1);
            mDiagram.M_OperationInfoHeader = "超帧表: " + text;
        }

        public void getLianLuBiao_Show()
        {
            dataGridView_Material.Columns.Clear();
            mDiagram.M_OperationInfoHeader = "";


            mDiagram.GetObjLianLuBiao();
            mDiagram.SetObjLianLuBiao();

            dataGridView_Material.DataSource = mDiagram.LinkFormDt;

            System.Windows.Forms.DataGridViewCheckBoxColumn Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            //Column1.HeaderText = "Column1";
            //Column1.Name = "Column1";
            //Column1.ReadOnly = true;
            dataGridView_Material.Columns.Insert(0, Column1);
            dataGridView_Material.Columns[0].Width = 40;
            dataGridView_Material.Columns[0].MinimumWidth = 30;


            String text = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx].m_ID;
            if (text.Contains("HC_"))
                text = text.Substring(text.IndexOf("_") + 1);
            mDiagram.M_OperationInfoHeader = "链路表: " + text;
        }

        public void SetWIAPABiao(int OperationToDo)
        {
            if (OperationToDo == 0)
                getLuYouBiao_Show();
            else if (OperationToDo == 1)
                getChaoZhenBiao_Show();
            else if (OperationToDo == 2)
                getLianLuBiao_Show();
            else if (OperationToDo == 3)
                getStatsFlowBiao_Show();
            else
                getLuYouBiao_Show();
        }

        private void ManageObject(GObject GContainer, int OperationToDo, int OperationID, Point IniPoint)
        {
            //必须先更新各表格，以防止没有得到数据
            getLuYouBiao_Show();
            getChaoZhenBiao_Show();
            getLianLuBiao_Show();
            getStatsFlowBiao_Show();

            FrmManageObject Manage = new FrmManageObject(mDiagram.RouteDt, mDiagram.SuperframeDt, mDiagram.LinkFormDt, mDiagram.StatsFlowDt);
            Manage.InitSetting(GContainer.m_ID, GContainer.Name, GContainer.m_GatewayIPName, GContainer.m_type, GContainer.PlotType, OperationToDo, OperationID);

            Manage.StartPosition = FormStartPosition.CenterParent;
            Manage.Location = IniPoint;

            if (Manage.ShowDialog() == DialogResult.OK)
            {
                // 设置WIA-PA设备
                mDiagram.SetWIAPABiao(Manage.OperationToDo, Manage.subOperationToDo, Manage.partOperDt);

                SetWIAPABiao(Manage.OperationToDo);

                reNewTopology();
            }


            //switch (Manage.OperationToDo)
            //{
            //    case "Modify":
            //        //
            //        //Load New Data from the Manage Form
            //        //
            //        //GModified.Name = Manage.GObjName;
            //        //mDiagram.GPlotTopology.ModifyGObject(GContainer, GModified);
            //        mDiagram.ModifyGObject(GContainer, Manage.m_strName);
            //        break;

            //    case "Delete":
            //        //
            //        //      Delete the object with the original name
            //        //      not with then eventually modified name!
            //        //
            //        //mDiagram.GPlotTopology.DeleteGObject(GContainer);
            //        mDiagram.DeleteGObject(GContainer);
            //        break;
            //}
        }



        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            pictureBox1.Invalidate();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 力导向ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (mDiagram.beEffectiveData)
            {
                mDiagram.M_reInitializeFlag = false;

                bool timerState = timer_LineAnimate.Enabled;
                if (timer_LineAnimate.Enabled)
                    timer_LineAnimate.Stop();

                mDiagramArrangeAlgorithm();
                if (timerState)
                    timer_LineAnimate.Start();
            }
        }

        private void LinkInfoLabel_DoubleClick(object sender, EventArgs e)
        {

        }

        private void TSM_Luyoubiao_Click(object sender, EventArgs e)
        {
            mDiagram.m_dGV_MaterialShowType = 0;
            getLuYouBiao_Show();

            pictureBox_ListHeader.Invalidate();
        }

        private void TSM_Chaozhenbiao_Click(object sender, EventArgs e)
        {
            mDiagram.m_dGV_MaterialShowType = 1;
            getChaoZhenBiao_Show();

            pictureBox_ListHeader.Invalidate();
        }

        private void TSM_Lianlubiao_Click(object sender, EventArgs e)
        {
            mDiagram.m_dGV_MaterialShowType = 2;
            getLianLuBiao_Show();

            pictureBox_ListHeader.Invalidate();
        }

        private void 路由表设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void TSM_Jiaohuanjiliubiao_Click(object sender, EventArgs e)
        {
            mDiagram.m_dGV_MaterialShowType = 3;
            getStatsFlowBiao_Show();

            pictureBox_ListHeader.Invalidate();
        }

        public void getStatsFlowBiao_Show()
        {
            dataGridView_Material.Columns.Clear();
            mDiagram.M_OperationInfoHeader = "";

            mDiagram.GetObjStatsFlowBiao();
            mDiagram.SetObjStatsFlowBiao();

            dataGridView_Material.DataSource = mDiagram.StatsFlowDt;

            System.Windows.Forms.DataGridViewCheckBoxColumn Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            //Column1.HeaderText = "Column1";
            //Column1.Name = "Column1";
            //Column1.ReadOnly = true;
            dataGridView_Material.Columns.Insert(0, Column1);
            dataGridView_Material.Columns[0].Width = 40;
            dataGridView_Material.Columns[0].MinimumWidth = 30;

            String text = mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx].m_ID;
            if (text.Contains("HC_"))
                text = text.Substring(text.IndexOf("_")+1);
            mDiagram.M_OperationInfoHeader = "交换机流表: " + text;
        }

        private void testToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            mDiagram.beSimulationFlag = true;
            reNewTopology();
        }

        private void reNewTopology_recvData(string recvData)
        {
            mDiagram.beEffectiveData = false;
            if (timer_LineAnimate.Enabled)
                timer_LineAnimate.Stop();

            mDiagram.Clear();
            //dataGridView_Material.DataSource = null;

            ////确定连接有效
            //if ((!mDiagram.beSimulationFlag) && (string.IsNullOrEmpty(mDiagram.linkSet.ServerName) || string.IsNullOrEmpty(mDiagram.linkSet.ServerPort)))
            //{
            //    DialogResult dgRst = SetLinkInfo(ref mDiagram.linkSet);
            //    if (dgRst == DialogResult.No || dgRst == DialogResult.Cancel) //直接退出，不显示主对话框
            //        return;

            //    LinkInfoLabel.Text = "连接目标: " + mDiagram.linkSet.ServerName + ":" + mDiagram.linkSet.ServerPort;
            //}

            getNetworkTopology_recvData(recvData);
            mDiagramArrangeAlgorithm();
        }

        private void reNewTopology()
        {
            //mDiagram.linkSet.ServerName = "192.168.0.1";
            //mDiagram.linkSet.ServerPort = "8080";
            //string receiveString = "";
            //(new TCPOper()).send_ReceiveInfo(mDiagram.linkSet, "GET sendMessage", ref receiveString);

            mDiagram.beEffectiveData = false;
            if (timer_LineAnimate.Enabled)
                timer_LineAnimate.Stop();

            mDiagram.Clear();
            dataGridView_Material.DataSource = null;

            //确定连接有效
            if ((!mDiagram.beSimulationFlag) && (string.IsNullOrEmpty(mDiagram.linkSet.ServerName) || string.IsNullOrEmpty(mDiagram.linkSet.ServerPort)))
            {
                DialogResult dgRst = SetLinkInfo(ref mDiagram.linkSet);
                if (dgRst == DialogResult.No || dgRst == DialogResult.Cancel) //直接退出，不显示主对话框
                    return;

                LinkInfoLabel.Text = "连接目标: " + mDiagram.linkSet.ServerName + ":" + mDiagram.linkSet.ServerPort;
            }


            //PaintTopology();
            getNetworkTopology();
            mDiagramArrangeAlgorithm();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (mDiagram.linkSet.ServerName == null || mDiagram.linkSet.ServerPort == null)
                return;
            //mDiagram.linkSet.ServerName ="192.168.0.154";
            //mDiagram.linkSet.ServerPort = "8080";

            //设定服务器IP地址
            IPAddress ip = IPAddress.Parse(mDiagram.linkSet.ServerName);
            //Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            TcpClient NetworkClient = null;

            string path = System.Environment.CurrentDirectory + "\\BoxDataTest.txt";//文件的路径，保证文件存在。
            FileStream fs = new FileStream(path, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);


            try
            {
                //clientSocket.Connect(new IPEndPoint(ip, int.Parse(mDiagram.linkSet.ServerPort))); //配置服务器IP与端口 
                NetworkClient = TimeOutSocket.Connect(new IPEndPoint(ip, int.Parse(mDiagram.linkSet.ServerPort)), TimeOutSocket.TcpClientConnectTimeout); // 连接服务器
            }
            catch
            {
                //Console.WriteLine("连接服务器失败，请按回车键退出！");
                MessageBox.Show("连接服务器失败！","警告");
                return;
            }

            //通过 clientSocket 发送数据  
            try
            {
                //string sendMessage = textBox_Send.Text; // 获取要发送的字符串
                string sendMessage = richTextBoxPrintCtrl_Send.Text; // 获取要发送的字符串

                //string tempMessage = sendMessage;
                //TCPOper oper = new TCPOper();
                //oper.TranslateJsonMessage_WithoutSpace_ExceptN(ref tempMessage);
                ////int len = tempMessage.Length;

                //int index = sendMessage.IndexOf('{');
                //string stttr = sendMessage.Substring(0, index) + tempMessage;


                TCPOper oper = new TCPOper();

                string stttr;
                if (sendMessage.Contains("GET"))
                    stttr = sendMessage + "\r\n\r\n";
                else if (sendMessage.Contains("POST"))
                {
                    string subStr = sendMessage.Substring(sendMessage.IndexOf("{"));
                    oper.TranslateJsonMessage_WithoutSpace_ExceptN(ref subStr);
                    int len = subStr.Length;

                    string checkStr = "Content-Length:";
                    int index = 0;
                    if (sendMessage.Contains(checkStr))
                        index = sendMessage.IndexOf(checkStr);
                    else
                    {
                        index = sendMessage.IndexOf("Content-Type");
                        index = index + sendMessage.Substring(index).IndexOf("\r\n") + 2;
                        sendMessage = sendMessage.Insert(index, checkStr);
                    }

                    stttr = sendMessage.Substring(0, index + checkStr.Length) + " " + len.ToString() + "\r\n\r\n" + subStr;

                    string rightStr = "POST /WIA-PA/routetable/0/0001 HTTP/1.1\r\nContent-Type: application/json\r\nContent-Length: 76\r\n\r\n{\n\t\"num\":1,\n\t\"0120\":{\n\t\t\"src\":\"0001\",\n\t\t\"dst\":\"0001\",\n\t\t\"next\":\"0001\"\n\t}\n}\n\n";
                }
                else
                    return;


                if (NetworkClient != null && NetworkClient.Connected)
                {
                    NetworkClient.ReceiveTimeout = TimeOutSocket.TcpClientReceiveTimeout;
                    NetworkClient.SendTimeout = TimeOutSocket.TcpClientSendTimeout;

                    NetworkStream ns = NetworkClient.GetStream();
                    if (ns.CanRead && ns.CanWrite)
                    {
                        Byte[] sendBytes = Encoding.ASCII.GetBytes(stttr + "\r\n");
                        ns.Write(sendBytes, 0, sendBytes.Length);


                        if (!mDiagram.beSimulationFlag && mDiagram.beEnableRecoredOper)
                            sw.WriteLine("\r\nZhangYanSend\r\n" + sendMessage + "\r\nZhangYanSend\r\n");


                        byte[] result = new byte[10240 * 4];
                        int receiveLength = ns.Read(result, 0, 10240 * 4);
                        string recStr = Encoding.ASCII.GetString(result, 0, receiveLength);

                        richTextBoxPrintCtrl_Receive.Text = recStr;

                        if (!mDiagram.beSimulationFlag && mDiagram.beEnableRecoredOper)
                            sw.WriteLine("\r\nZhangYanReceive\r\n" + recStr + "\r\nZhangYanReceive\r\n");
                    }
                    ns.Close();
                }


                //clientSocket.Send(Encoding.ASCII.GetBytes(stttr + "\r\n"));
                //sw.WriteLine("\r\nZhangYanSend\r\n" + sendMessage + "\r\nZhangYanSend\r\n");
                ////Console.WriteLine("向服务器发送消息：{0}" + sendMessage);

                ////通过clientSocket接收数据
                //byte[] result = new byte[10240 * 4];
                //int receiveLength = clientSocket.Receive(result);
                //string recStr = Encoding.ASCII.GetString(result, 0, receiveLength);

                //textBox_Receive.Text = recStr;
                //richTextBox_Receive.Text = recStr;
                //richTextBoxPrintCtrl_Receive.Text = recStr;

                //sw.WriteLine("\r\nZhangYanReceive\r\n" + recStr + "\r\nZhangYanReceive\r\n");
            }
            catch
            {

                //clientSocket.Shutdown(SocketShutdown.Both);
                MessageBox.Show("数据请求失败！","警告");
            }
            finally
            {
                //clientSocket.Shutdown(SocketShutdown.Both);
                //clientSocket.Close();
                if (NetworkClient != null)
                {
                    NetworkClient.Close();
                }
                sw.Close();
                fs.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (mDiagram.beEffectiveData)
            {
            //    if (dst_comboBox.SelectedIndex != src_comboBox.SelectedIndex)
            //        System.Windows.Forms.MessageBox("源地址和目的地址不能一致！");

                mDiagram.beShowDiaoDu = !mDiagram.beShowDiaoDu;
                if (mDiagram.beShowDiaoDu)
                {
                    if (timer_LineAnimate.Enabled)
                        timer_LineAnimate.Stop();
                    btn_Diaodu.Text = "停止调度";

                    mDiagram.src_comboBoxText = src_comboBox.Text;
                    mDiagram.dst_comboBoxText = dst_comboBox.Text;
                    //在函数内部解析路径信息
                    GetSchedulingLinkInfo();

                    mDiagram.PosPercentage = 0;
                    Random rnd = new Random();
                    mDiagram.m_RGBPlotSetting[0] = rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[1] = rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[2] = rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[3] = 255 - rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[4] = 255 - rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[5] = 255 - rnd.Next(0, 255);

                    timer_LineAnimate.Start();
                }
                else
                {
                    timer_LineAnimate.Stop();
                    btn_Diaodu.Text = "联合调度";

                    mDiagram.mRouteNode.Clear();
                    pictureBox1.Invalidate();
                }
            }
        }

        private void realTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mDiagram.beSimulationFlag = false;
            reNewTopology();
        }

        private void 统计信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowStatisticInfo();
        }

        private void ShowStatisticInfo()
        {
            if (mDiagram.beEffectiveData)
            {
                StatInfoForm statDiag = new StatInfoForm(mDiagram.mNodes);
                statDiag.ShowDialog();
            }
        }

        //System.Windows.Forms.DataVisualization.Charting.Series series = new System.Windows.Forms.DataVisualization.Charting.Series("Spline"); 
        //series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline; 
        //series.BorderWidth = 3; 
        //series.ShadowOffset = 2;             // Populate new series with data 
        //series.Points.AddY(67);             
        //series.Points.AddY(57);             
        //series.Points.AddY(83);            
        //series.Points.AddY(23);             
        //series.Points.AddY(70);             
        //series.Points.AddY(60);             
        //series.Points.AddY(90);             
        //series.Points.AddY(20);              // Add series into the chart's series collection             
        //chart1.Series.Add(series);

        private void button4_Click(object sender, EventArgs e)
        {
            if (mDiagram.beEffectiveData)
            {
                bool timerState = timer_LineAnimate.Enabled;
                if (timer_LineAnimate.Enabled)
                    timer_LineAnimate.Stop();

                mDiagram.m_beArrangeWithForceDirect = !mDiagram.m_beArrangeWithForceDirect;

                mDiagram.M_reInitializeFlag = false;
                mDiagramArrangeAlgorithm();
                if (timerState)
                    timer_LineAnimate.Start();
            }
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Demo_SizeChanged(object sender, EventArgs e)
        {
            pictureBox2.Top = this.ClientRectangle.Top;
            pictureBox2.Width = this.ClientRectangle.Width;

            panel_Caidan.Top = 0; // pictureBox2.Bottom - panel_Caidan.Height;
            panel_Caidan.Left = 85;
            panel_Caidan.Height = pictureBox2.Height;
            btn_Gengxin.Top = panel_Caidan.Bottom - btn_Gengxin.Height;
            btn_Tongji.Top = panel_Caidan.Bottom - btn_Tongji.Height;
            btn_Pailie.Top = panel_Caidan.Bottom - btn_Pailie.Height;
            btn_Youhua.Top = panel_Caidan.Bottom - btn_Youhua.Height;
            button_Seprator.Top = panel_Caidan.Bottom - button_Seprator.Height;
            btn_Diaodu.Top = panel_Caidan.Bottom - btn_Diaodu.Height;
            dst_comboBox.Top = panel_Caidan.Bottom - dst_comboBox.Height;
            src_comboBox.Top = dst_comboBox.Top - src_comboBox.Height;



            splitContainer1.Top = pictureBox2.Bottom;
            splitContainer1.Height = statusStrip1.Top - pictureBox2.Bottom;

            splitContainer1.Left = this.ClientRectangle.Left;
            splitContainer1.Width = this.ClientRectangle.Width;

            btn_Close.Left = pictureBox2.Right - btn_Close.Width;
            btn_Max.Left = btn_Close.Left - btn_Max.Width;
            btn_Min.Left = btn_Max.Left - btn_Min.Width;
            btn_file.Left = btn_Min.Left - btn_file.Width;

            checkBox_CMD.Left = pictureBox2.Right - checkBox_CMD.Width;
            //toolStrip_cmd.Left = pictureBox2.Right - 20 - toolStrip_cmd.Width;
            //toolStrip_cmd.Top = richTextBoxPrintCtrl_Send.Bottom - toolStrip_cmd.Height;
            //splitContainer1.Panel2MinSize = pictureBox2.Right - toolStrip_cmd.Left;


            if (this.WindowState != FormWindowState.Minimized)
            {
                panel_Caidan.BackgroundImage = NetworkTopology.Properties.Resources.顶端无图标;
                Graphics g = Graphics.FromImage(panel_Caidan.BackgroundImage);
                Image image = NetworkTopology.Properties.Resources.顶端无图标;

                float Xscale = pictureBox2.ClientRectangle.Width / (float)image.Width;
                float Yscale = pictureBox2.ClientRectangle.Height / (float)image.Height;

                Point imagPt1 = new Point((int)(panel_Caidan.Location.X / Xscale), (int)(panel_Caidan.Location.Y / Yscale));
                Point imagPt2 = new Point((int)((panel_Caidan.Location.X + panel_Caidan.ClientSize.Width) / Xscale), (int)((panel_Caidan.Location.Y + panel_Caidan.ClientSize.Height) / Yscale));

                Rectangle rscRect = new Rectangle(imagPt1, new Size((int)((imagPt2.X - imagPt1.X)), (int)((imagPt2.Y - imagPt1.Y))));
                g.DrawImage(image, panel_Caidan.ClientRectangle, rscRect, GraphicsUnit.Pixel);
                panel_Caidan.BackgroundImageLayout = ImageLayout.Tile;
                panel_Caidan.Refresh();
            }

            progressBar1.Left = toolStripProgressBar1.Bounds.Left;
            progressBar1.Top = toolStripProgressBar1.Bounds.Top + statusStrip1.Top + 1;
            progressBar1.Width = toolStripProgressBar1.Bounds.Width;
            progressBar1.Height = toolStripProgressBar1.Bounds.Height - 2;

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                moveCurPosX = e.X;
                moveCurPosY = e.Y;
            }
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + (e.X - moveCurPosX), this.Location.Y + (e.Y - moveCurPosY));
            }
        }


        private void button8_Click(object sender, EventArgs e)
        {
            MaxFormOper();
        }

        private void MaxFormOper()
        {

            if (this.WindowState == FormWindowState.Maximized)
            {
                // 如果窗口已经最大化，则恢恢复为正常大小
                this.WindowState = FormWindowState.Normal;
                //pictureBox3.Image = NetworkTopology.Properties.Resources.最大化;
                btn_Max.Image = NetworkTopology.Properties.Resources.最大化;
                btn_Max.Invalidate();
            }
            else
            {
                // 否则，窗口为正常时，将其最大化
                //下面这一句决定是否遮盖任务栏
                this.MaximumSize = new Size(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);

                this.WindowState = FormWindowState.Maximized;

                //pictureBox3.Image = NetworkTopology.Properties.Resources.最大化2;
                btn_Max.Image = NetworkTopology.Properties.Resources.最大化2;
                btn_Max.Invalidate();



            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            PreviousSplitterDistance = splitContainer1.SplitterDistance;
            this.WindowState = FormWindowState.Minimized;//最小化
        }

        private void button7_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                moveCurPosX = e.X;
                moveCurPosY = e.Y;
            }
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + (e.X - moveCurPosX), this.Location.Y + (e.Y - moveCurPosY));
            }
        }

        private void pictureBox2_DoubleClick(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, MouseEventArgs e)
        {
            MaxFormOper();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_CMD.Checked)
            {
                splitContainer1.SplitterDistance = PreviousSplitterDistance;
                //checkBox1.Checked = false;
            }
            else
            {
                PreviousSplitterDistance = splitContainer1.SplitterDistance;
                splitContainer1.SplitterDistance = splitContainer1.ClientRectangle.Width;
                //checkBox1.Checked = true;
            }



        }

        private void 打印拓扑图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.DefaultExt = "Jpeg";
            saveDialog.Filter = "EMF文件|*.emf|Jpeg文件|*.Jpeg"; //|Bmp文件|*.Bmp
            saveDialog.FileName = "拓扑图.emf";
            if (saveDialog.ShowDialog() == DialogResult.Cancel)
                return;

            //被点了取消  
            if (saveDialog.FileName.IndexOf(":") < 0)
                return;

            try
            {
                Bitmap bitmapTopology = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                Graphics g = Graphics.FromImage(bitmapTopology);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                g.Clear(pictureBox1.BackColor);//背景色
                this.mDiagram.Draw(g);

                bitmapTopology.Save(saveDialog.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);

                bitmapTopology.Dispose();
                g.Dispose();

                MessageBox.Show("文件保存成功", "提示", MessageBoxButtons.OK);
            }            
            catch (Exception Err)
            {
                MessageBox.Show("文件保存操作失败！" + Err.Message, "警告", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
            //printDocument_Prev.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);

            //printPreviewDialog1.Document = printDocument_Prev;
            //PrintDialog MyPrintDg = new PrintDialog();
            //MyPrintDg.Document = printDocument_Prev;

            //if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            //    if (MyPrintDg.ShowDialog() == DialogResult.OK)
            //    {
            //        try
            //        {

            //            printDocument_Prev.DefaultPageSettings.Landscape = false;// 横向
            //            printDocument_Prev.Print();
            //        }
            //        catch
            //        {   //停止打印
            //            printDocument_Prev.PrintController.OnEndPrint(printDocument_Prev, new System.Drawing.Printing.PrintEventArgs());
            //        }
            //    }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            this.mDiagram.Draw(e.Graphics);
            //e.Graphics.DrawImage(pictureBox1.Image, 0, 0, pictureBox1.Image.Width, pictureBox1.Image.Height);
        }

        private void splitContainer2_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox_ListHeader_Paint(object sender, PaintEventArgs e)
        {
            //DrawdataGridView_Material_HeadInfo(e.Graphics, mDiagram.M_OperationInfoHeader);
            StringFormat strFormat = new StringFormat();
            strFormat.Alignment = StringAlignment.Center;
            lock (e.Graphics)
            {
                Font font = new Font("宋体", 10, FontStyle.Regular);

                float Xtemp = (float)(pictureBox_ListHeader.ClientRectangle.Width / 2);
                float Ytemp = (float)(pictureBox_ListHeader.ClientRectangle.Height / 2 - font.Height / 2);

                SolidBrush trnsRedBrush = new SolidBrush(Color.FromArgb(0, 162, 232));
                e.Graphics.FillRectangle(trnsRedBrush, pictureBox_ListHeader.ClientRectangle);

                //gcHeadInfo.DrawString(m_blockInfo[index].strHeadInfo, new Font("宋体", 11, FontStyle.Regular), brHeadInfo, Xtemp, Ytemp, strFormat);
                e.Graphics.DrawString(mDiagram.M_OperationInfoHeader, font, new SolidBrush(Color.FromArgb(255, 255, 255)), Xtemp, Ytemp, strFormat);
            }
        }

        private void DrawdataGridView_Material_HeadInfo(Graphics gcHeadInfo, String strHeadInfo)
        {

        }

        private void splitContainer2_Panel2_SizeChanged(object sender, EventArgs e)
        {
            pictureBox_ListHeader.Left = splitContainer2.Panel2.ClientRectangle.Left;
            pictureBox_ListHeader.Top = splitContainer2.Panel2.ClientRectangle.Top;
            pictureBox_ListHeader.Width = splitContainer2.Panel2.ClientRectangle.Width;

            listView__Material.Visible = true;
            listView__Material.Left = splitContainer2.Panel2.ClientRectangle.Left;
            listView__Material.Top = pictureBox_ListHeader.Bottom;
            listView__Material.Width = splitContainer2.Panel2.ClientRectangle.Width;
            listView__Material.Height = splitContainer2.Panel2.ClientRectangle.Height - pictureBox_ListHeader.Height;
            listView__Material.Invalidate();

            pictureBox_ListHeader.Invalidate();



            btn_gridviewPrint.Left = splitContainer2.Panel2.ClientRectangle.Right - btn_gridviewPrint.Width;
            btn_gridviewPrint.Top = splitContainer2.Panel2.ClientRectangle.Top;
            btn_gridviewSave.Left = btn_gridviewPrint.Left - 3 - btn_gridviewSave.Width;
            btn_gridviewSave.Top = splitContainer2.Panel2.ClientRectangle.Top;



            //pictureBox_ListHeader.Left = splitContainer2.Panel2.ClientRectangle.Left;
            //pictureBox_ListHeader.Top = splitContainer2.Panel2.ClientRectangle.Top;
            //pictureBox_ListHeader.Width = splitContainer2.Panel2.ClientRectangle.Width;

            //dataGridView_Material.Left = splitContainer2.Panel2.ClientRectangle.Left;
            //dataGridView_Material.Top = pictureBox_ListHeader.Bottom;
            //dataGridView_Material.Width = splitContainer2.Panel2.ClientRectangle.Width;
            //dataGridView_Material.Height = splitContainer2.Panel2.ClientRectangle.Height - pictureBox_ListHeader.Height;

            //pictureBox_ListHeader.Invalidate();



            //btn_gridviewPrint.Left = splitContainer2.Panel2.ClientRectangle.Right - btn_gridviewPrint.Width;
            //btn_gridviewPrint.Top = splitContainer2.Panel2.ClientRectangle.Top;
            //btn_gridviewSave.Left = btn_gridviewPrint.Left - 3 - btn_gridviewSave.Width;
            //btn_gridviewSave.Top = splitContainer2.Panel2.ClientRectangle.Top;

            ////btn_gridviewSave.Left = splitContainer2.Panel2.ClientRectangle.Left;
            ////btn_gridviewSave.Top = splitContainer2.Panel2.ClientRectangle.Top;
            ////btn_gridviewPrint.Left = btn_gridviewSave.Right + 3;
            ////btn_gridviewPrint.Top = splitContainer2.Panel2.ClientRectangle.Top;
        }

        private void splitContainer3_Panel2_SizeChanged(object sender, EventArgs e)
        {
            toolStrip_cmd.Left = splitContainer3.Panel2.ClientRectangle.Right - toolStrip_cmd.Width - 20;
            toolStrip_cmd.Top = splitContainer3.Panel2.ClientRectangle.Bottom - toolStrip_cmd.Height;

            //btn_Send.Left = splitContainer3.Panel2.ClientRectangle.Right - btn_Send.Width - 20;
            //btn_Clc.Left = btn_Send.Left - btn_Clc.Width - 5;

            //btn_Send.Top = splitContainer3.Panel2.ClientRectangle.Bottom - btn_Send.Height - 5;
            //btn_Clc.Top = btn_Send.Top;


            //textBox_Send.Left = splitContainer3.Panel2.ClientRectangle.Left;
            //textBox_Send.Top = toolStrip_cmd.Bottom;
            //textBox_Send.Width = splitContainer3.Panel2.ClientRectangle.Width;
            //textBox_Send.Height = splitContainer3.Panel2.ClientRectangle.Height - toolStrip_cmd.Height;

        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void button7_MouseMove(object sender, MouseEventArgs e)
        {
            //((Button)sender).BackColor = System.Drawing.Color.Red;
            String type = (sender.GetType()).Name;
            Graphics graphic;

            //if(type == "ToolStripButton")
            //    graphic = ((ToolStripButton)sender).CreateGraphics();
            //else if(type == "Button")
                graphic = ((Button)sender).CreateGraphics();
            int x = ((Button)sender).ClientRectangle.Left;
            int y = ((Button)sender).ClientRectangle.Top;
            int width = ((Button)sender).ClientRectangle.Width - 1;
            int height = ((Button)sender).ClientRectangle.Height - 1;

            //Color color = Color.FromArgb(230, 200, 205);
            //Brush brush = new SolidBrush(color);
            //graphic.FillRectangle(brush, x, y, width, height);

            Pen pen = new Pen(Color.Red, 3);
            graphic.DrawRectangle(pen, x, y, width, height);

        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            ((Button)sender).BackColor = System.Drawing.Color.Transparent;
        }


        private void Form4_MouseDown(object sender, MouseEventArgs e)
        {
            //鼠标按下
            bool Xflag = (e.Location.X <= this.Width) && (e.Location.X >= this.Width - 5);
            bool Yflag = (this.Height - (this.statusStrip1.Height - e.Location.Y) <= this.Height) && (this.Height - (this.statusStrip1.Height - e.Location.Y) >= this.Height - 5);
            if (Xflag || Yflag)
                isMouseDown = true;
        }

        private void Form4_MouseUp(object sender, MouseEventArgs e)
        {
            teminateResizingOpe();
        }

        private void statusStrip1_MouseLeave(object sender, EventArgs e)
        {
            teminateResizingOpe();
        }

        private void teminateResizingOpe()
        {
            if (isMouseDown)
                ResizeWindow();

            isMouseDown = false;
            //既然鼠标弹起了，那么就不能再改变窗体尺寸，拖拽方向置 none
            direction = MouseDirection.None;
            this.Cursor = Cursors.Arrow;
        }

        private void Form4_MouseMove(object sender, MouseEventArgs e)
        {
            //string CoordsMsg = "x = " + e.X.ToString() + " : y = " + e.Y.ToString();
            //toolStripStatusLabel1.Text = CoordsMsg;

            //鼠标移动过程中，坐标时刻在改变 
            //当鼠标移动时横坐标距离窗体右边缘5像素以内且纵坐标距离下边缘也在5像素以内时，要将光标变为倾斜的箭头形状，同时拖拽方向direction置为MouseDirection.Declining 
            bool Xflag = (e.Location.X <= this.Width) && (e.Location.X >= this.Width - 5);
            bool Yflag = (this.Height - (this.statusStrip1.Height - e.Location.Y) <= this.Height) && (this.Height - (this.statusStrip1.Height - e.Location.Y) >= this.Height - 5);

            if (Xflag && Yflag)
            {
                this.Cursor = Cursors.SizeNWSE;
                direction = MouseDirection.Declining;
            }
            //当鼠标移动时横坐标距离窗体右边缘5像素以内时，要将光标变为倾斜的箭头形状，同时拖拽方向direction置为MouseDirection.Herizontal
            else if (Xflag)
            {
                this.Cursor = Cursors.SizeWE;
                direction = MouseDirection.Herizontal;
            }
            //同理当鼠标移动时纵坐标距离窗体下边缘5像素以内时，要将光标变为倾斜的箭头形状，同时拖拽方向direction置为MouseDirection.Vertical
            else if (Yflag)
            {
                this.Cursor = Cursors.SizeNS;
                direction = MouseDirection.Vertical;
            }
            ////否则，以外的窗体区域，鼠标星座均为单向箭头（默认）             
            //else
            //    this.Cursor = Cursors.Arrow;
            //设定好方向后，调用下面方法，改变窗体大小

            if (isMouseDown && (Xflag || Yflag))
                ResizeWindow();
        }

        private void ResizeWindow()
        {
            //这个判断很重要，只有在鼠标按下时才能拖拽改变窗体大小，如果不作判断，那么鼠标弹起和按下时，窗体都可以改变 

            //MousePosition的参考点是屏幕的左上角，表示鼠标当前相对于屏幕左上角的坐标this.left和this.top的参考点也是屏幕，属性MousePosition是该程序的重点
            if (direction == MouseDirection.Declining)
            {
                //此行代码在mousemove事件中已经写过，在此再写一遍，并不多余，一定要写
                //this.Cursor = Cursors.SizeNWSE;
                //下面是改变窗体宽和高的代码，不明白的可以仔细思考一下
                this.Width = MousePosition.X - this.Left;
                this.Height = MousePosition.Y - this.Top;
            }
            //以下同理
            else if (direction == MouseDirection.Herizontal)
            {
                //this.Cursor = Cursors.SizeWE;
                this.Width = MousePosition.X - this.Left;
            }
            else if (direction == MouseDirection.Vertical)
            {
                //this.Cursor = Cursors.SizeNS;
                this.Height = MousePosition.Y - this.Top;
            }
            ////即使鼠标按下，但是不在窗口右和下边缘，那么也不能改变窗口大小
            //else
            //    this.Cursor = Cursors.Arrow;
            this.Invalidate();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Clear();

            richTextBoxPrintCtrl_Receive.Clear();
        }

        private void toolStrip_cmd_Paint(object sender, PaintEventArgs e)
        {
            if ((sender as ToolStrip).RenderMode == ToolStripRenderMode.System)
            {
                Rectangle rect = new Rectangle(0, 0, this.toolStrip_cmd.Width, this.toolStrip_cmd.Height);

                Pen pen = new Pen(Color.White, 2);
                e.Graphics.DrawRectangle(pen, rect);
            }

        }

        private void printDocument1_PrintPage_1(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            bool more = gridPrinter.DrawDataGridView(e.Graphics);
            if (more == true)
                e.HasMorePages = true;
        }

        private void btn_gridviewPrint_Click(object sender, EventArgs e)
        {
            //目前功能还有Bug
            //listView__Material.DoPrint();


            //下列代码支持对dataGridView_Material中的内容进行打印
            //if (InitializePrinting())
            //{
            //    PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();
            //    printPreviewDialog.Document = printDocument_DataGridview;
            //    printPreviewDialog.ShowDialog();
            //}
        }

        //定义一个bool方法
        private bool InitializePrinting()
        {
            PrintDialog printDialog = new PrintDialog();
            //printDialog.AllowCurrentPage = true;
            //printDialog.AllowPrintToFile = true;
            //printDialog.AllowSelection = true;
            //printDialog.AllowSomePages = true;
            //printDialog.PrintToFile = true;
            //printDialog.ShowHelp = true;
            //printDialog.ShowNetwork = true;

            if (printDialog.ShowDialog() != DialogResult.OK)
                return false;

            printDocument_DataGridview.DocumentName = mDiagram.M_OperationInfoHeader;
            printDocument_DataGridview.PrinterSettings = printDialog.PrinterSettings;
            printDocument_DataGridview.DefaultPageSettings = printDialog.PrinterSettings.DefaultPageSettings;
            printDocument_DataGridview.DefaultPageSettings.Margins = new Margins(20, 20, 20, 20);

            gridPrinter = new GridPrinter(dataGridView_Material, printDocument_DataGridview, true, true, mDiagram.M_OperationInfoHeader, new Font("黑体", 12, FontStyle.Bold, GraphicsUnit.Point), Color.Blue, true);
            return true;
        }

        private void Demo_Leave(object sender, EventArgs e)
        {

        }

        private void btn_gridviewSave_Click(object sender, EventArgs e)
        {
            FileOperClass fileOpe = new FileOperClass();
            lock (listView__Material)
            {
                fileOpe.ExportExcel(mDiagram.M_OperationInfoHeader, listView__Material);
            }

            //FileOperClass fileOpe = new FileOperClass();
            //lock (dataGridView_Material)
            //{
            //    fileOpe.ExportExcel(mDiagram.M_OperationInfoHeader, dataGridView_Material);
            //}
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FileOperClass fileOpe = new FileOperClass();
            lock (richTextBoxPrintCtrl_Receive)
            {
                fileOpe.ExportRichTextBoxToWord("Cmd_Records", richTextBoxPrintCtrl_Receive);
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument_RichTextBox;
            printDialog1.Document = printDocument_RichTextBox;
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
                if (printDialog1.ShowDialog() == DialogResult.OK)
                    printDocument_RichTextBox.Print();

            //PrintDialog MyPrintDg = new PrintDialog();
            //MyPrintDg.Document = printDocument_Prev;
            //if (MyPrintDg.ShowDialog() == DialogResult.OK)
            //{

            //    try
            //    {
            //        PrintDocument pd = new PrintDocument();
            //        pd.PrintPage += new PrintPageEventHandler(pd_PrintPage);
            //        // 打印文档
            //        pd.Print();
            //    }
            //    catch
            //    {   //停止打印
            //        printDocument_Prev.PrintController.OnEndPrint(printDocument_Prev, new System.Drawing.Printing.PrintEventArgs());
            //    }
            //}

        }

        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            //e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            //Font printFont;
            //printFont = new Font("Arial", 10);

            //e.Graphics.DrawString(richTextBox_Send.Text, printFont,Brushes.White,new PointF(20,20));
        }

        private void printDocument_RichTextBox_BeginPrint(object sender, PrintEventArgs e)
        {
            checkPrint = 0;
        }

        private void printDocument_RichTextBox_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Print the content of RichTextBox. Store the last character printed.
            checkPrint = richTextBoxPrintCtrl_Receive.Print(checkPrint, richTextBoxPrintCtrl_Receive.TextLength, e);

            // Check for more pages
            if (checkPrint < richTextBoxPrintCtrl_Receive.TextLength)
                e.HasMorePages = true;
            else
                e.HasMorePages = false;
        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(NetworkTopology.Properties.Resources.顶端无图标, pictureBox2.ClientRectangle);
            e.Graphics.DrawImage(NetworkTopology.Properties.Resources.顶端图标, pictureBox2.ClientRectangle.Left, pictureBox2.ClientRectangle.Top, pictureBox2.ClientRectangle.Height, pictureBox2.ClientRectangle.Height);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                const int WS_MINIMIZEBOX = 0x00020000;  // Winuser.h中定义
                CreateParams cp = base.CreateParams;
                cp.Style = cp.Style | WS_MINIMIZEBOX;   // 允许最小化操作
                return cp;
            }
        }

        private void dataGridView_Material_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex != -1)
            {
                bool ischk2 = (bool)dataGridView_Material.Rows[e.RowIndex].Cells[0].EditedFormattedValue.ToString().Equals("True");
                if (!ischk2)
                {
                    //dataGridView_Material.Rows[e.RowIndex].Cells[0].Value = true;
                    if (timer_LineAnimate.Enabled)
                        timer_LineAnimate.Stop();

                    if (mDiagram.beShowDiaoDu)
                    {
                        mDiagram.beShowDiaoDu = false;
                        btn_Diaodu.Text = "联合调度";
                    }
                    mDiagram.mRouteNode.Clear();

                    if (mDiagram.m_dGV_MaterialShowType == 0 && mDiagram.CurrObjDragIndx >= 0)
                    {
                        Node operNode = mDiagram.mNodes.Find(c => c.M_ID == mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx].m_ID);
                        String strPre = operNode.M_ID.Substring(0, operNode.M_ID.IndexOf('_') + 1);

                        NodePair pairItem = new NodePair();
                        pairItem.srcNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["src"].Value.ToString());
                        pairItem.dstNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["next"].Value.ToString());
                        mDiagram.mRouteNode.Add(pairItem);

                        pairItem = new NodePair();
                        pairItem.srcNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["next"].Value.ToString());
                        pairItem.dstNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["dst"].Value.ToString());
                        mDiagram.mRouteNode.Add(pairItem);
                    }

                    mDiagram.PosPercentage = 0;
                    Random rnd = new Random();
                    mDiagram.m_RGBPlotSetting[0] = rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[1] = rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[2] = rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[3] = 255 - rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[4] = 255 - rnd.Next(0, 255);
                    mDiagram.m_RGBPlotSetting[5] = 255 - rnd.Next(0, 255);

                    timer_LineAnimate.Start();
                }
                else
                {
                    //dataGridView_Material.Rows[e.RowIndex].Cells[0].Value = false;
                    mDiagram.mRouteNode.Clear();
                    pictureBox1.Invalidate();
                    if (timer_LineAnimate.Enabled)
                        timer_LineAnimate.Stop();
                }
            }
        }

        private void 显示设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //iSelectedAreaIndex
            //if (mDiagram.mNodes == null || mDiagram.mNodes.Count <= 0)
            //{
            //    return;
            //}


            //mDiagram.si.screenMinHeight = yMinLen;
            //mDiagram.si.screenMinWidth = xMinLen;
            //mDiagram.si.screenSingleColumn = bSingleColumn;
            ////mDiagram.si.screenXLeftFull=m_blockInfo[iSelectedAreaIndex].
            //double fXStart = m_fXStart[iSelectedAreaIndex];
            //double fXEnd = m_fXEnd[iSelectedAreaIndex];

            //double fXStartIndex = m_blockInfo[iSelectedAreaIndex].fStartIndex;
            //double fXEndIndex = m_blockInfo[iSelectedAreaIndex].fEndIndex;

            //// m_blockInfo[index].fStartIndex = 0;
            //// m_blockInfo[index].fEndIndex = m_dSig[iSelectedAreaIndex].Length - 1;
            //// m_fXStart[index] += (m_blockInfo[index].fStartIndex - fXStartIndex) * (fXEnd - fXStart) / (fXEndIndex - fXStartIndex);
            ////  m_fXEnd[index] += (m_blockInfo[index].fEndIndex - fXEndIndex) * (fXEnd - fXStart) / (fXEndIndex - fXStartIndex);

            //mDiagram.si.screenXLeftFull = fXStart + (-fXStartIndex) * (fXEnd - fXStart) / (fXEndIndex - fXStartIndex);
            //mDiagram.si.screenXRightFull = fXEnd + (m_dSig[iSelectedAreaIndex].Length - 1 - fXEndIndex) * (fXEnd - fXStart) / (fXEndIndex - fXStartIndex);
            //mDiagram.si.screenXLeftShow = m_fXStart[iSelectedAreaIndex];
            //mDiagram.si.screenXRightShow = m_fXEnd[iSelectedAreaIndex];


            //mDiagram.si.screenYDown = m_fYStart[iSelectedAreaIndex];
            //mDiagram.si.screenYUp = m_fYEnd[iSelectedAreaIndex];
            //mDiagram.si.screenXLog = false;
            //mDiagram.si.screenYLog = false;
            //mDiagram.si.screenMinWidth = xMinLen;
            //mDiagram.si.screenMinHeight = yMinLen;
            //mDiagram.si.leftRemain = m_nLeftRemain[iSelectedAreaIndex];
            //mDiagram.si.rightRemain = m_nRightRemain[iSelectedAreaIndex];
            //mDiagram.si.upRemain = m_nTopRemain[iSelectedAreaIndex];
            //mDiagram.si.downRemain = m_nBottomRemain[iSelectedAreaIndex];
            //mDiagram.si.xMinPix = xMinPix;
            //mDiagram.si.yMinPix = yMinPix;


            //mDiagram.si.drwClr[0] = penAreaRect.Color;
            //mDiagram.si.drwClr[1] = penGrid.Color;
            //mDiagram.si.drwClr[2] = penShape.Color;
            //mDiagram.si.drwClr[3] = penCursor.Color;
            //// string strClr = brHeadInfo.ToString();
            //// mDiagram.si.drwClr[4] = ColorTranslator.FromHtml(strClr);            
            ////  brHeadInfo.

            ////   (Color)ColorConverter.ConvertFromString(brHeadInfo.ToString());
            //mDiagram.si.drwClr[5] = brShadowGround.Color;

            //mDiagram.si.drwClr[6] = brBkGround.Color;

            //mDiagram.si.drwWth[0] = penAreaRect.Width;
            //mDiagram.si.drwWth[1] = penGrid.Width;
            //mDiagram.si.drwWth[2] = penShape.Width;
            //mDiagram.si.drwWth[3] = penCursor.Width;

            //FrmScreenProp fsp = new FrmScreenProp(si);
            //if (fsp.ShowDialog() == DialogResult.OK)
            //{
            //    si = fsp.si;
            //    setDrowTool(3);
            //    Reset(this.Width, this.Height);
            //}
        }

        private void pictureBox2_Resize(object sender, EventArgs e)
        {
            pictureBox2.Refresh();
        }

        private void btn_Tongji_Click(object sender, EventArgs e)
        {
            ShowStatisticInfo();
        }

        private void 连线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mDiagram.screenSettingInfo.beNodeName = !mDiagram.screenSettingInfo.beNodeName;
            pictureBox1.Invalidate();
        }

        private void 图例ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            mDiagram.screenSettingInfo.beLegend = !mDiagram.screenSettingInfo.beLegend;
            pictureBox1.Invalidate();
        }

        private void ConnectorNameToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            mDiagram.screenSettingInfo.beNodeConnectorName = !mDiagram.screenSettingInfo.beNodeConnectorName;
            pictureBox1.Invalidate();
        }

        private void 默认设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mDiagram.screenSettingInfo.beLegend = true;
            mDiagram.screenSettingInfo.beNodeName = true;
            mDiagram.screenSettingInfo.beNodeConnectorName = true;
            pictureBox1.Invalidate();
        }

        

        private void toolStripButton1_Paint_1(object sender, PaintEventArgs e)
        {
            drawButtonRetangular(sender, e);
        }

        private void toolStripButton1_MouseMove(object sender, MouseEventArgs e)
        {
            beToolStripButton_MouseMove = true;
            ((ToolStripButton)sender).Invalidate();
        }

        private void toolStripButton1_MouseLeave(object sender, EventArgs e)
        {
            beToolStripButton_MouseMove = false;
            ((ToolStripButton)sender).Invalidate();
        }

        private void drawButtonRetangular(object sender, PaintEventArgs e)
        {
            
            //Rectangle tac = toolStrip_cmd.Bounds;
            //ToolStripButton btn = (ToolStripButton)sender;
            //if (beToolStripButton_MouseMove)
            //{

            //    int x = btn.Bounds.Left + 1;
            //    int y = btn.Bounds.Top + 1;
            //    int width = btn.Bounds.Width - 2;
            //    int height = btn.Bounds.Height - 3;

            //    //Color color = Color.FromArgb(230, 200, 205);
            //    //Brush brush = new SolidBrush(color);
            //    //graphic.FillRectangle(brush, x, y, width, height);
            //    Pen pen = new Pen(Color.Red, 2);
            //    e.Graphics.DrawRectangle(pen, x, y, width, height);

            //    btn.BackColor = Color.Red;
            //}
            //else
            //{
                ((ToolStripButton)sender).BackColor = System.Drawing.Color.Transparent;
            //}
        }

        private void 获取panidToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /WIA-PA/panid HTTP/1.1";
        }

        private void 获取WIAPA拓扑信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /WIA-PA/topology/0  HTTP/1.1";
        }

        private void 获取回程网络拓扑信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /networks/topology HTTP/1.1";
        }

        private void 获取WIAPA设备路由表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /WIA-PA/routetable/0/0001  HTTP/1.1";
        }

        private void 设置WIAPA设备路由表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = @"POST /WIA-PA/routetable/0/0001 HTTP/1.1";
        }

        private void 获取WIAPA设备超帧表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /WIA-PA/superframe/0/0001 HTTP/1.1";
        }

        private void 设置WIAPA设备超帧表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "POST /WIA-PA/superframe/0/0001 HTTP/1.1";
        }

        private void 获取WIAPA设备链路表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /WIA-PA/linktable/0/0100 HTTP/1.1";
        }

        private void 设置WIAPA设备链路表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "POST /WIA-PA/linktable/0/0100 HTTP/1.1";
        }

        private void 获取交换机流表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "GET /stats/flow/1 HTTP/1.1";
        }

        private void 增加交换机流表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "POST /stats/flowentry/add HTTP/1.1";
        }

        private void 删除交换机流表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "POST /stats/flowentry/delete HTTP/1.1";
        }

        private void 联合调度ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBoxPrintCtrl_Send.Text = "POST /WIA-PA/scheduling HTTP/1.1\r\nContent-Type: application/json\r\n{\r\n\"src\":{\r\n      \"panid\":\"1\",\r\n      \"ip\":\"2016::11\",\r\n      \"shortaddr\":\"0101\"\r\n},\r\n\"dst\":{\r\n      \"panid\":\"0\",\r\n      \"ip\":\"2016::7\",\r\n      \"shortaddr\":\"0101\"\r\n}\r\n}";
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            mDiagram.beEnableRecoredOper = !mDiagram.beEnableRecoredOper;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            switch (button1.Text)
            {
                case "监听":
                    {
                        ConnectAction();
                        break;
                    }
                case "停止":
                    {
                        StopAction();
                        break;
                    }
            }
        }

        private void ConnectAction()
        {
            try//先执行try后面的语句，如果没有异常则顺序执行，如果出现异常则转入执行catch后面的语句
            {
                button1.Text = "停止";//文本框显示由监听转化为停止
                comboBox3.Enabled = false;
                textBox2.Enabled = false;

                mDiagram.linkSet.ServerName = comboBox3.SelectedItem.ToString();
                mDiagram.linkSet.ServerPort = textBox2.Text;

                //textBox2.ReadOnly = true;//textBox2转化为可读
                m_mainSocket = new Socket(AddressFamily.InterNetworkV6, SocketType.Stream, ProtocolType.Tcp);
                m_mainSocket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

                if (mDiagram.linkSet.ServerName == "IPv6Any")
                {
                    m_mainSocket.Bind(new IPEndPoint(IPAddress.IPv6Any, Convert.ToInt32(mDiagram.linkSet.ServerPort)));//终结点和本地终结点
                }
                else
                {
                    m_mainSocket.Bind(new IPEndPoint(IPAddress.Parse(mDiagram.linkSet.ServerName), Convert.ToInt32(mDiagram.linkSet.ServerPort)));
                }
                m_mainSocket.Listen(10);

                m_mainSocket.BeginAccept(new AsyncCallback(OnClientConnect), m_mainSocket);

                LinkInfoLabel.Text = "连接目标: " + mDiagram.linkSet.ServerName + ":" + mDiagram.linkSet.ServerPort;
            }
            catch (System.Exception ex)
            {
                button1.Text = "监听";//文本框显示由监听转化为停止
                comboBox3.Enabled = true;
                textBox2.Enabled = true;

                LinkInfoLabel.Text = "连接目标: Null";
                MessageBox.Show(ex.Message + "1", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);//报错
            }
        }

        private void StopAction()
        {
            button1.Text = "监听";//button1文本由停止转化为监听
            comboBox3.Enabled = true;
            textBox2.Enabled = true;

            //textBox2.ReadOnly = false;//textBox2转化为不可读
            CloseSockets();//停止通信
        }

        private void CloseSockets()//停止通信
        {//toolStripStatusLabel2
            try
            {
                toolStripStatusLabel1.Text = "未连接";//连接状态显示为未连接
                if (m_mainSocket != null)
                {
                    m_mainSocket.Close();
                    m_mainSocket = null;
                }
                for (int i = 0; i < m_workerSocketList.Count; i++)
                {
                    Socket workerSocket = (Socket)m_workerSocketList[i];
                    if (workerSocket != null)
                    {
                        workerSocket.Close();
                        workerSocket = null;
                    }
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "关闭套接字错误");//关闭出现异常
            }
        }

        private void 清空ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox_RecMsg.Items.Clear();//listBox_RecMsg（列表框）清空
        }


        public void OnClientConnect(IAsyncResult asyn)//在客户端连接
        {
            try
            {
                if (m_mainSocket != null)
                {
                    Socket workerSocket = m_mainSocket.EndAccept(asyn);
                    Interlocked.Increment(ref m_clientCount);
                    m_workerSocketList.Add(workerSocket);
                    string msg = "Welcome " + workerSocket.RemoteEndPoint.ToString();
                    listBox_RecMsg.Items.Add(workerSocket.RemoteEndPoint.ToString() + " Connected");
                    SendMsgToClient(msg, m_clientCount);
                    UpdateClientListControl();
                    WaitForData(workerSocket, m_clientCount);
                    m_mainSocket.BeginAccept(new AsyncCallback(OnClientConnect), m_mainSocket);
                }
            }
            catch (ObjectDisposedException)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\n OnClientConnection: Socket has been closed\n");
            }
            //catch (System.Exception se)
            //{
            //    MessageBox.Show(se.Message);
            //}
        }

        void SendMsgToClient(string msg, int clientNumber)//向客户端发送数据
        {
            byte[] byData = System.Text.Encoding.ASCII.GetBytes(msg);
            Socket workerSocket = (Socket)m_workerSocketList[clientNumber - 1];
            workerSocket.Send(byData);
        }

        private void UpdateClientListControl()//更新客户端列表控件
        {
            if (InvokeRequired)
            {
                //ConnectedType.BeginInvoke(new UpdateClientListCallback(UpdateClientList), null);
            }
            else
            {
                UpdateClientList();
            }
        }

        public void WaitForData(Socket soc, int clientNumber)//等待数据
        {
            SocketPacket theSocPkt = new SocketPacket(soc, clientNumber);
            try
            {
                if (pfnWorkerCallBack == null)
                {
                    pfnWorkerCallBack = new AsyncCallback(OnDataReceived);//接收数据
                }
                soc.BeginReceive(theSocPkt.dataBuffer, 0, theSocPkt.dataBuffer.Length, SocketFlags.None, pfnWorkerCallBack, theSocPkt);
            }
            catch (SocketException se)//发生SocketException错误
            {
                if (se.ErrorCode == 10053)//错误代码
                {
                    string msg = theSocPkt.string_RemoteEndPoint.ToString() + " Disconnected";
                    AppendToRichEditControl(msg);
                    m_workerSocketList[theSocPkt.m_clientNumber - 1] = null;
                    UpdateClientListControl();
                }
                else
                {
                    MessageBox.Show(se.Message);
                }
            }
        }


        ////////////////////以上为套接字传输算法等
        ///以下为显示函数之类



        public void OnDataReceived(IAsyncResult asyn)
        {
            SocketPacket socketData = (SocketPacket)asyn.AsyncState;
            try
            {

                int A, B, C;//湿度
                int D, E, F;//温度
                int iRx = socketData.m_currentSocket.EndReceive(asyn);
                char[] chars = new char[5000];//[iRx + 1];
                System.Text.Decoder d = System.Text.Encoding.UTF8.GetDecoder();//UTF8
                int charLen = d.GetChars(socketData.dataBuffer, 0, iRx, chars, 0);
                System.String szData = new System.String(chars);
                
                //仅供测试
                //bool singtestFlag = true;
                //if (singtestFlag)
                //{
                //    szData = "Relationship address Number is:0x00Parent address is:0x0000Parent category is:0x0001Child address is:0x3525Child category is:0x0003Number of total address relationship is:0x03Relationship address Number is:0x01Parent address is:0x0000Parent category is:0x0001Child address is:0x3527Child category is:0x0003Number of total address relationship is:0x03Relationship address Number is:0x02Parent address is:0x3525Parent category is:0x0003Child address is:0x4525Child category is:0x0003Number of total address relationship is:0x03"; //0x05 0x03 0x04 0x02 0x10 0x01 0x75 0x7F 0xF9 0x92
                //    chars = szData.ToCharArray();
                //}

                // 该判定方法不严谨，有可能出现小概率的误判
                int index1 = szData.IndexOf("Relationship");
                int index2 = szData.IndexOf("Number of total address relationship is");
                if (index1 >= 0 && index2 >= 0 && index1 < index2)
                {
                    // 对网络拓扑进行更新
                    mDiagram.beSimulationFlag = false;
                    reNewTopology_recvData(szData);
                    //singtestFlag = false;
                }
                else if (szData.Length >= 45 && JudgeModBus(szData, 9)) // 判断是否为有效的传感器数据，添加Modbus校验
                {
                    if ((int)chars[18] < 58) { A = chars[18] - 48; }
                    else { A = chars[18] - 55; }

                    if ((int)chars[22] < 58) { B = chars[22] - 48; }
                    else { B = chars[22] - 55; }

                    if ((int)chars[23] < 58) { C = chars[23] - 48; }
                    else { C = chars[23] - 55; }
                    Common.shidu = (decimal)(A * 256 + B * 16 + C) / 10;     //湿度

                    if ((int)chars[28] < 58) { D = chars[28] - 48; }
                    else { D = chars[28] - 55; }

                    if ((int)chars[32] < 58) { E = chars[32] - 48; }
                    else { E = chars[32] - 55; }

                    if ((int)chars[33] < 58) { F = chars[33] - 48; }
                    else { F = chars[23] - 55; }
                    Common.wendu = (decimal)(D * 256 + E * 16 + F) / 10;     //温度


                    int tempNum = int.Parse(chars[3].ToString());
                    //Common.SensorNo[tempNum] = true;
                    Common.温度[tempNum] = Common.wendu;
                    Common.湿度[tempNum] = Common.shidu;

                    if (chars[3] != 0 && Common.shidu != 0 && Common.wendu != 0)
                    {
                        HomePage WriteinNewFile = new HomePage();
                        WriteinNewFile.WriteNewData_c(chars[3], Common.shidu, Common.wendu);
                        ListViewItem item = new ListViewItem();
                        item.Text = chars[3].ToString() + "#";//Common.xhi.ToString();
                        //Common.xhi++;
                        item.SubItems.Add(Common.shidu.ToString());
                        item.SubItems.Add(Common.wendu.ToString());
                        item.SubItems.Add(DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString().Replace(":", "-"));

                        this.listView__Material.Items.Add(item);
                        this.listView__Material.EndUpdate();
                        this.listView__Material.Items[this.listView__Material.Items.Count - 1].EnsureVisible();
                    }
                }

                //if (chars[45] == 'x' && chars[70] == 'x')
                //{
                //    if ((int)chars[18 + 44] < 58) { A = chars[18 + 44] - 48; }
                //    else { A = chars[18 + 44] - 55; }

                //    if ((int)chars[22 + 44] < 58) { B = chars[22 + 44] - 48; }
                //    else { B = chars[22 + 44] - 55; }

                //    if ((int)chars[23 + 44] < 58) { C = chars[23 + 44] - 48; }
                //    else { C = chars[23 + 44] - 55; }
                //    Common.shidu = (decimal)(A * 256 + B * 16 + C) / 10;     //湿度

                //    if ((int)chars[28 + 44] < 58) { D = chars[28 + 44] - 48; }
                //    else { D = chars[28 + 44] - 55; }

                //    if ((int)chars[32 + 44] < 58) { E = chars[32 + 44] - 48; }
                //    else { E = chars[32 + 44] - 55; }

                //    if ((int)chars[33 + 44] < 58) { F = chars[33 + 44] - 48; }
                //    else { F = chars[33 + 44] - 55; }
                //    Common.wendu = (decimal)(D * 256 + E * 16 + F) / 10;     //温度

                //    if (chars[3 + 44] == '5')////////////////////////////////可以更改数以显示更多其他可能设备 (原来为8)
                //    {
                //        Common.Sensor机器号8 = true;
                //        Common.温度[8] = Common.wendu;
                //        Common.湿度[8] = Common.shidu;
                //        textBox3.Text = Common.shidu.ToString();
                //        textBox1.Text = Common.wendu.ToString();
                //    }
                //    else if (chars[3 + 44] == '2')
                //    {
                //        Common.Sensor机器号2 = true;
                //        Common.温度[2] = Common.wendu;
                //        Common.湿度[2] = Common.shidu;
                //        textBox5.Text = Common.shidu.ToString();
                //        textBox4.Text = Common.wendu.ToString();
                //    }
                //    else if (chars[3 + 44] == '4')
                //    {
                //        Common.Sensor机器号4 = true;
                //        Common.温度[4] = Common.wendu;
                //        Common.湿度[4] = Common.shidu;
                //        textBox6.Text = Common.shidu.ToString();
                //        textBox7.Text = Common.wendu.ToString();
                //    }

                //    if (chars[3 + 44] != 0 && Common.shidu != 0 && Common.wendu != 0)
                //    {
                //        HomePage WriteinNewFile = new HomePage();
                //        WriteinNewFile.WriteNewData_c(chars[3 + 44], Common.shidu, Common.wendu);
                //        ListViewItem item = new ListViewItem();
                //        item.Text = chars[3 + 44].ToString();//Common.xhi.ToString();
                //        //Common.xhi++;
                //        item.SubItems.Add(Common.shidu.ToString());
                //        item.SubItems.Add(Common.wendu.ToString());
                //        item.SubItems.Add(DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString().Replace(":", "-"));
                //        this.listView1.Items.Add(item);
                //        this.listView1.EndUpdate();
                //        this.listView1.Items[this.listView1.Items.Count - 1].EnsureVisible();
                //    }

                //}
                ////////////////////////////////////////////////////////////////////////////////
                AppendToRichEditControl(socketData.string_RemoteEndPoint.ToString() + ":" + szData);//显示函数

                //AppendToRichEditControl(socketData.string_RemoteEndPoint.ToString() + ":" + szData);//显示函数
                Socket workerSocket = (Socket)socketData.m_currentSocket;
                byte[] byData = System.Text.Encoding.ASCII.GetBytes(szData);
                workerSocket.Send(byData);
                WaitForData(socketData.m_currentSocket, socketData.m_clientNumber);
            }//没有异常的情况
            catch (ObjectDisposedException)//捕获到ObjectDisposedException异常
            {
                System.Diagnostics.Debugger.Log(0, "1", "\nOnDataReceived: Socket has been closed\n");
            }
            catch (SocketException se)//捕获到SocketException异常
            {
                if (se.ErrorCode == 10054)//如果错误代码是10054
                {
                    string msg = socketData.string_RemoteEndPoint.ToString() + " Disconnected";////
                    AppendToRichEditControl(msg);//msg显示Disconnected
                    m_workerSocketList[socketData.m_clientNumber - 1] = null;
                    UpdateClientListControl();
                }
                else
                {
                    MessageBox.Show(se.Message);
                }
            }
        }

        /// <summary>
        /// 判断是否符合ModBus格式
        /// </summary>
        /// <param name="strGet"></param>
        /// <param name="len">Modbus字节数 含校验位</param>
        /// <returns></returns>
        public bool JudgeModBus(string strGet, int len)
        {
            string subStr = strGet.Substring(0,len*5);
            subStr = subStr.Replace("0x", "");

            
            byte[] data = HexStrTobyte(subStr);
            if (data != null)
            {
                byte[] crc = CRC16(data);
                if (crc[1] == data[len - 2] && crc[0] == data[len - 1])
                    return true;
                else
                    return false;
            }
            else
                return false;
        }

        private byte[] HexStrTobyte(string hexString) //16 进制转换成字符串   hexString格式为"01 AB C3"
        {
            try
            {
                hexString = hexString.Replace(" ", "");
                if ((hexString.Length % 2) != 0)
                    hexString += " ";
                byte[] returnBytes = new byte[hexString.Length / 2];
                for (int i = 0; i < returnBytes.Length; i++)
                    returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2).Trim(), 16);
                return returnBytes;
            }
            catch
            {
                return null; 
            }
            
        }

        public byte[] CRC16(byte[] data)
        {
            int len = data.Length-2;
            if (len > 0)
            {
                ushort crc = 0xFFFF;

                for (int i = 0; i < len; i++)
                {
                    crc = (ushort)(crc ^ (data[i]));
                    for (int j = 0; j < 8; j++)
                    {
                        crc = (crc & 1) != 0 ? (ushort)((crc >> 1) ^ 0xA001) : (ushort)(crc >> 1);
                    }
                    System.Diagnostics.Debug.WriteLine("i=" + i.ToString() + "," + crc.ToString());
                }
                byte hi = (byte)((crc & 0xFF00) >> 8); //高位置
                byte lo = (byte)(crc & 0x00FF); //低位置

                return new byte[] { hi, lo };
            }
            return new byte[] { 0, 0 };
        }

        ////////以下为显示函数
        private void AppendToRichEditControl(string msg)//显示函数，显示msg数据
        {

            if (InvokeRequired)
            {
                object[] pList = { msg };
                listBox_RecMsg.BeginInvoke(new UpdateRichEditCallback(OnUpdateRichEdit), pList);////////////////

            }
            else
            {
                OnUpdateRichEdit(msg);
            }
        }

        private void OnUpdateRichEdit(string msg)
        {
            if (msg.Length > 20)
            {
                listBox_RecMsg.Items.Add(msg);////////////////////////////////////////
            }
        }

        void UpdateClientList()
        {
            try
            {
                toolStripStatusLabel1.Text = "未连接";//显示连接状态
                for (int i = 0; i < m_workerSocketList.Count; i++)
                {
                    Socket workerSocket = (Socket)m_workerSocketList[i];
                    if (workerSocket != null)
                    {
                        if (workerSocket.Connected)
                        {
                            toolStripStatusLabel1.Text = "已连接";
                        }
                        else
                        {
                            workerSocket.Close();
                            workerSocket = null;
                        }
                    }
                }
            }
            catch (System.Exception se)
            {
                MessageBox.Show(se.Message);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }



        private void Button2_Click(object sender, EventArgs e)
        {
            Common.点击的Sensor = 1;
            button1_Click_Page frm = new button1_Click_Page();
            frm.Show();

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Common.点击的Sensor = 2;
            button1_Click_Page frm = new button1_Click_Page();
            frm.Show();
        }
        private void Button4_Click(object sender, EventArgs e)
        {
            Common.点击的Sensor = 3;
            button1_Click_Page frm = new button1_Click_Page();
            frm.Show();

        }

        private void Button11_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        private void richTextBoxPrintCtrl_Receive_TextChanged(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //Common.点击的Sensor = 1;
            SensorData frm = new SensorData(5);
            frm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text == "拓扑")
            {
                PreviousSplitterDistance_Topology_Info = splitContainer4.SplitterDistance;
                splitContainer4.SplitterDistance = splitContainer4.Width;
                button5.Text = "信息";
            }
            else if (button5.Text == "信息")
            {
                splitContainer4.SplitterDistance = 0;
                button5.Text = "双显";
            }
            else
            {
                splitContainer4.SplitterDistance = PreviousSplitterDistance_Topology_Info;
                button5.Text = "拓扑";
            }
        }

        private void button11_Click_1(object sender, EventArgs e)
        {

        }

        private void btn_file_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (button5.Text == "拓扑")
            {
                PreviousSplitterDistance_Topology_Info = splitContainer4.SplitterDistance;
                splitContainer4.SplitterDistance = splitContainer4.Width;
                button5.Text = "信息";
            }
            else if (button5.Text == "信息")
            {
                splitContainer4.SplitterDistance = 0;
                button5.Text = "双显";
            }
            else
            {
                splitContainer4.SplitterDistance = PreviousSplitterDistance_Topology_Info;
                button5.Text = "拓扑";
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {

        }
        
    }
}
