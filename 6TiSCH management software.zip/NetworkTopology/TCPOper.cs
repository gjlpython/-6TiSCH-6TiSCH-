﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data;
using System.Reflection;
using System.IO;
using System.Threading;


namespace NetworkTopology
{
    /// <summary>
    /// 保存路径
    /// </summary>
    public struct NodePair
    {
        public Node srcNode;
        public Node dstNode;
    }

    /// <summary>
    /// 连接IP及端口
    /// </summary>
    public struct DataLinkInfo
    {
        //public string LocalName;
        //public string LocalPort;

        public string ServerName;
        public string ServerPort;

        //public string SDNIPName;
        //public string SDNPort;
    }

    /// <summary>
    /// 发送数据
    /// </summary>
    public struct postStruct
    {
        public string sendString; // = null; // 要发送的字符串
        public byte[] sendData; // = null; // 要发送的字节数组
        public TcpClient sendClient; // = null; // TcpClient实例
        public NetworkStream sendStream; // = null;// 网络流
    }

    //IPAddress localIP = IPAddress.Parse("127.0.0.1");
    //        int localPort = 12000;
    /// <summary>
    /// 接收数据
    /// </summary>
    public struct getStruct
    {
        public TcpListener listener;
        public TcpClient Getclient;// = null;
        public NetworkStream Getstream;// = null;
        public byte[] getBuffer;// = null;
        public string getString;// = null;
    }


    /// <summary>
    /// panid
    /// </summary>
    public class panid
    {
        public string PanidID { get; set; }
        public string GatewayIP { get; set; }
    }


    /// <summary>
    /// WIA-PA拓扑信息
    /// </summary>
    public class WIAPATopology2
    {
        public src src
        { 
            get; set; 
        } 
        public dst dst { get; set; }
        //public string num { get; set;}
    }
    public class src
    {
        public string category { get; set; }
        public string address { get; set; }
    }
    public class dst
    {
        public string category { get; set; }
        public string address { get; set; }
    }


    /// <summary>
    /// 路由表信息
    /// </summary>
    public class WIAPALuYou
    {
        public string RoutedID { get; set; }
        public partWIAPALuYou partWIAPALuYou { get; set; }
    }
    public class partWIAPALuYou
    {
        public string src { get; set; }
        public string dst { get; set; }
        public string next { get; set; }
    }


    /// <summary>
    /// 超帧表信息
    /// </summary>
    public class WIAPAChaoZhen
    {
        public string SuperframeID { get; set; }
        public partWIAPAChaoZhen partWIAPAChaoZhen { get; set; }
    }
    public class partWIAPAChaoZhen
    {
        public string ActiveFlag { get; set; }
        public string ActiveSlot { get; set; }
        public string NumberSlots { get; set; }
        public string SuperframeMultiple { get; set; }
    }


    /// <summary>
    /// 链路表信息
    /// </summary>
    public class WIAPALianLu
    {
        public string LinkID { get; set; }
        public partWIAPALianLu partWIAPALianLu { get; set; }
    }
    public class partWIAPALianLu
    {
        public string LinkType { get; set; }
        public string ChannelIndex { get; set; }
        public string LinkSuperFrameNum { get; set; }
        public string SuperframeID { get; set; }
        public string RelativeSlotNumber { get; set; }
        public string ActiveFlag { get; set; }
        public string NeighborID { get; set; }
    }

    /// <summary>
    /// 交换机流表
    /// </summary>
    public class StatsFlow
    {
        public string dpid { get; set; }
        public partStatsFlow partStatsFlow { get; set; }
    }
    public class partStatsFlow
    {
        public string[] actions { get; set; }
        public string idle_timeout { get; set; }
        public string cookie { get; set; }
        public string packet_count { get; set; }
        public string hard_timeout { get; set; }
        public string byte_count { get; set; }
        public string duration_sec { get; set; }
        public string duration_nsec { get; set; }

        public string priority { get; set; }
        public string length { get; set; }
        public string flags { get; set; }

        public string table_id { get; set; }
        public string match { get; set; }
    }


    class TimeOutSocket
    {
        public const int TcpClientConnectTimeout = 3000;
        public const int TcpClientSendTimeout = 5000;
        public const int TcpClientReceiveTimeout = 10000;

        private static bool IsConnectionSuccessful = false;
        private static Exception socketexception;
        private static ManualResetEvent TimeoutObject = new ManualResetEvent(false);

        public static TcpClient Connect(IPEndPoint remoteEndPoint, int timeoutMSec)
        {
            TimeoutObject.Reset();
            socketexception = null;

            string serverip = Convert.ToString(remoteEndPoint.Address);
            int serverport = remoteEndPoint.Port;
            TcpClient tcpclient = new TcpClient();

            tcpclient.BeginConnect(serverip, serverport, new AsyncCallback(CallBackMethod), tcpclient);

            if (TimeoutObject.WaitOne(timeoutMSec, false))
            {
                if (IsConnectionSuccessful)
                {

                    return tcpclient;
                }
                else
                {
                    throw socketexception;
                }
            }
            else
            {
                tcpclient.Close();
                throw new TimeoutException("TimeOut Exception");
            }
        }
        private static void CallBackMethod(IAsyncResult asyncresult)
        {
            try
            {
                IsConnectionSuccessful = false;
                TcpClient tcpclient = asyncresult.AsyncState as TcpClient;

                if (tcpclient.Client != null)
                {
                    tcpclient.EndConnect(asyncresult);
                    IsConnectionSuccessful = true;
                }
            }
            catch (Exception ex)
            {
                IsConnectionSuccessful = false;
                socketexception = ex;
            }
            finally
            {
                TimeoutObject.Set();
            }
        }

    }


    class TCPOper
    {

        //public DataLinkInfo linkSet_TCPOper;
        public bool beSimulationFlag;
        public bool beEnableRecoredOper;

        /// <summary>
        /// 将DataTable 转换为实体对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        private static List<T> TableToEntity<T>(DataTable dt) where T : class,new()
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return null;
            }

            Type type = typeof(T);
            List<T> list = new List<T>();

            foreach (DataRow row in dt.Rows)
            {
                PropertyInfo[] pArray = type.GetProperties();
                T entity = new T();
                foreach (PropertyInfo p in pArray)
                {
                    if (row[p.Name] is Int64)
                    {
                        p.SetValue(entity, Convert.ToInt32(row[p.Name]), null);
                        continue;
                    }
                    if (p.Name == "actions")
                        continue;
                    else
                        p.SetValue(entity, row[p.Name], null);

                }
                list.Add(entity);
            }
            return list;
        }


        #region DataTable 转换为Json 字符串
        /// <summary>     
        /// Datatable转换为Json     
        /// </summary>    
        /// <param name="table">Datatable对象</param>     
        /// <returns>Json字符串</returns>     
        public static string ToJson(DataTable dt, List<string> BianLiangToJson)
        {
            StringBuilder jsonString = new StringBuilder();
            //jsonString.Append("[");
            DataRowCollection drc = dt.Rows;
            for (int i = 0; i < drc.Count; i++)
            {
                jsonString.Append("{\n");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    string strKey = dt.Columns[j].ColumnName;
                    int index = BianLiangToJson.FindIndex(c => c == strKey);
                    if (index < 0)
                        continue;

                    string strValue = drc[i][j].ToString();
                    Type type = dt.Columns[j].DataType;
                    jsonString.Append("\"" + strKey + "\": ");
                    //strValue = StringFormat(strValue, type);
                    if (j < dt.Columns.Count - 1)
                    {
                        jsonString.Append(strValue + ",\n");
                    }
                    else
                    {
                        jsonString.Append(strValue + "\n");
                    }
                }
                jsonString.Append("},");
            }
            jsonString.Remove(jsonString.Length - 1, 1);
            //jsonString.Append("]");
            return jsonString.ToString();
        }

        /// <summary>
        /// 格式化字符型、日期型、布尔型
        /// </summary>
        /// <param name="str"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        private static string StringFormat(string str, Type type)
        {
            if (type == typeof(string))
            {
                str = String2Json(str);
                str = "\"" + str + "\"";
            }
            else if (type == typeof(DateTime))
            {
                str = "\"" + str + "\"";
            }
            else if (type == typeof(bool))
            {
                str = str.ToLower();
            }
            else if (type != typeof(string) && string.IsNullOrEmpty(str))
            {
                str = "\"" + str + "\"";
            }
            return str;
        }
        /// <summary>
        /// 过滤特殊字符
        /// </summary>
        /// <param name="s">字符串</param>
        /// <returns>json字符串</returns>
        private static string String2Json(String s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                char c = s.ToCharArray()[i];
                switch (c)
                {
                    case '\"':
                        sb.Append("\\\""); break;
                    case '\\':
                        sb.Append("\\\\"); break;
                    case '/':
                        sb.Append("\\/"); break;
                    case '\b':
                        sb.Append("\\b"); break;
                    case '\f':
                        sb.Append("\\f"); break;
                    case '\n':
                        sb.Append("\\n"); break;
                    case '\r':
                        sb.Append("\\r"); break;
                    case '\t':
                        sb.Append("\\t"); break;
                    default:
                        sb.Append(c); break;
                }
            }
            return sb.ToString();
        }
        #endregion




        /// <summary>
        /// 测试目标连接是否有效
        /// </summary>
        //public bool CheckConnectionEffectiveness(DataLinkInfo linkSetInput)
        public static void CheckConnectionEffectiveness(object linkSet, ref object rst)
        {
            DataLinkInfo linkSetInput = (DataLinkInfo)linkSet;
            IPAddress ip = IPAddress.Parse(linkSetInput.ServerName); // 服务器地址 
            int port = int.Parse(linkSetInput.ServerPort); // 服务器端口号

            bool connectedFlag = false;
            try
            {

                TcpClient NetworkClient = TimeOutSocket.Connect(new IPEndPoint(ip, port), TimeOutSocket.TcpClientConnectTimeout); // 连接服务器
                if (NetworkClient != null)
                {
                    connectedFlag = NetworkClient.Connected;
                    NetworkClient.Close();
                }

                rst = connectedFlag;
            }
            catch (SocketException e)
            {
                Console.WriteLine(e.Message); // 输出发生错误的信息
                rst = false;
            }
        }

        public bool CheckConnectionEffectiveness_Realize(DataLinkInfo linkSet)
        {
            IPAddress ip = IPAddress.Parse(linkSet.ServerName); // 服务器地址 
            int port = int.Parse(linkSet.ServerPort); // 服务器端口号


            bool connectedFlag = false;
            try
            {
                TcpClient NetworkClient = TimeOutSocket.Connect(new IPEndPoint(ip, port), TimeOutSocket.TcpClientConnectTimeout); // 连接服务器
                if (NetworkClient != null)
                {
                    connectedFlag = NetworkClient.Connected;
                    NetworkClient.Close();
                }

                return connectedFlag;
                //Result = connectedFlag;
            }
            catch (SocketException e)
            {
                Console.WriteLine(e.Message); // 输出发生错误的信息
                //Result = false;
                return false;
            }
        }

        /// <summary>
        /// 获取panid
        /// </summary>
        /// <param name="remoteLinkSet"></param>
        /// <param name="m_panid"></param>
        public void getWIAPAPanidList(DataLinkInfo remoteLinkSet, ref List<panid> m_panid)
        {
            //IPAddress remoteIP = IPAddress.Parse("127.0.0.1");//远程主机IP
            //int remotePort = 11000;//远程主机端口

            m_panid.Clear();

            int networkInfoType = 1;
            string strJson = getnetworkInfo(networkInfoType, remoteLinkSet, "GET /WIA-PA/panid HTTP/1.1");
            bool effectiveJson = strJson.Contains("200 OK");

            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));
            if (effectiveJson)
            {
                Regex regex = new Regex("\"[^\"]*\"");
                MatchCollection results = regex.Matches(strJson);
                string str;
                for (int i = 0; i < results.Count; )
                {
                    str = results[i].Value.Replace("\"", "");
                    if (str != "num")
                    {
                        panid add_panid = new panid();
                        add_panid.PanidID = str;
                        add_panid.GatewayIP = results[i + 1].Value.Replace("\"", "");
                        m_panid.Add(add_panid);
                    }
                    i = i + 2;
                }
            }

            //判断获取数据是否正确
            if (!effectiveJson || int.Parse(patternStr_aftersubstr(strJson, "\"num\"", "\"[^\"]*\"")) != m_panid.Count)
            {
                //System.Diagnostics.Debug.Assert(false, "getWIAPAPanidList错误！");
                m_panid.Clear();
            }
        }


        /// <summary>
        /// 返回strJson中，字符串spcstr位置之前，满足pattern格式的字符串
        /// </summary>
        /// <param name="strJson"></param>
        /// <param name="substr"></param>
        /// <returns></returns>
        private string patternStr_Previoussubstr(string strJson, string spcstr, string pattern)
        {
            int index = strJson.LastIndexOf(spcstr);
            if (index >= 0)
            {
                strJson = strJson.Substring(0, index);
                Regex regex = new Regex(pattern);
                MatchCollection results = regex.Matches(strJson);

                //string newregex = "/b{\r\n\"src\"*}}/b";
                //MatchCollection results = Regex.Matches(strJson, newregex, RegexOptions.IgnorePatternWhitespace |
                //                                                    RegexOptions.ExplicitCapture |    //提高检索效率  
                //                                                    RegexOptions.RightToLeft);          //从左向右匹配字符串);

                spcstr = results[results.Count - 1].Value.Replace("\"", "");
                return spcstr;
            }
            else
                return "";
            //return results[1].Value;
        }


        /// <summary>
        /// 返回strJson中，字符串spcstr位置之后，满足pattern格式的字符串
        /// </summary>
        /// <param name="strJson"></param>
        /// <param name="substr"></param>
        /// <returns></returns>
        private string patternStr_aftersubstr(string strJson, string spcstr, string pattern)
        {
            int index = strJson.IndexOf(spcstr);
            strJson = strJson.Substring(index, strJson.Length - index);

            Regex regex = new Regex(pattern);
            MatchCollection results = regex.Matches(strJson);

            //string newregex = "/b{\r\n\"src\"*}}/b";
            //MatchCollection results = Regex.Matches(strJson, newregex, RegexOptions.IgnorePatternWhitespace |
            //                                                    RegexOptions.ExplicitCapture |    //提高检索效率  
            //                                                    RegexOptions.RightToLeft);          //从左向右匹配字符串);

            spcstr = results[1].Value.Replace("\"", "");
            return spcstr;
            //return results[1].Value;
        }



        /// <summary>
        /// 获取以特定字符串开头和特定字符串结尾的字符串
        /// </summary>
        /// <param name="TxtStr"></param>
        /// <param name="FirstStr"></param>
        /// <param name="SecondStr"></param>
        /// <returns></returns>
        private int GetStr(int baseIndex, string TxtStr, string FirstStr, string SecondStr, ref string selectedStr)
        {
            int FirstSite = -1;
            int SecondSite = -1;
            if (FirstStr.IndexOf(SecondStr, 0) != -1)
                selectedStr = "";
            else
            {
                FirstSite = TxtStr.IndexOf(FirstStr, 0);
                SecondSite = TxtStr.IndexOf(SecondStr, FirstSite + 1);
                if (FirstSite == -1 || SecondSite == -1)
                    selectedStr = "";
                else
                    selectedStr = TxtStr.Substring(FirstSite, SecondSite - FirstSite + SecondStr.Length);
                //selectedStr = TxtStr.Substring(FirstSite + FirstStr.Length, SecondSite - FirstSite - FirstStr.Length);
            }
            return baseIndex + SecondSite;
        }

        /// <summary>
        /// 获取以包含特定字符串的Json字符串
        /// </summary>
        /// <param name="TxtStr"></param>
        /// <param name="FirstStr"></param>
        /// <param name="SecondStr"></param>
        /// <returns></returns>
        private int GetStr(int baseIndex, string TxtStr, string targetStr, ref string selectedStr)
        {
            string subStr = TxtStr.Substring(baseIndex);
            int targetIndex = subStr.IndexOf(targetStr);

            int FirstSite = 0;
            int SecondSite = 0;
            if (targetIndex >= 0)
            {
                targetIndex = targetIndex + baseIndex;

                string str2 = TxtStr.Substring(0, targetIndex);
                FirstSite = str2.LastIndexOf('{');

                string str3 = TxtStr.Substring(targetIndex);
                SecondSite = str3.IndexOf('}') + targetIndex;


                if (FirstSite < 0 || SecondSite < targetIndex)
                    selectedStr = "";
                else
                    selectedStr = TxtStr.Substring(FirstSite, SecondSite - FirstSite + 1);

                return SecondSite;
            }
            else
            {
                selectedStr = "";
                return TxtStr.Length;
            }

        }

        /// <summary>
        /// 用于生成联合调度用  地址信息
        /// </summary>
        /// <param name="remoteLinkSet"></param>
        /// <param name="srcNode"></param>
        /// <param name="dstNode"></param>
        /// <param name="mRouteNode"></param>
        public string getSchedulingLinkInfo_WithNode(Node srcNode)
        {
            String strPanid = "{\r\n\"panid\":\"" + srcNode.mPanid.PanidID.ToString() + "\",\r\n";
            String strIP = "\"ip\":\"" + srcNode.mPanid.GatewayIP.ToString() + "\",\r\n";
            String strAddr = "\"shortaddr\":\"" + srcNode.M_ID.Substring(srcNode.M_ID.IndexOf('_') + 1).ToString() + "\"\r\n}";
            return strPanid + strIP + strAddr;
        }

        /// <summary>
        /// 获取联合调度命令信息
        /// </summary>
        /// <param name="srcNode"></param>
        /// <param name="dstNode"></param>
        /// <param name="mRouteNode"></param>
        public void GetSchedulingLinkInfo(DataLinkInfo remoteLinkSet, Node srcNode, Node dstNode, ref List<NodePair> mRouteNode)
        {
            mRouteNode.Clear();

            String strSerializeJSON1 = getSchedulingLinkInfo_WithNode(srcNode);
            String strSerializeJSON2 = getSchedulingLinkInfo_WithNode(dstNode);

            //在每一个:后加上一个空格
            //strSerializeJSON = InsertStringAfterIndicatedStr(strSerializeJSON, ":", " ");

            string str = "POST /WIA-PA/scheduling HTTP/1.1";
            str = postNetwork_StringSetting(remoteLinkSet, str);

            string Mes = str + "{\r\n\"src\":" + strSerializeJSON1 + ",\r\n\"dst\":" + strSerializeJSON2 + "\r\n}\r\n";


            string strJson = PostnetworkInfo(remoteLinkSet, Mes);
            //if (strJson.Length > 0 && !strJson.Contains("200 OK"))
            //    System.Diagnstring strJsonostics.Debug.Assert(false, "GetSchedulingLinkInfo！");


            bool effectiveJson = strJson.Contains("200 OK");
            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));


            if (effectiveJson)
            {
                // 将数据分为"network"与"WIAPAsrc"两部分 分别进行处理
                int index1 = strJson.IndexOf("network");
                int index2 = strJson.IndexOf("WIAPAsrc");
                int index3 = strJson.IndexOf("WIAPAdst");
                string strJson_network = strJson.Substring(index1, index2 - index1);
                string strJson_WIAPAsrc = strJson.Substring(index2, index3 - index2);
                string strJson_WIAPAdst = strJson.Substring(index3);

                //List<WIAPATopology2> WIAPATopologyList = new List<WIAPATopology2>();
                //Node tempNode1, tempNode2;
                WIAPATopology2 mWIAPATopology = new WIAPATopology2();
                NodePair nodepair;


                // 将dpid换成address
                strJson_network = strJson_network.Replace("dpid", "address");
                string selectedStr;
                int curIndex;
                List<NodePair> mRouteNodeSrc = new List<NodePair>();
                List<NodePair> mRouteNodeDst = new List<NodePair>();

                // 对strJson_WIAPAsrc进行处理
                selectedStr = "";
                curIndex = GetStr(0, strJson_WIAPAsrc, "{\"src\"", "}}", ref selectedStr);
                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //WIAPATopologyList.Add(JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr));
                    mWIAPATopology = JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr);
                    nodepair = new NodePair();
                    nodepair.dstNode = srcNode.Diagram.mNodes.Find(c => c.M_ID == srcNode.mPanid.PanidID + "_" + mWIAPATopology.src.address);
                    nodepair.srcNode = srcNode.Diagram.mNodes.Find(c => c.M_ID == srcNode.mPanid.PanidID + "_" + mWIAPATopology.dst.address);
                    mRouteNodeSrc.Add(nodepair);

                    curIndex = GetStr(curIndex, strJson_WIAPAsrc.Substring(curIndex), "{\"src\"", "}}", ref selectedStr);
                }

                // 对strJson_WIAPAdst进行处理
                selectedStr = "";
                curIndex = GetStr(0, strJson_WIAPAdst, "{\"src\"", "}}", ref selectedStr);
                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //WIAPATopologyList.Add(JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr));
                    mWIAPATopology = JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr);
                    nodepair = new NodePair();
                    nodepair.srcNode = srcNode.Diagram.mNodes.Find(c => c.M_ID == dstNode.mPanid.PanidID + "_" + mWIAPATopology.src.address);
                    nodepair.dstNode = srcNode.Diagram.mNodes.Find(c => c.M_ID == dstNode.mPanid.PanidID + "_" + mWIAPATopology.dst.address);
                    mRouteNodeDst.Add(nodepair);

                    curIndex = GetStr(curIndex, strJson_WIAPAdst.Substring(curIndex), "{\"src\"", "}}", ref selectedStr);
                }

                // 先对strJson_network进行处理
                selectedStr = "";
                curIndex = GetStr(0, strJson_network, "{\"src\"", "}}", ref selectedStr);

                String srcPanid = mRouteNodeSrc[0].srcNode.M_ID.Substring(0, mRouteNodeSrc[0].srcNode.M_ID.IndexOf("_"));
                String dstPanid = mRouteNodeDst[0].dstNode.M_ID.Substring(0, mRouteNodeDst[0].dstNode.M_ID.IndexOf("_"));

                List<String> srcHCNodeID = new List<String>();
                List<String> dstHCNodeID = new List<String>();
                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //WIAPATopologyList.Add(JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr));
                    mWIAPATopology = JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr);
                    nodepair = new NodePair();
                    Node node1, node2;

                    if (mWIAPATopology.src.category == "2" && mWIAPATopology.dst.category == "2")
                    {
                        node1 = srcNode.Diagram.mNodes.Find(c => c.M_ID == "HC_" + mWIAPATopology.src.address);
                        node2 = srcNode.Diagram.mNodes.Find(c => c.M_ID == "HC_" + mWIAPATopology.dst.address);

                        nodepair.dstNode = node1;
                        nodepair.srcNode = node2;
                    }
                    else
                    {
                        if (mWIAPATopology.src.category == "2" && mWIAPATopology.dst.category == "3")
                        {
                            node1 = srcNode.Diagram.mNodes.Find(c => c.M_ID == "HC_" + mWIAPATopology.src.address); //c.mPanid.PanidID == "HC" &&
                            node2 = srcNode.Diagram.mNodes.Find(c => c.M_GatewayIPName == mWIAPATopology.dst.address);
                        }
                        else //if(mWIAPATopology.src.category == "3" && mWIAPATopology.dst.category == "2")
                        {
                            if (mWIAPATopology.src.category != "3" || mWIAPATopology.dst.category != "2")
                                MessageBox.Show("调度过程返回数据错误！", "警告");

                            node1 = srcNode.Diagram.mNodes.Find(c => c.M_ID == "HC_" + mWIAPATopology.dst.address); //c.mPanid.PanidID == "HC" &&
                            node2 = srcNode.Diagram.mNodes.Find(c => c.M_GatewayIPName == mWIAPATopology.src.address);
                        }

                        if (node2.M_ID.Substring(0, node2.M_ID.IndexOf("_")) == srcPanid)
                        {
                            nodepair.dstNode = node1;
                            nodepair.srcNode = node2;
                            srcHCNodeID.Add(node1.M_ID);
                        }
                        else
                        {
                            nodepair.dstNode = node2;
                            nodepair.srcNode = node1;
                            dstHCNodeID.Add(node1.M_ID);
                        }
                    }

                    mRouteNode.Add(nodepair);
                    curIndex = GetStr(curIndex, strJson_network.Substring(curIndex), "{\"src\"", "}}", ref selectedStr);
                }

                // ZYan 20170714
                List<NodePair> tempNodePair = new List<NodePair>();
                for (int i = 0; i<mRouteNode.Count;i++)
                {
                    if (mRouteNode[i].srcNode.M_type == mRouteNode[i].dstNode.M_type)
                    {
                        bool beSwitchFlag = false;
                        for (int index = 0; index < srcHCNodeID.Count; index++)
                        {
                            if (mRouteNode[i].dstNode.M_ID == srcHCNodeID[index])
                            {
                                beSwitchFlag = true;
                                break;
                            }
                        }
                        if (!beSwitchFlag)
                        {
                            for (int index = 0; index < dstHCNodeID.Count; index++)
                            {
                                if (mRouteNode[i].srcNode.M_ID == dstHCNodeID[index])
                                {
                                    beSwitchFlag = true;
                                    break;
                                }
                            }
                        }
                        if (beSwitchFlag)
                        {
                            NodePair temp = new NodePair();
                            temp.dstNode = mRouteNode[i].srcNode;
                            temp.srcNode = mRouteNode[i].dstNode;
                            tempNodePair.Add(temp);
                        }
                        else
                            tempNodePair.Add(mRouteNode[i]);
                    }
                    else
                        tempNodePair.Add(mRouteNode[i]);
                }
                mRouteNode = tempNodePair;


                //List<String> srcHCNodeID = new List<String>();
                //List<String> dstHCNodeID = new List<String>();
                //while (!string.IsNullOrEmpty(selectedStr))
                //{
                //    //WIAPATopologyList.Add(JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr));
                //    mWIAPATopology = JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr);
                //    nodepair = new NodePair();
                //    if (mWIAPATopology.src.category == "2")
                //        nodepair.srcNode = srcNode.Diagram.mNodes.Find(c => c.M_ID == "HC_" + mWIAPATopology.src.address); //c.mPanid.PanidID == "HC" &&
                //    else
                //        nodepair.srcNode = srcNode.Diagram.mNodes.Find(c => c.M_GatewayIPName == mWIAPATopology.src.address);

                //    if (mWIAPATopology.dst.category == "2")
                //        nodepair.dstNode = srcNode.Diagram.mNodes.Find(c => c.M_ID == "HC_" + mWIAPATopology.dst.address); //c.mPanid.PanidID == "HC"  &&
                //    else
                //        nodepair.dstNode = srcNode.Diagram.mNodes.Find(c => c.M_GatewayIPName == mWIAPATopology.dst.address); //c.mPanid.PanidID == "HC" &&


                //    // 根据PanidID将dstNode和srcNode交换一次
                //    bool flag1 = (mRouteNodeSrc[0].srcNode.M_ID.Substring(0, mRouteNodeSrc[0].srcNode.M_ID.IndexOf("_")) == nodepair.dstNode.M_ID.Substring(0, nodepair.dstNode.M_ID.IndexOf("_")));
                //    bool flag2 = (mRouteNodeDst[0].dstNode.M_ID.Substring(0, mRouteNodeDst[0].dstNode.M_ID.IndexOf("_")) == nodepair.srcNode.M_ID.Substring(0, nodepair.srcNode.M_ID.IndexOf("_")));
                //    if ( flag1||flag2)
                //    {
                //        Node temp = nodepair.dstNode;
                //        nodepair.dstNode = nodepair.srcNode;
                //        nodepair.srcNode = temp;
                //    }


                //    //记录源和目的的ID  ZYan 20170714
                //    //if (nodepair.srcNode.M_GatewayIPName != "" &&  nodepair.dstNode.M_ID.Contains("HC"))
                //    //    srcHCNodeID.Add(nodepair.dstNode.M_ID);
                //    //else if (nodepair.srcNode.M_ID.Contains("HC") && nodepair.dstNode.M_GatewayIPName != "")
                //    //    dstHCNodeID.Add(nodepair.srcNode.M_ID);
                    
                //    mRouteNode.Add(nodepair);
                //    curIndex = GetStr(curIndex, strJson_network.Substring(curIndex), "{\"src\"", "}}", ref selectedStr);
                //}

                // ZYan 20170714
                //List<NodePair> tempNodePair = new List<NodePair>();
                //for (int i = 0; i<mRouteNode.Count;i++)
                //{
                //    bool beSwitchFlag = false;
                //    for(int index = 0;index < srcHCNodeID.Count; index++)
                //    {
                //        if (mRouteNode[i].dstNode.M_ID == srcHCNodeID[index])
                //        {
                //            beSwitchFlag = true;
                //            break;
                //        }
                //    }
                //    for(int index = 0;index < dstHCNodeID.Count; index++)
                //    {
                //        if (mRouteNode[i].srcNode.M_ID == dstHCNodeID[index])
                //        {
                //            beSwitchFlag = true;
                //            break;
                //        }
                //    }


                //    if(beSwitchFlag)
                //    {
                //        NodePair temp = new NodePair();
                //        temp.dstNode = mRouteNode[i].srcNode;
                //        temp.srcNode = mRouteNode[i].dstNode;
                //        tempNodePair.Add(temp);
                //    }
                //    else
                //    {
                //        tempNodePair.Add(mRouteNode[i]);
                //    }
                //}
                //mRouteNode = tempNodePair;


                mRouteNode.AddRange(mRouteNodeSrc);
                mRouteNode.AddRange(mRouteNodeDst);
            }

            ////解析路劲信息
            //Node operNode = mDiagram.mNodes.Find(c => c.M_ID == mDiagram.GPlotTopology.GObjects[mDiagram.CurrObjDragIndx].m_ID);
            //String strPre = operNode.M_ID.Substring(0, operNode.M_ID.IndexOf('_') + 1);

            //NodePair pairItem = new NodePair();
            //pairItem.srcNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["src"].Value.ToString());
            //pairItem.dstNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["next"].Value.ToString());
            //mDiagram.mRouteNode.Add(pairItem);

            //pairItem = new NodePair();
            //pairItem.srcNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["next"].Value.ToString());
            //pairItem.dstNode = mDiagram.mNodes.Find(c => c.M_ID == strPre + dataGridView_Material.Rows[e.RowIndex].Cells["dst"].Value.ToString());
            //mDiagram.mRouteNode.Add(pairItem);
        }



        public void GetObjLuYouBiao(int networkInfoType, DataLinkInfo remoteLinkSet, string nodeID, ref List<WIAPALuYou> mWIAPALuYou)
        {
            string[] sArray = nodeID.Split('_');
            string str = "GET /WIA-PA/routetable/" + sArray[0] + "/" + sArray[1] + " HTTP/1.1";

            string strJson = getnetworkInfo(networkInfoType, remoteLinkSet, str);
            bool effectiveJson = strJson.Contains("200 OK");

            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));

            int newAddedNo = 0;
            if (effectiveJson)
            {
                string selectedStr = "";
                int curIndex = GetStr(0, strJson, "{\"src\"", "}", ref selectedStr);
                // 获取RoutedID
                string RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"src\"", "\"[^\"]*\"");

                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //MessageBox.Show(selectedStr);
                    WIAPALuYou tempWIAPALuYou = new WIAPALuYou();
                    tempWIAPALuYou.RoutedID = RoutedIDStr;
                    tempWIAPALuYou.partWIAPALuYou = JsonConvert.DeserializeObject<partWIAPALuYou>(selectedStr);

                    mWIAPALuYou.Add(tempWIAPALuYou);
                    newAddedNo++;

                    curIndex = GetStr(curIndex, strJson.Substring(curIndex), "{\"src\"", "}", ref selectedStr);
                    RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"src\"", "\"[^\"]*\"");
                }
            }

            // 判断实际获取，与报文中num值 是否一致
            if (!effectiveJson || int.Parse(patternStr_aftersubstr(strJson, "\"num\"", "\"[^\"]*\"")) != newAddedNo)
            {
                //System.Diagnostics.Debug.Assert(false, "GetObjLuYouBiao！");
                mWIAPALuYou.Clear();
            }
        }

        /// <summary>
        /// 获取CheckStr中 第order个pattern 所在的位置索引
        /// </summary>
        /// <param name="CheckStr"></param>
        /// <param name="pattern"></param>
        /// <param name="order"></param>
        public int StringIndexOf(string CheckStr, string pattern, int order)
        {
            int fIndex0, flag;
            int num = 1;

            fIndex0 = CheckStr.IndexOf(pattern);
            flag = fIndex0;
            num++;
            while (flag > 0 && num <= order)
            {
                flag = CheckStr.Substring(fIndex0 + 1).IndexOf(pattern);
                fIndex0 = CheckStr.Substring(fIndex0 + 1).IndexOf(pattern) + fIndex0 + 1;
                num++;
            }
            if (flag < 0)
                return flag;
            else
                return fIndex0;
        }


        public void GetObjStatsFlowBiao(int networkInfoType, DataLinkInfo remoteLinkSet, string nodeID, ref List<StatsFlow> mStatsFlow)
        {
            string[] sArray = nodeID.Split('_');
            string str = "GET /stats/flow/" + sArray[1] + " HTTP/1.1";

            string strJson = getnetworkInfo(networkInfoType, remoteLinkSet, str);

            bool effectiveJson = strJson.Contains("200 OK");

            List<string> matchArr = new List<string>();
            if (effectiveJson)
            {
                //将所有的match 之后的{}内容换成 "\"ReplacePartForSimplification\""
                int fIndex0 = 0;

                int order = 1;
                fIndex0 = StringIndexOf(strJson, "\"match\"", order);
                while (fIndex0 > 0)
                {
                    int fIndex1 = strJson.Substring(fIndex0).IndexOf("{") + fIndex0;
                    int fIndex2 = strJson.Substring(fIndex0).IndexOf("}") + fIndex0;

                    matchArr.Add(strJson.Substring(fIndex1, fIndex2 - fIndex1 + 1));
                    strJson = strJson.Substring(0, fIndex1) + "\"ReplacePartForSimplification\"" + strJson.Substring(fIndex2 + 1);
                    order++;

                    fIndex0 = StringIndexOf(strJson, "\"match\"", order);
                }
            }

            //fIndex0 = strJson.Substring(fIndex0).IndexOf("\"match\"");
            //while (fIndex0 > 0)
            //{
            //    int fIndex1 = strJson.Substring(fIndex0).IndexOf("{") + fIndex0;
            //    int fIndex2 = strJson.Substring(fIndex0).IndexOf("}") + fIndex0;

            //    matchArr.Add(strJson.Substring(fIndex1, fIndex2 - fIndex1 + 1));
            //    strJson = strJson.Substring(0, fIndex1) + "待替换对象" + strJson.Substring(fIndex2+1);

            //    fIndex0 = strJson.Substring(fIndex0+10).IndexOf("\"match\"") + fIndex0;
            //}


            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));

            int newAddedNo = 0;
            if (effectiveJson)
            {
                string selectedStr = "";
                int curIndex = GetStr(0, strJson, "{\"actions\"", "}", ref selectedStr);
                // 获取RoutedID
                string RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"actions\"", "\"[^\"]*\"");

                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //MessageBox.Show(selectedStr);
                    StatsFlow tempStatsFlow = new StatsFlow();
                    tempStatsFlow.dpid = RoutedIDStr; //RoutedIDStr 所有partStatsFlow共用
                    tempStatsFlow.partStatsFlow = JsonConvert.DeserializeObject<partStatsFlow>(selectedStr);

                    mStatsFlow.Add(tempStatsFlow);
                    newAddedNo++;

                    curIndex = GetStr(curIndex, strJson.Substring(curIndex), "{\"actions\"", "}", ref selectedStr);
                }
            }

            // 判断实际获取，与报文中num值 是否一致
            if (!effectiveJson || mStatsFlow.Count != newAddedNo || mStatsFlow.Count != matchArr.Count)
            {
                //System.Diagnostics.Debug.Assert(false, "GetObjStatsFlowBiao！");
                mStatsFlow.Clear();
            }
            else
            {
                // 将match值恢复
                for (int i = 0; i < mStatsFlow.Count; i++)
                    mStatsFlow[i].partStatsFlow.match = matchArr[i];
            }

        }


        public void GetObjChaoZhenBiao(int networkInfoType, DataLinkInfo remoteLinkSet, string nodeID, ref List<WIAPAChaoZhen> mWIAPAChaoZhen)
        {
            string[] sArray = nodeID.Split('_');
            string str = "GET /WIA-PA/superframe/" + sArray[0] + "/" + sArray[1] + " HTTP/1.1";

            string strJson = getnetworkInfo(networkInfoType, remoteLinkSet, str);
            bool effectiveJson = strJson.Contains("200 OK");

            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));

            int newAddedNo = 0;
            if (effectiveJson)
            {
                string selectedStr = "";
                int curIndex = GetStr(0, strJson, "\"ActiveFlag\"", ref selectedStr);
                // 获取RoutedID
                string RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "\"ActiveFlag\"", "\"[^\"]*\"");

                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //MessageBox.Show(selectedStr);
                    WIAPAChaoZhen tempWIAPAChaoZhen = new WIAPAChaoZhen();
                    tempWIAPAChaoZhen.SuperframeID = RoutedIDStr;
                    tempWIAPAChaoZhen.partWIAPAChaoZhen = JsonConvert.DeserializeObject<partWIAPAChaoZhen>(selectedStr);

                    mWIAPAChaoZhen.Add(tempWIAPAChaoZhen);
                    newAddedNo++;

                    curIndex = GetStr(curIndex, strJson, "\"ActiveFlag\"", ref selectedStr);
                    RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "\"ActiveFlag\"", "\"[^\"]*\"");
                }

                //string selectedStr = "";
                //int curIndex = GetStr(0, strJson, "{\"ActiveFlag\"", "}", ref selectedStr);

                //// 获取RoutedID
                //string RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"ActiveFlag\"", "\"[^\"]*\"");

                //while (!string.IsNullOrEmpty(selectedStr))
                //{
                //    //MessageBox.Show(selectedStr);
                //    WIAPAChaoZhen tempWIAPAChaoZhen = new WIAPAChaoZhen();
                //    tempWIAPAChaoZhen.SuperframeID = RoutedIDStr;
                //    tempWIAPAChaoZhen.partWIAPAChaoZhen = JsonConvert.DeserializeObject<partWIAPAChaoZhen>(selectedStr);

                //    mWIAPAChaoZhen.Add(tempWIAPAChaoZhen);
                //    newAddedNo++;

                //    curIndex = GetStr(curIndex, strJson.Substring(curIndex), "{\"ActiveFlag\"", "}", ref selectedStr);
                //    RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"ActiveFlag\"", "\"[^\"]*\"");
                //}

            }

            // 判断实际获取，与报文中num值 是否一致
            if (!effectiveJson || int.Parse(patternStr_aftersubstr(strJson, "\"num\"", "\"[^\"]*\"")) != newAddedNo)
            {
                //System.Diagnostics.Debug.Assert(false, "GetObjChaoZhenBiao！");
                mWIAPAChaoZhen.Clear();
            }
        }

        public string InsertStringAfterIndicatedStr(string strToOper, string IndicatedStr, string InsertString)
        {
            int baseIndex = 0;
            int index = strToOper.IndexOf(IndicatedStr);
            while (index >= 0)
            {
                strToOper.Insert(baseIndex + index + IndicatedStr.Length, InsertString);

                baseIndex = baseIndex + index + IndicatedStr.Length + InsertString.Length;
                string tempStr = strToOper.Substring(baseIndex);
                index = tempStr.IndexOf(IndicatedStr);
            }
            return strToOper;
        }


        public void setLuYouBiao(DataLinkInfo remoteLinkSet, string nodeID, DataTable partOperDt)
        {
            // 将DataTable转换为类实例
            //WIAPALuYou temp = new WIAPALuYou();
            //temp.RoutedID = partOperDt.Rows[0][0].ToString();
            //partOperDt.Columns.RemoveAt(0);

            string newID = partOperDt.Rows[0][0].ToString();

            List<partWIAPALuYou> userList = TableToEntity<partWIAPALuYou>(partOperDt);
            string strSerializeJSON = JsonConvert.SerializeObject(userList[0], Formatting.Indented);
            //在每一个:后加上一个空格
            //strSerializeJSON = InsertStringAfterIndicatedStr(strSerializeJSON, ":", " ");


            string[] sArray = nodeID.Split('_');
            string str = "POST /WIA-PA/routetable/" + sArray[0] + "/" + sArray[1] + " HTTP/1.1";
            str = postNetwork_StringSetting(remoteLinkSet, str);


            string Mes = str + "{\r\n\"num\": 1,\r\n" + "\"" + newID + "\": " + strSerializeJSON + "\r\n}\r\n";

            //string response = PostnetworkInfo(remoteLinkSet, Mes);
            //if (response.Length > 0 && !response.Contains("200 OK"))
            //    System.Diagnostics.Debug.Assert(false, "setLuYouBiao！");
        }


        public void setStatsFlowBiao(DataLinkInfo remoteLinkSet, string nodeID, int subOperationToDo, DataTable partOperDt)
        {

            // 将DataTable转换为类实例
            string newID = partOperDt.Rows[0][0].ToString();

            List<string> BianLiangToJson = new List<string> { "dpid", "idle_timeout", "cookie", "packet_count", "hard_timeout", "priority", "flags", "table_id", "match" };
            string strSerializeJSON = ToJson(partOperDt, BianLiangToJson);
            //List<partStatsFlow> userList = TableToEntity<partStatsFlow>(partOperDt);
            //string strSerializeJSON = JsonConvert.SerializeObject(userList[0], Formatting.Indented);


            string str;
            if (subOperationToDo == 0)
                str = "POST /stats/flowentry/add HTTP/1.1";
            else
                str = "POST /stats/flowentry/delete HTTP/1.1";

            str = postNetwork_StringSetting(remoteLinkSet, str);


            string Mes = str + strSerializeJSON + "\r\n\r\n";

            //string response = PostnetworkInfo(remoteLinkSet, Mes);
            //if (response.Length > 0 && !response.Contains("200 OK"))
            //    System.Diagnostics.Debug.Assert(false, "setStatsFlowBiao！");
        }


        public string PostnetworkInfo(DataLinkInfo remoteLinkSet, string sendMessage)
        {
            //string sendMessage = getNetwork_StringSetting(networkInfoType, remoteLinkSet, infoShortStr); // 获取要发送的字符串

            string receiveString = "";
            send_ReceiveInfo(remoteLinkSet, sendMessage, ref receiveString);

#if DEBUG
            if (!beSimulationFlag && beEnableRecoredOper)
            {
                string path = System.Environment.CurrentDirectory + "\\SendReceivedData.txt";//文件的路径，保证文件存在。
                FileStream fs = new FileStream(path, FileMode.Append);
                StreamWriter sw = new StreamWriter(fs);

                sw.WriteLine("\r\nZhangYanSend\r\n" + sendMessage + "\r\nZhangYanSend\r\n");
                sw.WriteLine("\r\nZhangYanReceive\r\n" + receiveString + "\r\nZhangYanReceive\r\n");

                sw.Close();
                fs.Close();
            }
#endif

            return receiveString;


            ////设定服务器IP地址  
            //IPAddress ip = IPAddress.Parse(remoteLinkSet.ServerName);
            //Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            //try
            //{
            //    clientSocket.Connect(new IPEndPoint(ip, int.Parse(remoteLinkSet.ServerPort))); //配置服务器IP与端口  
            //    //Console.WriteLine("连接服务器成功");
            //}
            //catch
            //{
            //    //Console.WriteLine("连接服务器失败，请按回车键退出！");
            //    return null;
            //}

            ////通过 clientSocket 发送数据  
            //try
            //{
            //    string sendMessage = Mes; // 获取要发送的字符串
            //    clientSocket.Send(Encoding.ASCII.GetBytes(sendMessage));
            //    //Console.WriteLine("向服务器发送消息：{0}" + sendMessage);
            //}
            //catch
            //{
            //    clientSocket.Shutdown(SocketShutdown.Both);
            //    clientSocket.Close();
            //    return null;
            //}

            ////通过clientSocket接收数据
            //byte[] result = new byte[10240 * 4];
            //int receiveLength = clientSocket.Receive(result);
            //string recStr = Encoding.ASCII.GetString(result, 0, receiveLength);

            //clientSocket.Shutdown(SocketShutdown.Both);
            //clientSocket.Close();

            //return recStr;



            //IPAddress localIP = IPAddress.Parse(remoteLinkSet.LocalName);// IPAddress.Parse("127.0.0.1");
            //int localPort = int.Parse(remoteLinkSet.LocalPort);//12000;
            //// 开始监听
            //getStruct getC = new getStruct();
            //getC.listener = new TcpListener(localIP, localPort);//用本地IP和端口实例化Listener
            //getC.listener.Start();//开始监听


            ////发送数据
            //postStruct postC = new postStruct();
            //postC.sendString = Mes; // 获取要发送的字符串
            //postC.sendData = Encoding.Default.GetBytes(postC.sendString);//获取要发送的字节数组
            //try
            //{
            //    postC.sendClient = new TcpClient();//实例化TcpClient
            //    postC.sendClient.Connect(remoteLinkSet.ServerName, int.Parse(remoteLinkSet.ServerPort));//连接远程主机

            //    postC.sendStream = postC.sendClient.GetStream();//获取网络流
            //    postC.sendStream.Write(postC.sendData, 0, postC.sendData.Length);//将数据写入网络流
            //    postC.sendStream.Flush();
            //}
            //catch (System.Exception ex)
            //{
            //    //Console.WriteLine("连接超时，服务器没有响应！");//连接失败
            //    System.Diagnostics.Debug.Assert(false, "连接超时，服务器没有响应！");
            //    //Console.ReadKey();
            //    postC.sendStream.Close();//关闭网络流
            //    postC.sendClient.Close();//关闭客户端
            //    return null;
            //}
            //finally
            //{
            //    postC.sendStream.Close();//关闭网络流
            //    postC.sendClient.Close();//关闭客户端
            //}

            //while (true)//死循环
            //{
            //    getC.Getclient = getC.listener.AcceptTcpClient();//接受一个Client
            //    getC.getBuffer = new byte[getC.Getclient.ReceiveBufferSize];
            //    getC.Getstream = getC.Getclient.GetStream();//获取网络流
            //    getC.Getstream.Read(getC.getBuffer, 0, getC.getBuffer.Length);//读取网络流中的数据
            //    getC.Getstream.Close();//关闭流
            //    getC.Getclient.Close();//关闭Client

            //    getC.getString = Encoding.Default.GetString(getC.getBuffer).Trim('\0');//转换成字符串
            //    break;
            //}

            //getC.listener.Stop();

            //return getC.getString;
        }


        public void setChaoZhenBiao(DataLinkInfo remoteLinkSet, string nodeID, DataTable partOperDt)
        {
            // 将DataTable转换为类实例
            string newID = partOperDt.Rows[0][0].ToString();

            List<partWIAPAChaoZhen> userList = TableToEntity<partWIAPAChaoZhen>(partOperDt);
            string strSerializeJSON = JsonConvert.SerializeObject(userList[0], Formatting.Indented);

            string[] sArray = nodeID.Split('_');
            string str = "POST /WIA-PA/superframe/" + sArray[0] + "/" + sArray[1] + " HTTP/1.1";
            str = postNetwork_StringSetting(remoteLinkSet, str);

            string Mes = str + "{\"num\": 1,\r\n" + "\"" + newID + "\": " + strSerializeJSON + "\r\n}\r\n";

            //string response = PostnetworkInfo(remoteLinkSet, Mes);
            //if (response.Length > 0 && !response.Contains("200 OK"))
            //    System.Diagnostics.Debug.Assert(false, "setChaoZhenBiao失败！");
        }

        public void setLianLuBiao(DataLinkInfo remoteLinkSet, string nodeID, DataTable partOperDt)
        {
            // 将DataTable转换为类实例
            string newID = partOperDt.Rows[0][0].ToString();

            List<partWIAPALianLu> userList = TableToEntity<partWIAPALianLu>(partOperDt);
            string strSerializeJSON = JsonConvert.SerializeObject(userList[0], Formatting.Indented);

            string[] sArray = nodeID.Split('_');
            string str = "POST /WIA-PA/linktable/" + sArray[0] + "/" + sArray[1] + " HTTP/1.1";
            str = postNetwork_StringSetting(remoteLinkSet, str);

            string Mes = str + "{\"num\": 1,\r\n" + "\"" + newID + "\": " + strSerializeJSON + "\r\n}\r\n\r\n";

            //string response = PostnetworkInfo(remoteLinkSet, Mes);
            //if (response.Length > 0 && !response.Contains("200 OK"))
            //    System.Diagnostics.Debug.Assert(false, "setLianLuBiao失败！");
        }



        public void GetObjLianLuBiao(int networkInfoType, DataLinkInfo remoteLinkSet, string nodeID, ref List<WIAPALianLu> mWIAPALianLu)
        {
            string[] sArray = nodeID.Split('_');
            string str = "GET /WIA-PA/linktable/" + sArray[0] + "/" + sArray[1] + " HTTP/1.1";

            string strJson = getnetworkInfo(networkInfoType, remoteLinkSet, str);
            bool effectiveJson = strJson.Contains("200 OK");

            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));

            int newAddedNo = 0;
            if (effectiveJson)
            {
                string selectedStr = "";
                int curIndex = GetStr(0, strJson, "{\"LinkType\"", "}", ref selectedStr);
                // 获取RoutedID
                string RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"LinkType\"", "\"[^\"]*\"");

                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //MessageBox.Show(selectedStr);
                    WIAPALianLu tempWIAPALianLu = new WIAPALianLu();
                    tempWIAPALianLu.LinkID = RoutedIDStr;
                    tempWIAPALianLu.partWIAPALianLu = JsonConvert.DeserializeObject<partWIAPALianLu>(selectedStr);

                    mWIAPALianLu.Add(tempWIAPALianLu);
                    newAddedNo++;

                    curIndex = GetStr(curIndex, strJson.Substring(curIndex), "{\"LinkType\"", "}", ref selectedStr);
                    RoutedIDStr = patternStr_Previoussubstr(strJson.Substring(0, curIndex), "{\"LinkType\"", "\"[^\"]*\"");
                }
            }

            // 判断实际获取，与报文中num值 是否一致
            if (!effectiveJson || int.Parse(patternStr_aftersubstr(strJson, "\"num\"", "\"[^\"]*\"")) != newAddedNo)
            {
                //System.Diagnostics.Debug.Assert(false, "GetObjLianLuBiao！");
                mWIAPALianLu.Clear();
            }
        }

        /// <summary>
        /// 获取传感网拓扑信息
        /// </summary>
        /// <param name="WIAPATopologyList"></param>
        public void getTopology_networksTopologyList_recvData(ref List<WIAPATopology2> WIAPATopologyList, string recvData)
        {
            //TranslateJsonMessage_WithoutSpace(ref recvData);
            recvData = recvData.Replace(" ", "");
            recvData = recvData.Trim();

            //记录已有节点数
            int PreTopologyListCount = WIAPATopologyList.Count;

            string tempStr;
            if (!string.IsNullOrEmpty(recvData))
            {
                
                int pos = 0,pos2=0;
                WIAPATopology2 tempWIAPAnode;
                do
                {
                    pos = pos2;

                    //Relationship address Number is:0x00Parent address is:0x0000Parent category is:0x0001Child address is:0x3525Child category is:0x0003Number of total address relationship is:0x01
                    tempWIAPAnode = new WIAPATopology2();
                    tempWIAPAnode.src = new src();
                    tempWIAPAnode.dst = new dst();

                    tempStr = "Parentaddressis:";
                    pos = recvData.IndexOf(tempStr,pos);
                    tempWIAPAnode.src.address = recvData.Substring(pos + tempStr.Length, 6);

                    tempStr = "Parentcategoryis:";
                    pos = recvData.IndexOf(tempStr,pos);
                    tempWIAPAnode.src.category = recvData.Substring(pos + tempStr.Length, 6);

                    tempStr = "Childaddressis:";
                    pos = recvData.IndexOf(tempStr, pos);
                    tempWIAPAnode.dst.address = recvData.Substring(pos + tempStr.Length, 6);

                    tempStr = "Childcategoryis:";
                    pos = recvData.IndexOf(tempStr, pos);
                    tempWIAPAnode.dst.category = recvData.Substring(pos + tempStr.Length, 6);

                    WIAPATopologyList.Add(tempWIAPAnode);


                    tempStr = "Parentaddressis:";
                    pos2 = recvData.IndexOf(tempStr, pos);

                } while (pos2 >0); //如果后续还有，需要进一步获取

                // 判断实际获取的src dst对，与报文中Number of total address relationship is:是否一致
                tempStr = "Numberoftotaladdressrelationshipis:0x";
                pos = recvData.LastIndexOf(tempStr);
                int numGot = int.Parse(recvData.Substring(pos + tempStr.Length, 2));
                if (numGot != WIAPATopologyList.Count - PreTopologyListCount)
                {
                    //表明解析数据出错
                    WIAPATopologyList.Clear();
                }
            }
        }


        /// <summary>
        /// 获取WIA-PA拓扑信息,获取回程网络拓扑信息
        /// </summary>
        /// <param name="remoteLinkSet"></param>
        /// <param name="WIAPATopologyList"></param>
        public void getWIAPATopology_networksTopologyList(int networkInfoType, DataLinkInfo remoteLinkSet, string panidIDStr, ref List<WIAPATopology2> WIAPATopologyList)
        {
            //IPAddress remoteIP = IPAddress.Parse("127.0.0.1");//远程主机IP
            //int remotePort = 11000;//远程主机端口

            //Regex regex = new Regex("\"[^\"]*\"");
            //MatchCollection results = regex.Matches(strtmp);
            //Replace("\"", "");

            string str = "";
            if (networkInfoType == 2)
                str = "GET /WIA-PA/topology/" + panidIDStr + " HTTP/1.1";
            else if (networkInfoType == 3)
                str = "GET /networks/topology HTTP/1.1";

            string strJson = getnetworkInfo(networkInfoType, remoteLinkSet, str);
            bool effectiveJson = strJson.Contains("200 OK");

            TranslateJsonMessage_WithoutSpace(ref strJson);
            effectiveJson = effectiveJson && (!string.IsNullOrEmpty(strJson));

            int newAddedNo = 0;
            if (effectiveJson)
            {
                // 将dpid换成address
                if (networkInfoType == 3)
                    strJson = strJson.Replace("dpid", "address");

                string selectedStr = "";
                int curIndex = GetStr(0, strJson, "{\"src\"", "}}", ref selectedStr);
                while (!string.IsNullOrEmpty(selectedStr))
                {
                    //MessageBox.Show(selectedStr);
                    WIAPATopologyList.Add(JsonConvert.DeserializeObject<WIAPATopology2>(selectedStr));
                    newAddedNo++;
                    curIndex = GetStr(curIndex, strJson.Substring(curIndex), "{\"src\"", "}}", ref selectedStr);
                }
            }


            // 判断实际获取的src dst对，与报文中num值 是否一致
            if (!effectiveJson || int.Parse(patternStr_aftersubstr(strJson, "\"num\"", "\"[^\"]*\"")) != newAddedNo)
            {
                //System.Diagnostics.Debug.Assert(false, "getWIAPATopologyList！");
                WIAPATopologyList.Clear();
            }
        }

        public void TranslateJsonMessage_WithoutSpace(ref string strJson)
        {
            int index = strJson.IndexOf('{');
            if (index >= 0)
            {
                strJson = strJson.Substring(index, strJson.Length - index);
                strJson = strJson.Replace("\n", "");
                strJson = strJson.Replace("\r", "");
                strJson = strJson.Replace(" ", "");
            }
            else
            {
                strJson = "";
            }
        }

        public void TranslateJsonMessage_WithoutSpace_ExceptN(ref string strJson)
        {
            int index = strJson.IndexOf('{');
            strJson = strJson.Substring(index, strJson.Length - index);
            //strJson = strJson.Replace("\n", "");
            strJson = strJson.Replace("\r", "");
            strJson = strJson.Replace(" ", "");
        }

        public void send_ReceiveInfo(DataLinkInfo remoteLinkSet, string sendMessage, ref string receiveString)
        {

            //设定服务器IP地址
            IPAddress ip = null;
            //Socket clientSocket = null;
            TcpClient NetworkClient = null;

            try
            {
                //string sendMessage = textBox_Send.Text; // 获取要发送的字符串
                TCPOper oper = new TCPOper();

                string stttr;
                if (sendMessage.Contains("GET"))
                    stttr = sendMessage + "\r\n\r\n";

                else if (sendMessage.Contains("POST"))
                {
                    string subStr = sendMessage.Substring(sendMessage.IndexOf("{"));
                    oper.TranslateJsonMessage_WithoutSpace_ExceptN(ref subStr);
                    int len = subStr.Length;

                    string checkStr = "Content-Length:";
                    int index = 0;
                    if (sendMessage.Contains(checkStr))
                        index = sendMessage.IndexOf(checkStr);
                    else
                    {
                        index = sendMessage.IndexOf("Content-Type");
                        index = index + sendMessage.Substring(index).IndexOf("\r\n") + 2;
                        sendMessage = sendMessage.Insert(index, checkStr);
                    }

                    stttr = sendMessage.Substring(0, index + checkStr.Length) + " " + len.ToString() + "\r\n\r\n" + subStr;

                }
                else
                {
                    //System.Diagnostics.Debug.Assert(false, "无效的输入指令！");
                    receiveString = "";
                    return;
                }

                if (this.beSimulationFlag)
                {
                    string path = System.Environment.CurrentDirectory + "\\SendReceivedData.txt";//文件的路径，保证文件存在。
                    StreamReader sr = new StreamReader(path);

                    String str_read = sr.ReadToEnd();
                    sr.Close();


                    int sendMesIndex = str_read.IndexOf(sendMessage);
                    if (sendMesIndex > 0)
                    {
                        String subStr_read = str_read.Substring(sendMesIndex);

                        String flagStr = "ZhangYanReceive1\r\n";
                        int index1 = subStr_read.IndexOf(flagStr) + flagStr.Length;
                        int index2 = subStr_read.IndexOf("ZhangYanReceive2");

                        receiveString = subStr_read.Substring(index1, index2 - index1);
                        receiveString.Trim();
                    }
                    else
                    {
                        receiveString = "";
                    }

                    //path是要读取的文件的完整路径
                    //从开始到末尾读取文件的所有内容，str_read 存放的就是读取到的文本
                }
                else
                {
                    ip = IPAddress.Parse(remoteLinkSet.ServerName);
                    NetworkClient = TimeOutSocket.Connect(new IPEndPoint(ip, int.Parse(remoteLinkSet.ServerPort)), TimeOutSocket.TcpClientConnectTimeout); // 连接服务器
                    NetworkClient.ReceiveTimeout = TimeOutSocket.TcpClientReceiveTimeout;
                    NetworkClient.SendTimeout = TimeOutSocket.TcpClientSendTimeout;

                    if (NetworkClient != null && NetworkClient.Connected)
                    {
                        NetworkStream ns = NetworkClient.GetStream();
                        if (ns.CanRead && ns.CanWrite)
                        {
                            Byte[] sendBytes = Encoding.ASCII.GetBytes(stttr + "\r\n");
                            ns.Write(sendBytes, 0, sendBytes.Length);

                            byte[] result = new byte[10240 * 4];
                            int receiveLength = ns.Read(result, 0, 10240 * 4);
                            receiveString = Encoding.ASCII.GetString(result, 0, receiveLength);
                        }
                        else
                            receiveString = "";

                        ns.Close();
                    }

                    //ip = IPAddress.Parse(remoteLinkSet.ServerName);
                    //clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    //clientSocket.Connect(new IPEndPoint(ip, int.Parse(remoteLinkSet.ServerPort))); //配置服务器IP与端口

                    //if (clientSocket != null && clientSocket.Connected)
                    //{
                    //    clientSocket.Send(Encoding.ASCII.GetBytes(stttr + "\r\n"));

                    //    //通过clientSocket接收数据
                    //    byte[] result = new byte[10240 * 4];
                    //    int receiveLength = clientSocket.Receive(result);
                    //    receiveString = Encoding.ASCII.GetString(result, 0, receiveLength);
                    //}
                    //else
                    //    receiveString = "";
                }

            }
            catch
            {
                receiveString = "";
                //System.Diagnostics.Debug.Assert(false, "控制指令操作失败！");
            }
            finally
            {
                if (NetworkClient != null)
                {
                    NetworkClient.Close();
                }
                //if (clientSocket != null && clientSocket.Connected)
                //{
                //    clientSocket.Shutdown(SocketShutdown.Both);
                //    clientSocket.Close();
                //}
            }
        }

        /// <summary>
        /// 获取网络信息
        /// </summary>
        /// <param name="networkInfoType"></param>
        /// <param name="remoteLinkSet"></param>
        /// <param name="infoShortStr"></param>
        /// <returns></returns>
        public string getnetworkInfo(int networkInfoType, DataLinkInfo remoteLinkSet, string infoShortStr)
        {
            string sendMessage = getNetwork_StringSetting(networkInfoType, remoteLinkSet, infoShortStr); // 获取要发送的字符串


            string receiveString = "";
            send_ReceiveInfo(remoteLinkSet, sendMessage, ref receiveString);

            if (!beSimulationFlag && beEnableRecoredOper)
            {
                //#if DEBUG
                string path = System.Environment.CurrentDirectory + "\\SendReceivedData.txt";//文件的路径，保证文件存在。
                FileStream fs = new FileStream(path, FileMode.Append);
                StreamWriter sw = new StreamWriter(fs);

                sw.WriteLine("\r\nZhangYanSend1\r\n" + sendMessage + "\r\nZhangYanSend2\r\n");
                sw.WriteLine("\r\nZhangYanReceive1\r\n" + receiveString + "\r\nZhangYanReceive2\r\n");

                //sw.WriteLine("\r\n\r\n\r\n");

                sw.Close();
                fs.Close();
                //#endif
            }

            return receiveString;

            ////设定服务器IP地址
            //IPAddress ip = IPAddress.Parse(remoteLinkSet.ServerName);
            //Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            //try
            //{
            //    clientSocket.Connect(new IPEndPoint(ip, int.Parse(remoteLinkSet.ServerPort))); //配置服务器IP与端口  
            //    //Console.WriteLine("连接服务器成功");
            //}
            //catch
            //{
            //    //Console.WriteLine("连接服务器失败，请按回车键退出！");
            //    return null;
            //}

            ////通过 clientSocket 发送数据  
            //try
            //{

            //    clientSocket.Send(Encoding.ASCII.GetBytes(sendMessage));
            //    //Console.WriteLine("向服务器发送消息：{0}" + sendMessage);
            //}
            //catch
            //{
            //    clientSocket.Shutdown(SocketShutdown.Both);
            //    clientSocket.Close();
            //    return null;
            //}

            ////通过clientSocket接收数据
            //byte[] result = new byte[10240*4]; 
            //int receiveLength = clientSocket.Receive(result);
            //string recStr = Encoding.ASCII.GetString(result, 0, receiveLength);

            //clientSocket.Shutdown(SocketShutdown.Both);
            //clientSocket.Close();

            //return recStr;



            //Console.WriteLine("接收服务器消息：{0}", Encoding.ASCII.GetString(result, 0, receiveLength)); 


            //IPAddress localIP = IPAddress.Parse(remoteLinkSet.LocalName);// IPAddress.Parse("127.0.0.1");
            //int localPort = int.Parse(remoteLinkSet.LocalPort);//12000;

            //// 开始监听
            //getStruct getC = new getStruct();
            //getC.listener = new TcpListener(localIP, localPort);//用本地IP和端口实例化Listener
            //getC.listener.Start();//开始监听



            ////发送数据
            //postStruct postC = new postStruct();
            //postC.sendString = getNetwork_StringSetting(networkInfoType, remoteLinkSet, infoShortStr); // 获取要发送的字符串
            //postC.sendData = Encoding.Default.GetBytes(postC.sendString);//获取要发送的字节数组
            //try
            //{
            //    postC.sendClient = new TcpClient();//实例化TcpClient
            //    postC.sendClient.Connect(remoteLinkSet.ServerName, int.Parse(remoteLinkSet.ServerPort));//连接远程主机

            //    postC.sendStream = postC.sendClient.GetStream();//获取网络流
            //    postC.sendStream.Write(postC.sendData, 0, postC.sendData.Length);//将数据写入网络流
            //    postC.sendStream.Flush();
            //}
            //catch (System.Exception ex)
            //{
            //    //Console.WriteLine("连接超时，服务器没有响应！");//连接失败
            //    System.Diagnostics.Debug.Assert(false, "连接超时，服务器没有响应！");
            //    //Console.ReadKey();
            //    postC.sendStream.Close();//关闭网络流
            //    postC.sendClient.Close();//关闭客户端
            //    return null;
            //}
            //finally
            //{
            //    postC.sendStream.Close();//关闭网络流
            //    postC.sendClient.Close();//关闭客户端
            //}

            //while (true)//死循环
            //{
            //    getC.Getclient = getC.listener.AcceptTcpClient();//接受一个Client
            //    getC.getBuffer = new byte[getC.Getclient.ReceiveBufferSize];
            //    getC.Getstream = getC.Getclient.GetStream();//获取网络流
            //    getC.Getstream.Read(getC.getBuffer, 0, getC.getBuffer.Length);//读取网络流中的数据
            //    getC.Getstream.Close();//关闭流
            //    getC.Getclient.Close();//关闭Client

            //    getC.getString = Encoding.Default.GetString(getC.getBuffer).Trim('\0');//转换成字符串
            //    break;
            //}

            //getC.listener.Stop();

            //return getC.getString;
        }



        public string postNetwork_StringSetting(DataLinkInfo remoteLinkSet, string infoShortStr)
        {
            string temp3 = "Content-Type: application/json\r\nContent-Length:\r\n\r\n";
            return infoShortStr + "\r\n" + temp3;

            //            string temp2 = "Host: " +  remoteLinkSet.SDNIPName + ":" + remoteLinkSet.SDNPort;
            //            string temp3 = "";
            //            if (infoShortStr.Contains("WIA-PA/routetable"))
            //                temp3 = @"Content-Type: application/json
            //                        Cache-Control: no-cache
            //                        Postman-Token: eccbde4f-a965-069a-389c-a52f45e4e024
            //
            //                        ";

            //            else if (infoShortStr.Contains("WIA-PA/superframe"))
            //                temp3 = @"Content-Type: application/json
            //                            Cache-Control: no-cache
            //                            Postman-Token: 4479eb94-0a0e-4144-7374-10482fb32ac8
            //
            //                            ";

            //            else if (infoShortStr.Contains("WIA-PA/linktable"))
            //                temp3 = @"Content-Type: application/json
            //                            Cache-Control: no-cache
            //                            Postman-Token: 4e073ad0-7d8a-3d9a-f2db-8821ed8bee92
            //
            //                            ";


            //            return infoShortStr + "\r\n" + temp2 + "\r\n" + temp3;
        }

        /// <summary>
        /// 获取数据时，需要发送的字符串信息
        /// </summary>
        /// <param name="networkInfoType"></param>
        /// <param name="remoteLinkSet"></param>
        /// <param name="infoShortStr"></param>
        /// <returns></returns>
        public string getNetwork_StringSetting(int networkInfoType, DataLinkInfo remoteLinkSet, string infoShortStr)
        {
            return infoShortStr;
            //            string temp2 = "Host: " + remoteLinkSet.SDNIPName + ":" + remoteLinkSet.SDNPort;
            //            string temp3 = "";
            //            if (infoShortStr.Contains("WIA-PA/panid"))
            //                temp3 = @"Content-Type: application/json
            //                        Cache-Control: no-cache
            //                        Postman-Token: 50117443-f9fe-502c-767c-b56a204efdab";

            //            else if (infoShortStr.Contains("WIA-PA/topology"))
            //                temp3 = @"Content-Type: application/json
            //                        Cache-Control: no-cache
            //                        Postman-Token: f1646a86-d679-6063-0280-44eb54002f09";

            //            else if (infoShortStr.Contains("networks/topology"))
            //                temp3 = @"Content-Type: application/json
            //                        Cache-Control: no-cache
            //                        Postman-Token: 88ef8f65-f31d-9904-584f-6aa7d731177a";

            //            else if (infoShortStr.Contains("WIA-PA/routetable"))
            //                temp3 = @"Cache-Control: no-cache
            //                        Postman-Token: 0fb7ca58-a81a-12ec-98e8-1f65239336f4";

            //            else if (infoShortStr.Contains("WIA-PA/superframe"))
            //                temp3 = @"Cache-Control: no-cache
            //                        Postman-Token: d2d5e7e0-c2f2-916f-36ac-4cc4d7b32a17";

            //            else if (infoShortStr.Contains("WIA-PA/linktable"))
            //                temp3 = @"Content-Type: application/json
            //                        Cache-Control: no-cache
            //                        Postman-Token: 9133ccac-d09d-7606-a543-d64aa7682b14";

            //            else if (infoShortStr.Contains("stats/flow"))
            //                temp3 = @"Cache-Control: no-cache
            //                Postman-Token: d73656fe-8f36-fd28-5c7f-887f5fdb0f91";


            //            return infoShortStr + "\r\n" + temp2 + "\r\n" + temp3;
        }

    }
}
