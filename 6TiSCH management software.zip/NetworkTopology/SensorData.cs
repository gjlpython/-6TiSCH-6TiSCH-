﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using NetworkRealTime;
using System.Windows.Forms.DataVisualization.Charting;

namespace NetworkTopology
{
    public partial class SensorData : Form
    {
        int SensorNodeNum; //传感器编号
        DateTime dt2_begin;
        DateTime dt2_now;

        struct dataInfo
        {
            public int NodeNum;
            public decimal Q_wendu, Q_shidu;
            public DateTime dt;
        }

        Queue<dataInfo> SensorDataQuene = new Queue<dataInfo>();
        dataInfo tempDataInfo = new dataInfo();

        //Queue<decimal> Q21 = new Queue<decimal>();
        //Queue<decimal> Q22 = new Queue<decimal>();

        //Queue<decimal> Q41 = new Queue<decimal>();
        //Queue<decimal> Q42 = new Queue<decimal>();


        //Queue<decimal> Q81 = new Queue<decimal>();
        //Queue<decimal> Q82 = new Queue<decimal>();

        //Queue<decimal> Q51 = new Queue<decimal>();
        //Queue<decimal> Q52 = new Queue<decimal>();

        public SensorData(int NodeID)
        {
            InitializeComponent();
            SensorNodeNum = NodeID;
        }

        private void SensorData_Load(object sender, EventArgs e)
        {
            string s = "";
            //HomePage CNewFile = new HomePage();
            //CNewFile.CreateNewFile_c();

            //string fileDir = "D:\\";
            ////string fileName = fileDir + DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString().Replace(":", "-") + "数据输出" + ".txt";//xls xlsx txt
            //string fileName = fileDir + "6TiSCH_DataOutput" + ".txt";//xls xlsx txt
            //FileStream dataFile = new FileStream(fileName, FileMode.Append, FileAccess.Write,FileShare.ReadWrite);
            ////string data = "Machine Code\tHumidity\tTemperature\tTime\n";
            ////StreamWriter writer = new StreamWriter(dataFile);
            ////writer.Write(data);
            ////writer.Flush();
            ////writer.Close();
            //dataFile.Close();

            try
            {
                StreamReader sr = new StreamReader(Common.SensorDataFilePath);
                s = sr.ReadToEnd();
                sr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("----------------------内层catch" + ex.Message + "------------------------------");
            }

            //string[] sentence = s.Split('\n');
            int xsjs = 0;  //项数计数
            //int gsjs2 = 0;//个数计数
            //int gsjs4 = 0;//个数计数
            //int gsjs8 = 0;//个数计数
            //int gsjs5 = 0;//个数计数
            string[] another = s.Split(new char[2] { '\t', '\n' });
            string[] jlsz = new string[] { " ", " ", " ", " " };//记录数字
            
            foreach (string ss in another)
            {
                string[] words = ss.Split(' ');
                jlsz[xsjs] = words[0];
                xsjs++;

                if (xsjs == 4)
                {
                    xsjs = 0;
                    tempDataInfo.NodeNum = Convert.ToInt32(jlsz[0].Substring(0, 1));
                    if (SensorNodeNum == tempDataInfo.NodeNum)
                    {
                        tempDataInfo.Q_shidu = Convert.ToDecimal(jlsz[1]);
                        tempDataInfo.Q_wendu = Convert.ToDecimal(jlsz[2]);
                        tempDataInfo.dt = Convert.ToDateTime(jlsz[3]);
                        SensorDataQuene.Enqueue(tempDataInfo);//将数据加入队列
                    }
                    

                    //if (jlsz[0] == "2#")
                    //{
                    //    Common.湿度2 = Convert.ToDecimal(jlsz[1]);
                    //    Common.温度2 = Convert.ToDecimal(jlsz[2]);
                    //    Q21.Enqueue(Common.温度2);//将数据加入队列
                    //    Q22.Enqueue(Common.湿度2);
                    //    gsjs2++;
                    //}

                    //if (jlsz[0] == "4#")
                    //{
                    //    Common.湿度2 = Convert.ToDecimal(jlsz[1]);
                    //    Common.温度2 = Convert.ToDecimal(jlsz[2]);
                    //    Q41.Enqueue(Common.温度2);//将数据加入队列
                    //    Q42.Enqueue(Common.湿度2);
                    //    gsjs4++;
                    //}

                    //if (jlsz[0] == "8#")
                    //{
                    //    Common.湿度2 = Convert.ToDecimal(jlsz[1]);
                    //    Common.温度2 = Convert.ToDecimal(jlsz[2]);
                    //    Q81.Enqueue(Common.温度2);//将数据加入队列
                    //    Q82.Enqueue(Common.湿度2);
                    //    gsjs8++;
                    //}

                    //if (jlsz[0] == "5#")
                    //{
                    //    Common.湿度2 = Convert.ToDecimal(jlsz[1]);
                    //    Common.温度2 = Convert.ToDecimal(jlsz[2]);
                    //    Q81.Enqueue(Common.温度2);//将数据加入队列
                    //    Q82.Enqueue(Common.湿度2);
                    //    gsjs8++;
                    //}
                }
            }

            时钟.Enabled = true;
            InitChart2();
            InitChart3();

            chart波形2.MouseClick += new MouseEventHandler(chart波形2_MouseClick);
            chart波形3.MouseClick += new MouseEventHandler(chart波形3_MouseClick);
            dt2_begin = System.DateTime.Now;
        }

        public void InitChart2()
        {

            Series series = chart波形2.Series[0];
            // 画样条曲线（Spline）
            series.ChartType = SeriesChartType.Spline;
            // 线宽2个像素
            series.BorderWidth = 1;
            // 线的颜色：红色
            series.Color = System.Drawing.Color.Red;
            // 图示上的文字            
            series.IsVisibleInLegend = false;   //隐藏图示上的文字    



            // 设置显示范围
            ChartArea chartArea = chart波形2.ChartAreas[0];

            chartArea.AxisX.Minimum = 0;

            chartArea.AxisY.Minimum = 0d;

            chartArea.AxisX.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea.AxisY.MajorGrid.LineColor = System.Drawing.Color.Transparent;



            chart波形2.ChartAreas[0].CursorX.IsUserEnabled = true;//true
            chart波形2.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart波形2.ChartAreas[0].AxisX.ScaleView.Zoomable = true;

            //将滚动内嵌到坐标轴中
            chart波形2.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = false;

            // 设置滚动条的大小
            chart波形2.ChartAreas[0].AxisX.ScrollBar.Size = 10;


            // 设置自动放大与缩小的最小量
            chart波形2.ChartAreas[0].AxisX.ScaleView.SmallScrollSize = double.NaN;
            chart波形2.ChartAreas[0].AxisX.ScaleView.SmallScrollMinSize = 1;


            //Curve frm = new Curve();//温度

        }


        public void InitChart3()
        {

            Series series = chart波形3.Series[0];
            // 画样条曲线（Spline）
            series.ChartType = SeriesChartType.Spline;
            // 线宽2个像素
            series.BorderWidth = 1;
            // 线的颜色：蓝色
            series.Color = System.Drawing.Color.Blue;
            // 图示上的文字            
            series.IsVisibleInLegend = false;   //隐藏图示上的文字    

            ChartArea chartArea = chart波形3.ChartAreas[0];// 设置显示范围

            chartArea.AxisX.Minimum = 0;

            chartArea.AxisY.Minimum = 0d;

            chartArea.AxisX.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea.AxisY.MajorGrid.LineColor = System.Drawing.Color.Transparent;




            chart波形3.ChartAreas[0].CursorX.IsUserEnabled = true;
            chart波形3.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart波形3.ChartAreas[0].AxisX.ScaleView.Zoomable = true;

            //将滚动内嵌到坐标轴中
            chart波形3.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = false;

            // 设置滚动条的大小
            chart波形3.ChartAreas[0].AxisX.ScrollBar.Size = 10;


            // 设置自动放大与缩小的最小量
            chart波形3.ChartAreas[0].AxisX.ScaleView.SmallScrollSize = double.NaN;
            chart波形3.ChartAreas[0].AxisX.ScaleView.SmallScrollMinSize = 1;
        }

        private void chart波形2_MouseClick(object sender, MouseEventArgs e)  //chart1是你建的chart控件，实际名字根据你自己代码里的命名
        {
            HitTestResult hit = chart波形2.HitTest(e.X, e.Y);
            if (hit.Series != null)
            {
                var xValue = hit.Series.Points[hit.PointIndex].XValue;
                //var xValue = hit.XValue;
                var yValue = hit.Series.Points[hit.PointIndex].YValues.First();
                横坐标1.Text = string.Format("{0:F0}", "此处温度为：\r\n" + yValue + " ℃ ");//textbox1也是自己建的一个专门用来显示的内容框，也可以用messagebox直接弹出内容
            }
            else
            {
                横坐标1.Text = "未点击温度曲线";
            }
        }
        private void chart波形3_MouseClick(object sender, MouseEventArgs e)  //chart1是你建的chart控件，实际名字根据你自己代码里的命名
        {
            HitTestResult hit = chart波形3.HitTest(e.X, e.Y);
            if (hit.Series != null)
            {
                var xValue = hit.Series.Points[hit.PointIndex].XValue;
                //var xValue = hit.XValue;
                var yValue = hit.Series.Points[hit.PointIndex].YValues.First();
                横坐标2.Text = string.Format("{0:F0}", "此处湿度为：\r\n" + "% " + yValue);//textbox1也是自己建的一个专门用来显示的内容框，也可以用messagebox直接弹出内容
            }
            else
            {
                横坐标2.Text = "未点击湿度曲线";
            }
        }

        //decimal temp;//温度
        //decimal humidity;//湿度

        public void Draw2()
        {

            for (int i = 0; i < SensorDataQuene.Count; i++)
            {
                chart波形2.Series[0].Points.AddXY(i, SensorDataQuene.ElementAt(i).Q_wendu);
                chart波形3.Series[0].Points.AddXY(i, SensorDataQuene.ElementAt(i).Q_shidu);
            }

            //if (Common.init_flag2 == false)
            //{
            //    for (int i = 0; i < Q21.Count; i++)
            //    {
            //        chart波形2.Series[0].Points.AddXY(i, Q21.ElementAt(i));
            //    }
            //    for (int i = 0; i < Q22.Count; i++)
            //    {
            //        chart波形3.Series[0].Points.AddXY(i, Q22.ElementAt(i));
            //    }
            //    Common.init_flag2 = true;

            //}

            //if (Common.init_flag4 == false)
            //{
            //    for (int i = 0; i < Q41.Count; i++)
            //    {
            //        chart波形2.Series[0].Points.AddXY(i, Q41.ElementAt(i));
            //    }
            //    for (int i = 0; i < Q42.Count; i++)
            //    {
            //        chart波形3.Series[0].Points.AddXY(i, Q42.ElementAt(i));
            //    }
            //    Common.init_flag4 = true;

            //}

            //if (Common.init_flag8 == false)
            //{
            //    for (int i = 0; i < Q81.Count; i++)
            //    {
            //        chart波形2.Series[0].Points.AddXY(i, Q81.ElementAt(i));
            //    }
            //    for (int i = 0; i < Q82.Count; i++)
            //    {
            //        chart波形3.Series[0].Points.AddXY(i, Q82.ElementAt(i));
            //    }
            //    Common.init_flag8 = true;

            //}



            this.chart波形2.Series[0].Points.Clear();
            this.chart波形3.Series[0].Points.Clear();

            tempDataInfo.NodeNum = SensorNodeNum;
            tempDataInfo.Q_wendu = (decimal)Common.温度[SensorNodeNum];
            tempDataInfo.Q_shidu = (decimal)Common.湿度[SensorNodeNum];
            tempDataInfo.dt = DateTime.Now;


            机器号.Text = "Sensor机器号-" + SensorNodeNum.ToString();
            显示数值.Text = "当前温度" + tempDataInfo.Q_wendu.ToString() + "  当前湿度" + tempDataInfo.Q_shidu.ToString();
            Sensor类型.Text = "温度Sensor";

            //if (Common.Sensor机器号8 == true && Common.点击的Sensor == 1)
            //{
            //    temp = (decimal)Common.温度[8];
            //    humidity = (decimal)Common.湿度[8];

            //    机器号.Text = "Sensor机器号-08";
            //    显示数值.Text = "当前温度" + temp.ToString() + "  当前湿度" + humidity.ToString();
            //    Sensor类型.Text = "温度Sensor";
            //}

            //else if (Common.Sensor机器号2 == true && Common.点击的Sensor == 2)
            //{
            //    temp = (decimal)Common.温度[2];
            //    humidity = (decimal)Common.湿度[2];

            //    机器号.Text = "Sensor机器号-02";
            //    显示数值.Text = "当前温度" + temp.ToString() + "  当前湿度" + humidity.ToString(); ;
            //    Sensor类型.Text = "温度Sensor";
            //}

            //if (Common.Sensor机器号4 == true && Common.点击的Sensor == 3)
            //{
            //    temp = (decimal)Common.温度[4];
            //    humidity = (decimal)Common.湿度[4];

            //    机器号.Text = "Sensor机器号-04";
            //    显示数值.Text = "当前温度" + temp.ToString() + "  当前湿度" + humidity.ToString();
            //    Sensor类型.Text = "温度Sensor";
            //}


            SensorDataQuene.Enqueue(tempDataInfo);
            for (int i = 0; i < SensorDataQuene.Count; i++)
            {
                chart波形2.Series[0].Points.AddY(SensorDataQuene.ElementAt(i).Q_wendu);
                chart波形3.Series[0].Points.AddY(SensorDataQuene.ElementAt(i).Q_shidu);
            }

            //if (Common.点击的Sensor == 1)//机器号8
            //{
            //    Q81.Enqueue(temp);
            //    Q82.Enqueue(humidity);
            //    for (int i = 0; i < Q81.Count; i++)
            //    {
            //        chart波形2.Series[0].Points.AddY(Q81.ElementAt(i));
            //    }
            //    for (int i = 0; i < Q82.Count; i++)
            //    {
            //        chart波形3.Series[0].Points.AddY(Q82.ElementAt(i));
            //    }
            //}

            //if (Common.点击的Sensor == 2)//机器号2
            //{
            //    Q21.Enqueue(temp);
            //    Q22.Enqueue(humidity);
            //    for (int i = 0; i < Q21.Count; i++)
            //    {
            //        chart波形2.Series[0].Points.AddY(Q21.ElementAt(i));
            //    }
            //    for (int i = 0; i < Q22.Count; i++)
            //    {
            //        chart波形3.Series[0].Points.AddY(Q22.ElementAt(i));
            //    }
            //}


            //if (Common.点击的Sensor == 3)//机器号4
            //{
            //    Q41.Enqueue(temp);
            //    Q42.Enqueue(humidity);
            //    for (int i = 0; i < Q41.Count; i++)
            //    {
            //        chart波形2.Series[0].Points.AddY(Q41.ElementAt(i));
            //    }
            //    for (int i = 0; i < Q42.Count; i++)
            //    {
            //        chart波形3.Series[0].Points.AddY(Q42.ElementAt(i));
            //    }
            //}

        }

        TimeSpan ts;
        private void 时钟_Tick(object sender, EventArgs e)
        {
            Draw2();
            dt2_now = System.DateTime.Now;
            ts = (dt2_now - dt2_begin);

            //当前时间1.Text = "系统运行时长：" + ts.Days + " 天 " +
            //    ts.Hours + " 小时 " + ts.Minutes + " 分钟 " + ts.Seconds + " 秒";
            当前时间1.Text = dt2_now.ToString();
        }
        private void 时钟2_Tick(object sender, EventArgs e)
        {
            if (Common.时钟启停信号 == false) 
                this.时钟.Enabled = false;//同步关闭时钟
            if (Common.时钟启停信号 == true) 
                this.时钟.Enabled = true;//同步开启时钟
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
            //Common.关闭标志位 = true;
            //this.Close();
        //}

        private void chart波形2_Click(object sender, EventArgs e)
        {

            if (Common.时钟同步信号 == false)
                Common.时钟同步信号 = true;

        }

    }
}
