﻿namespace ForceDirected
{
    partial class FrmScreenProp
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmScreenProp));
            this.groupBoxRange = new System.Windows.Forms.GroupBox();
            this.chkRangeAll = new System.Windows.Forms.CheckBox();
            this.txtYDown = new System.Windows.Forms.TextBox();
            this.txtXRightShow = new System.Windows.Forms.TextBox();
            this.txtXRightFull = new System.Windows.Forms.TextBox();
            this.txtYUp = new System.Windows.Forms.TextBox();
            this.txtXLeftShow = new System.Windows.Forms.TextBox();
            this.txtXLeftFull = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chkRemainAll = new System.Windows.Forms.CheckBox();
            this.txtDowntReamin = new System.Windows.Forms.TextBox();
            this.txtRightReamin = new System.Windows.Forms.TextBox();
            this.txtUpReamin = new System.Windows.Forms.TextBox();
            this.txtLeftRemain = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.picClrCursor = new System.Windows.Forms.PictureBox();
            this.picClrBckgrd = new System.Windows.Forms.PictureBox();
            this.picClrSlcArea = new System.Windows.Forms.PictureBox();
            this.picClrInfo = new System.Windows.Forms.PictureBox();
            this.picClrShape = new System.Windows.Forms.PictureBox();
            this.picClrGrid = new System.Windows.Forms.PictureBox();
            this.picClrRect = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtWidthCursor = new System.Windows.Forms.TextBox();
            this.txtWidthShape = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtWidthGrid = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtWidthRect = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkLogAll = new System.Windows.Forms.CheckBox();
            this.chkYLog = new System.Windows.Forms.CheckBox();
            this.chkXLog = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioBtMulti = new System.Windows.Forms.RadioButton();
            this.radioBtSingle = new System.Windows.Forms.RadioButton();
            this.btOk = new System.Windows.Forms.Button();
            this.btCancle = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtMinHeight = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtMinWidth = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtYMinPix = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtXMinPix = new System.Windows.Forms.TextBox();
            this.cmbLineStyle = new System.Windows.Forms.ComboBox();
            this.groupBoxRange.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClrCursor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrBckgrd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrSlcArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrShape)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrRect)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxRange
            // 
            this.groupBoxRange.Controls.Add(this.chkRangeAll);
            this.groupBoxRange.Controls.Add(this.txtYDown);
            this.groupBoxRange.Controls.Add(this.txtXRightShow);
            this.groupBoxRange.Controls.Add(this.txtXRightFull);
            this.groupBoxRange.Controls.Add(this.txtYUp);
            this.groupBoxRange.Controls.Add(this.txtXLeftShow);
            this.groupBoxRange.Controls.Add(this.txtXLeftFull);
            this.groupBoxRange.Controls.Add(this.label8);
            this.groupBoxRange.Controls.Add(this.label7);
            this.groupBoxRange.Controls.Add(this.label6);
            this.groupBoxRange.Controls.Add(this.label3);
            this.groupBoxRange.Controls.Add(this.label5);
            this.groupBoxRange.Controls.Add(this.label1);
            this.groupBoxRange.Location = new System.Drawing.Point(375, 17);
            this.groupBoxRange.Name = "groupBoxRange";
            this.groupBoxRange.Size = new System.Drawing.Size(252, 143);
            this.groupBoxRange.TabIndex = 0;
            this.groupBoxRange.TabStop = false;
            this.groupBoxRange.Text = "坐标范围";
            // 
            // chkRangeAll
            // 
            this.chkRangeAll.AutoSize = true;
            this.chkRangeAll.Location = new System.Drawing.Point(13, 121);
            this.chkRangeAll.Name = "chkRangeAll";
            this.chkRangeAll.Size = new System.Drawing.Size(96, 16);
            this.chkRangeAll.TabIndex = 2;
            this.chkRangeAll.Text = "应用至所有块";
            this.chkRangeAll.UseVisualStyleBackColor = true;
            // 
            // txtYDown
            // 
            this.txtYDown.Location = new System.Drawing.Point(181, 87);
            this.txtYDown.Name = "txtYDown";
            this.txtYDown.Size = new System.Drawing.Size(55, 21);
            this.txtYDown.TabIndex = 1;
            // 
            // txtXRightShow
            // 
            this.txtXRightShow.Location = new System.Drawing.Point(181, 56);
            this.txtXRightShow.Name = "txtXRightShow";
            this.txtXRightShow.Size = new System.Drawing.Size(55, 21);
            this.txtXRightShow.TabIndex = 1;
            // 
            // txtXRightFull
            // 
            this.txtXRightFull.Location = new System.Drawing.Point(181, 25);
            this.txtXRightFull.Name = "txtXRightFull";
            this.txtXRightFull.Size = new System.Drawing.Size(55, 21);
            this.txtXRightFull.TabIndex = 1;
            // 
            // txtYUp
            // 
            this.txtYUp.Location = new System.Drawing.Point(76, 86);
            this.txtYUp.Name = "txtYUp";
            this.txtYUp.Size = new System.Drawing.Size(57, 21);
            this.txtYUp.TabIndex = 1;
            // 
            // txtXLeftShow
            // 
            this.txtXLeftShow.Location = new System.Drawing.Point(79, 55);
            this.txtXLeftShow.Name = "txtXLeftShow";
            this.txtXLeftShow.Size = new System.Drawing.Size(57, 21);
            this.txtXLeftShow.TabIndex = 1;
            // 
            // txtXLeftFull
            // 
            this.txtXLeftFull.Location = new System.Drawing.Point(79, 24);
            this.txtXLeftFull.Name = "txtXLeftFull";
            this.txtXLeftFull.Size = new System.Drawing.Size(57, 21);
            this.txtXLeftFull.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(150, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "至";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "纵轴显示:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(150, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "至";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(150, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "至";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "横轴显示:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "横轴全程:";
            // 
            // chkRemainAll
            // 
            this.chkRemainAll.AutoSize = true;
            this.chkRemainAll.Location = new System.Drawing.Point(8, 87);
            this.chkRemainAll.Name = "chkRemainAll";
            this.chkRemainAll.Size = new System.Drawing.Size(96, 16);
            this.chkRemainAll.TabIndex = 2;
            this.chkRemainAll.Text = "应用至所有块";
            this.chkRemainAll.UseVisualStyleBackColor = true;
            // 
            // txtDowntReamin
            // 
            this.txtDowntReamin.Location = new System.Drawing.Point(182, 56);
            this.txtDowntReamin.Name = "txtDowntReamin";
            this.txtDowntReamin.Size = new System.Drawing.Size(57, 21);
            this.txtDowntReamin.TabIndex = 1;
            // 
            // txtRightReamin
            // 
            this.txtRightReamin.Location = new System.Drawing.Point(181, 26);
            this.txtRightReamin.Name = "txtRightReamin";
            this.txtRightReamin.Size = new System.Drawing.Size(57, 21);
            this.txtRightReamin.TabIndex = 1;
            // 
            // txtUpReamin
            // 
            this.txtUpReamin.Location = new System.Drawing.Point(58, 56);
            this.txtUpReamin.Name = "txtUpReamin";
            this.txtUpReamin.Size = new System.Drawing.Size(57, 21);
            this.txtUpReamin.TabIndex = 1;
            // 
            // txtLeftRemain
            // 
            this.txtLeftRemain.Location = new System.Drawing.Point(59, 24);
            this.txtLeftRemain.Name = "txtLeftRemain";
            this.txtLeftRemain.Size = new System.Drawing.Size(57, 21);
            this.txtLeftRemain.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(125, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "下边距:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(122, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "右边距:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkRemainAll);
            this.groupBox1.Controls.Add(this.txtDowntReamin);
            this.groupBox1.Controls.Add(this.txtRightReamin);
            this.groupBox1.Controls.Add(this.txtUpReamin);
            this.groupBox1.Controls.Add(this.txtLeftRemain);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Location = new System.Drawing.Point(375, 165);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(252, 113);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "边距设置";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(2, 61);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "上边距:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "左边距:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.picClrCursor);
            this.groupBox2.Controls.Add(this.picClrBckgrd);
            this.groupBox2.Controls.Add(this.picClrSlcArea);
            this.groupBox2.Controls.Add(this.picClrInfo);
            this.groupBox2.Controls.Add(this.picClrShape);
            this.groupBox2.Controls.Add(this.picClrGrid);
            this.groupBox2.Controls.Add(this.picClrRect);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtWidthCursor);
            this.groupBox2.Controls.Add(this.txtWidthShape);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtWidthGrid);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.txtWidthRect);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(12, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(357, 267);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "颜色线宽设置";
            // 
            // picClrCursor
            // 
            this.picClrCursor.BackColor = System.Drawing.Color.Red;
            this.picClrCursor.Location = new System.Drawing.Point(110, 130);
            this.picClrCursor.Name = "picClrCursor";
            this.picClrCursor.Size = new System.Drawing.Size(77, 22);
            this.picClrCursor.TabIndex = 3;
            this.picClrCursor.TabStop = false;
            this.picClrCursor.Click += new System.EventHandler(this.picClrCursor_Click);
            // 
            // picClrBckgrd
            // 
            this.picClrBckgrd.BackColor = System.Drawing.Color.White;
            this.picClrBckgrd.Location = new System.Drawing.Point(110, 206);
            this.picClrBckgrd.Name = "picClrBckgrd";
            this.picClrBckgrd.Size = new System.Drawing.Size(77, 22);
            this.picClrBckgrd.TabIndex = 3;
            this.picClrBckgrd.TabStop = false;
            this.picClrBckgrd.Click += new System.EventHandler(this.picClrBckgrd_Click);
            // 
            // picClrSlcArea
            // 
            this.picClrSlcArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.picClrSlcArea.Location = new System.Drawing.Point(109, 237);
            this.picClrSlcArea.Name = "picClrSlcArea";
            this.picClrSlcArea.Size = new System.Drawing.Size(77, 22);
            this.picClrSlcArea.TabIndex = 3;
            this.picClrSlcArea.TabStop = false;
            this.picClrSlcArea.Click += new System.EventHandler(this.picClrSlcArea_Click);
            // 
            // picClrInfo
            // 
            this.picClrInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.picClrInfo.Location = new System.Drawing.Point(110, 171);
            this.picClrInfo.Name = "picClrInfo";
            this.picClrInfo.Size = new System.Drawing.Size(77, 22);
            this.picClrInfo.TabIndex = 3;
            this.picClrInfo.TabStop = false;
            this.picClrInfo.Click += new System.EventHandler(this.picClrInfo_Click);
            // 
            // picClrShape
            // 
            this.picClrShape.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.picClrShape.Location = new System.Drawing.Point(110, 95);
            this.picClrShape.Name = "picClrShape";
            this.picClrShape.Size = new System.Drawing.Size(77, 22);
            this.picClrShape.TabIndex = 3;
            this.picClrShape.TabStop = false;
            this.picClrShape.Click += new System.EventHandler(this.picClrShape_Click);
            // 
            // picClrGrid
            // 
            this.picClrGrid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.picClrGrid.Location = new System.Drawing.Point(110, 60);
            this.picClrGrid.Name = "picClrGrid";
            this.picClrGrid.Size = new System.Drawing.Size(77, 22);
            this.picClrGrid.TabIndex = 3;
            this.picClrGrid.TabStop = false;
            this.picClrGrid.Click += new System.EventHandler(this.picClrGrid_Click);
            // 
            // picClrRect
            // 
            this.picClrRect.BackColor = System.Drawing.Color.Black;
            this.picClrRect.Location = new System.Drawing.Point(110, 25);
            this.picClrRect.Name = "picClrRect";
            this.picClrRect.Size = new System.Drawing.Size(77, 22);
            this.picClrRect.TabIndex = 3;
            this.picClrRect.TabStop = false;
            this.picClrRect.Click += new System.EventHandler(this.picClrRect_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 207);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "背景颜色:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 240);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "框选区颜色:";
            // 
            // txtWidthCursor
            // 
            this.txtWidthCursor.Location = new System.Drawing.Point(277, 139);
            this.txtWidthCursor.Name = "txtWidthCursor";
            this.txtWidthCursor.Size = new System.Drawing.Size(57, 21);
            this.txtWidthCursor.TabIndex = 1;
            // 
            // txtWidthShape
            // 
            this.txtWidthShape.Location = new System.Drawing.Point(277, 103);
            this.txtWidthShape.Name = "txtWidthShape";
            this.txtWidthShape.Size = new System.Drawing.Size(57, 21);
            this.txtWidthShape.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "数据信息颜色:";
            // 
            // txtWidthGrid
            // 
            this.txtWidthGrid.Location = new System.Drawing.Point(277, 68);
            this.txtWidthGrid.Name = "txtWidthGrid";
            this.txtWidthGrid.Size = new System.Drawing.Size(57, 21);
            this.txtWidthGrid.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(203, 140);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 12);
            this.label21.TabIndex = 0;
            this.label21.Text = "游标线宽:";
            // 
            // txtWidthRect
            // 
            this.txtWidthRect.Location = new System.Drawing.Point(276, 29);
            this.txtWidthRect.Name = "txtWidthRect";
            this.txtWidthRect.Size = new System.Drawing.Size(57, 21);
            this.txtWidthRect.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "游标颜色:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(203, 67);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "网格线宽:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "网格颜色:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(203, 103);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "图形线宽:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "图形颜色:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(203, 30);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "边框线宽:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "边框颜色:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmbLineStyle);
            this.groupBox3.Controls.Add(this.chkLogAll);
            this.groupBox3.Controls.Add(this.chkYLog);
            this.groupBox3.Controls.Add(this.chkXLog);
            this.groupBox3.Location = new System.Drawing.Point(375, 333);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(252, 72);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "显示方式";
            // 
            // chkLogAll
            // 
            this.chkLogAll.AutoSize = true;
            this.chkLogAll.Location = new System.Drawing.Point(8, 49);
            this.chkLogAll.Name = "chkLogAll";
            this.chkLogAll.Size = new System.Drawing.Size(96, 16);
            this.chkLogAll.TabIndex = 2;
            this.chkLogAll.Text = "应用至所有块";
            this.chkLogAll.UseVisualStyleBackColor = true;
            // 
            // chkYLog
            // 
            this.chkYLog.AutoSize = true;
            this.chkYLog.Location = new System.Drawing.Point(80, 20);
            this.chkYLog.Name = "chkYLog";
            this.chkYLog.Size = new System.Drawing.Size(66, 16);
            this.chkYLog.TabIndex = 2;
            this.chkYLog.Text = "Y轴对数";
            this.chkYLog.UseVisualStyleBackColor = true;
            // 
            // chkXLog
            // 
            this.chkXLog.AutoSize = true;
            this.chkXLog.Location = new System.Drawing.Point(8, 20);
            this.chkXLog.Name = "chkXLog";
            this.chkXLog.Size = new System.Drawing.Size(66, 16);
            this.chkXLog.TabIndex = 2;
            this.chkXLog.Text = "X轴对数";
            this.chkXLog.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioBtMulti);
            this.groupBox4.Controls.Add(this.radioBtSingle);
            this.groupBox4.Location = new System.Drawing.Point(375, 285);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(252, 41);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "显示方式";
            // 
            // radioBtMulti
            // 
            this.radioBtMulti.AutoSize = true;
            this.radioBtMulti.Checked = true;
            this.radioBtMulti.Location = new System.Drawing.Point(126, 18);
            this.radioBtMulti.Name = "radioBtMulti";
            this.radioBtMulti.Size = new System.Drawing.Size(71, 16);
            this.radioBtMulti.TabIndex = 0;
            this.radioBtMulti.TabStop = true;
            this.radioBtMulti.Text = "多列排列";
            this.radioBtMulti.UseVisualStyleBackColor = true;
            // 
            // radioBtSingle
            // 
            this.radioBtSingle.AutoSize = true;
            this.radioBtSingle.Location = new System.Drawing.Point(11, 18);
            this.radioBtSingle.Name = "radioBtSingle";
            this.radioBtSingle.Size = new System.Drawing.Size(71, 16);
            this.radioBtSingle.TabIndex = 0;
            this.radioBtSingle.Text = "单列排列";
            this.radioBtSingle.UseVisualStyleBackColor = true;
            // 
            // btOk
            // 
            this.btOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btOk.Location = new System.Drawing.Point(467, 413);
            this.btOk.Name = "btOk";
            this.btOk.Size = new System.Drawing.Size(75, 23);
            this.btOk.TabIndex = 4;
            this.btOk.Text = "确定";
            this.btOk.UseVisualStyleBackColor = true;
            this.btOk.Click += new System.EventHandler(this.btOk_Click);
            // 
            // btCancle
            // 
            this.btCancle.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancle.Location = new System.Drawing.Point(552, 413);
            this.btCancle.Name = "btCancle";
            this.btCancle.Size = new System.Drawing.Size(75, 23);
            this.btCancle.TabIndex = 4;
            this.btCancle.Text = "取消";
            this.btCancle.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.txtMinHeight);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.txtMinWidth);
            this.groupBox5.Location = new System.Drawing.Point(12, 289);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(357, 55);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "区域大小";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(185, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 12);
            this.label23.TabIndex = 0;
            this.label23.Text = "最小高度:";
            // 
            // txtMinHeight
            // 
            this.txtMinHeight.Location = new System.Drawing.Point(270, 16);
            this.txtMinHeight.Name = "txtMinHeight";
            this.txtMinHeight.Size = new System.Drawing.Size(57, 21);
            this.txtMinHeight.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(59, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "最小宽度:";
            // 
            // txtMinWidth
            // 
            this.txtMinWidth.Location = new System.Drawing.Point(86, 20);
            this.txtMinWidth.Name = "txtMinWidth";
            this.txtMinWidth.Size = new System.Drawing.Size(57, 21);
            this.txtMinWidth.TabIndex = 1;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.txtYMinPix);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.txtXMinPix);
            this.groupBox6.Location = new System.Drawing.Point(12, 347);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(357, 52);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "标注间隔";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(185, 17);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(77, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "Y轴最小间隔:";
            // 
            // txtYMinPix
            // 
            this.txtYMinPix.Location = new System.Drawing.Point(270, 12);
            this.txtYMinPix.Name = "txtYMinPix";
            this.txtYMinPix.Size = new System.Drawing.Size(57, 21);
            this.txtYMinPix.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 17);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "X轴最小间隔:";
            // 
            // txtXMinPix
            // 
            this.txtXMinPix.Location = new System.Drawing.Point(86, 13);
            this.txtXMinPix.Name = "txtXMinPix";
            this.txtXMinPix.Size = new System.Drawing.Size(57, 21);
            this.txtXMinPix.TabIndex = 1;
            // 
            // cmbLineStyle
            // 
            this.cmbLineStyle.FormattingEnabled = true;
            this.cmbLineStyle.Items.AddRange(new object[] {
            "连续线条",
            "虚线条",
            "离散圆形",
            "离散方形"});
            this.cmbLineStyle.Location = new System.Drawing.Point(166, 20);
            this.cmbLineStyle.Name = "cmbLineStyle";
            this.cmbLineStyle.Size = new System.Drawing.Size(70, 20);
            this.cmbLineStyle.TabIndex = 3;
            // 
            // FrmScreenProp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 441);
            this.Controls.Add(this.btCancle);
            this.Controls.Add(this.btOk);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBoxRange);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmScreenProp";
            this.Text = "显示器设置";
            this.Load += new System.EventHandler(this.FrmScreenProp_Load);
            this.groupBoxRange.ResumeLayout(false);
            this.groupBoxRange.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClrCursor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrBckgrd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrSlcArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrShape)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClrRect)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxRange;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtXRightFull;
        private System.Windows.Forms.TextBox txtXLeftFull;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkRangeAll;
        private System.Windows.Forms.TextBox txtYDown;
        private System.Windows.Forms.TextBox txtXRightShow;
        private System.Windows.Forms.TextBox txtYUp;
        private System.Windows.Forms.TextBox txtXLeftShow;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox chkRemainAll;
        private System.Windows.Forms.TextBox txtDowntReamin;
        private System.Windows.Forms.TextBox txtRightReamin;
        private System.Windows.Forms.TextBox txtUpReamin;
        private System.Windows.Forms.TextBox txtLeftRemain;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox picClrRect;
        private System.Windows.Forms.TextBox txtWidthCursor;
        private System.Windows.Forms.TextBox txtWidthShape;
        private System.Windows.Forms.TextBox txtWidthGrid;
        private System.Windows.Forms.TextBox txtWidthRect;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.PictureBox picClrCursor;
        private System.Windows.Forms.PictureBox picClrBckgrd;
        private System.Windows.Forms.PictureBox picClrSlcArea;
        private System.Windows.Forms.PictureBox picClrInfo;
        private System.Windows.Forms.PictureBox picClrShape;
        private System.Windows.Forms.PictureBox picClrGrid;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkLogAll;
        private System.Windows.Forms.CheckBox chkYLog;
        private System.Windows.Forms.CheckBox chkXLog;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioBtMulti;
        private System.Windows.Forms.RadioButton radioBtSingle;
        private System.Windows.Forms.Button btOk;
        private System.Windows.Forms.Button btCancle;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtMinHeight;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtMinWidth;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtYMinPix;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtXMinPix;
        private System.Windows.Forms.ComboBox cmbLineStyle;
    }
}