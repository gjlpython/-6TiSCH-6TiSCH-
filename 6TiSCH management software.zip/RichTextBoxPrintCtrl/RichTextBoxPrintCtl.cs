﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Drawing.Printing;
using RichTextBoxPrintCtrl.Properties;

namespace RichTextBoxPrintCtrl
{
    public class RichTextBoxPrintCtrl : RichTextBox
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem CopyItem;
        private System.Windows.Forms.ToolStripMenuItem PasterItem;
        private System.Windows.Forms.ToolStripMenuItem UndoItem;
        private System.Windows.Forms.ToolStripMenuItem CutItem;
        private System.Windows.Forms.ToolStripMenuItem ClearItem;
        private System.Windows.Forms.ToolStripMenuItem SelectAllItem;
        private System.Windows.Forms.ToolStripMenuItem RedoItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripSeparator toolStripSeparator2;

        public RichTextBoxPrintCtrl()
        {
            InitializeComponent();
        }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.UndoItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CopyItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CutItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PasterItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClearItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.SelectAllItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RedoItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UndoItem,
            this.toolStripSeparator1,
            this.CopyItem,
            this.CutItem,
            this.PasterItem,
            this.ClearItem,
            this.toolStripSeparator2,
            this.SelectAllItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(172, 184);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // UndoItem
            // 
            this.UndoItem.Image = global::RichTextBoxPrintCtrl.Properties.Resources.undo;
            this.UndoItem.Name = "UndoItem";
            this.UndoItem.Size = new System.Drawing.Size(171, 28);
            this.UndoItem.Text = "撤销          ";
            this.UndoItem.Click += new System.EventHandler(this.UndoItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(168, 6);
            // 
            // CopyItem
            // 
            this.CopyItem.Image = global::RichTextBoxPrintCtrl.Properties.Resources.copy;
            this.CopyItem.Name = "CopyItem";
            this.CopyItem.Size = new System.Drawing.Size(171, 28);
            this.CopyItem.Text = "复制";
            this.CopyItem.Click += new System.EventHandler(this.CopyItem_Click);
            // 
            // CutItem
            // 
            this.CutItem.Image = global::RichTextBoxPrintCtrl.Properties.Resources.cut;
            this.CutItem.Name = "CutItem";
            this.CutItem.Size = new System.Drawing.Size(171, 28);
            this.CutItem.Text = "剪切           ";
            this.CutItem.Click += new System.EventHandler(this.CutItem_Click);
            // 
            // PasterItem
            // 
            this.PasterItem.Image = global::RichTextBoxPrintCtrl.Properties.Resources.paster;
            this.PasterItem.Name = "PasterItem";
            this.PasterItem.Size = new System.Drawing.Size(171, 28);
            this.PasterItem.Text = "粘贴";
            this.PasterItem.Click += new System.EventHandler(this.PasterItem_Click);
            // 
            // ClearItem
            // 
            this.ClearItem.Image = global::RichTextBoxPrintCtrl.Properties.Resources.clear;
            this.ClearItem.Name = "ClearItem";
            this.ClearItem.Size = new System.Drawing.Size(171, 28);
            this.ClearItem.Text = "清除";
            this.ClearItem.Click += new System.EventHandler(this.ClearItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(168, 6);
            // 
            // SelectAllItem
            // 
            this.SelectAllItem.Image = global::RichTextBoxPrintCtrl.Properties.Resources.all;
            this.SelectAllItem.Name = "SelectAllItem";
            this.SelectAllItem.Size = new System.Drawing.Size(171, 28);
            this.SelectAllItem.Text = "全选";
            this.SelectAllItem.Click += new System.EventHandler(this.SelectAllItem_Click);
            // 
            // RedoItem
            // 
            this.RedoItem.Name = "RedoItem";
            this.RedoItem.Size = new System.Drawing.Size(32, 19);
            // 
            // RichTextBoxPrintCtrl
            // 
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MyRichTextBox_MouseUp);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private void MyRichTextBox_MouseUp(object sender, MouseEventArgs e)//控制右键菜单的显示
        {
            if (e.Button == MouseButtons.Right)
            {
                if (base.CanRedo)//redo重做
                {
                    UndoItem.Enabled = true;//CopyItem
                }
                else
                {
                    UndoItem.Enabled = false;
                }
                if (base.CanUndo)//undo
                {
                    UndoItem.Enabled = true;
                }
                else
                {
                    UndoItem.Enabled = false;
                }

                if (base.SelectionLength > 0)
                {
                    CopyItem.Enabled = true;
                    CutItem.Enabled = true;//剪切
                    ClearItem.Enabled = true;
                }
                else
                {
                    CopyItem.Enabled = false;
                    CutItem.Enabled = false;
                    ClearItem.Enabled = false;
                }

                if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text))
                {
                    PasterItem.Enabled = true;
                }
                else
                {
                    PasterItem.Enabled = false;
                    contextMenuStrip1.Show(this, new Point(e.X, e.Y));
                }
            }
        }
        private void CopyItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();//先获取焦点，防止点两下才运行
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.Copy();
        }

        private void PasterItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.Paste();

        }

        private void UndoItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.Undo();
        }

        private void CutItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.Cut();
        }


        private void ClearItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.SelectedText = string.Empty;
        }

        private void SelectAllItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.SelectAll();
        }

        private void RedoItem_Click(object sender, EventArgs e)
        {
            this.contextMenuStrip1.SourceControl.Select();
            RichTextBox rtb = (RichTextBox)this.contextMenuStrip1.SourceControl;
            rtb.Redo();
        }












        //Convert the unit used by the .NET framework (1/100 inch) 
        //and the unit used by Win32 API calls (twips 1/1440 inch)
        private const double anInch = 14.4;

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct CHARRANGE
        {
            public int cpMin;         //First character of range (0 for start of doc)
            public int cpMax;           //Last character of range (-1 for end of doc)
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct FORMATRANGE
        {
            public IntPtr hdc;             //Actual DC to draw on
            public IntPtr hdcTarget;       //Target DC for determining text formatting
            public RECT rc;                //Region of the DC to draw to (in twips)
            public RECT rcPage;            //Region of the whole DC (page size) (in twips)
            public CHARRANGE chrg;         //Range of text to draw (see earlier declaration)
        }

        private const int WM_USER = 0x0400;
        private const int EM_FORMATRANGE = WM_USER + 57;

        [DllImport("USER32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);

        // Render the contents of the RichTextBox for printing
        //	Return the last character printed + 1 (printing start from this point for next page)
        public int Print(int charFrom, int charTo, PrintPageEventArgs e)
        {
            //Calculate the area to render and print
            RECT rectToPrint;
            rectToPrint.Top = (int)(e.MarginBounds.Top * anInch);
            rectToPrint.Bottom = (int)(e.MarginBounds.Bottom * anInch);
            rectToPrint.Left = (int)(e.MarginBounds.Left * anInch);
            rectToPrint.Right = (int)(e.MarginBounds.Right * anInch);

            //Calculate the size of the page
            RECT rectPage;
            rectPage.Top = (int)(e.PageBounds.Top * anInch);
            rectPage.Bottom = (int)(e.PageBounds.Bottom * anInch);
            rectPage.Left = (int)(e.PageBounds.Left * anInch);
            rectPage.Right = (int)(e.PageBounds.Right * anInch);

            IntPtr hdc = e.Graphics.GetHdc();

            FORMATRANGE fmtRange;
            fmtRange.chrg.cpMax = charTo;				//Indicate character from to character to 
            fmtRange.chrg.cpMin = charFrom;
            fmtRange.hdc = hdc;                    //Use the same DC for measuring and rendering
            fmtRange.hdcTarget = hdc;              //Point at printer hDC
            fmtRange.rc = rectToPrint;             //Indicate the area on page to print
            fmtRange.rcPage = rectPage;            //Indicate size of page

            IntPtr res = IntPtr.Zero;

            IntPtr wparam = IntPtr.Zero;
            wparam = new IntPtr(1);

            //Get the pointer to the FORMATRANGE structure in memory
            IntPtr lparam = IntPtr.Zero;
            lparam = Marshal.AllocCoTaskMem(Marshal.SizeOf(fmtRange));
            Marshal.StructureToPtr(fmtRange, lparam, false);

            //Send the rendered data for printing 
            res = SendMessage(Handle, EM_FORMATRANGE, wparam, lparam);

            //Free the block of memory allocated
            Marshal.FreeCoTaskMem(lparam);

            //Release the device context handle obtained by a previous call
            e.Graphics.ReleaseHdc(hdc);

            //Return last + 1 character printer
            return res.ToInt32();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

    }
}