﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;


namespace Lt_WinControls
{
    [DefaultProperty("Visible"), DefaultEvent("Click")]

    [ToolboxItem(true)]

    [ToolboxBitmap(typeof(PanelEx), "Resources.PanelEx.bmp")]

    [Description("表示一个可以自定义边框样式的Panel控件。")]

    //[Designer(typeof(PanelExDesigner))]

    //[Docking(DockingBehavior.Ask)]

    public class PanelEx : Panel
    {

        #region 属性

        bool _topLeft = true;

        [DefaultValue(true)]

        [Description("当CornerMode为Round时，是否显示左上角"), Category("自定义外观")]

        public bool TopLeft
        {

            get { return _topLeft; }

            set
            {

                _topLeft = value;

                base.Invalidate();

            }

        }



        bool _topRight = true;

        [DefaultValue(true)]

        [Description("当CornerMode为Round时，是否显示右上角"), Category("自定义外观")]

        public bool TopRight
        {

            get { return _topRight; }

            set
            {

                _topRight = value;

                base.Invalidate();

            }

        }



        bool _bottomLeft = true;

        [DefaultValue(true)]

        [Description("当CornerMode为Round时，是否显示左下角"), Category("自定义外观")]

        public bool BottomLeft
        {

            get { return _bottomLeft; }

            set
            {

                _bottomLeft = value;

                base.Invalidate();

            }

        }

        bool _bottomRight = true;

        [DefaultValue(true)]

        [Description("当CornerMode为Round时，是否显示右下角"), Category("自定义外观")]

        public bool BottomRight
        {

            get { return _bottomRight; }

            set
            {

                _bottomRight = value;

                base.Invalidate();

            }

        }



        private Color _borderColor = Color.Black;

        [DefaultValue(typeof(Color), "Black")]

        [Description("设置边框线的颜色"), Category("自定义外观")]

        public Color BorderColor
        {

            get { return _borderColor; }

            set
            {

                _borderColor = value;

                base.Invalidate();

            }

        }

        private GradientMode _gradientMode = GradientMode.None;

        [DefaultValue(typeof(GradientMode), "0")]

        [Description("用渐变色来填充背景时的填充方式"), Category("自定义外观")]

        public GradientMode GradientMode
        {

            get { return _gradientMode; }

            set
            {

                _gradientMode = value;

                base.Invalidate();

            }

        }

        [Browsable(false)]

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]

        public override Color BackColor
        {

            get
            {

                return Color.Transparent;

            }

        }

        private Color _backColor1 = Color.White;

        [DefaultValue(typeof(Color), "White")]

        [Description("控件的背景色1(若同时设置两个背景色，就是会用渐变色来填充背景)"), Category("自定义外观")]

        public Color BackColor1
        {

            get { return _backColor1; }

            set
            {

                _backColor1 = value;

                base.Invalidate();

            }

        }

        private Color _backColor2 = Color.White;

        [DefaultValue(typeof(Color), "White")]

        [Description("控件的背景色2，当GradientMode不为None时有效"), Category("自定义外观")]

        public Color BackColor2
        {

            get { return _backColor2; }

            set
            {

                _backColor2 = value;

                base.Invalidate();

            }

        }

        private int _borderWidth = 1;

        [DefaultValue(1)]

        [Description("设置边框线的宽度"), Category("自定义外观")]

        public int BorderWidth
        {

            get { return _borderWidth; }

            set
            {

                if (value >= 0)
                {

                    _borderWidth = value;

                    SetPadding();

                    base.Invalidate();

                }

            }

        }



        private DashStyle _borderStyle = DashStyle.Solid;

        [DefaultValue(typeof(DashStyle), "0")]

        [Description("设置边框线样式"), Category("自定义外观")]

        public new DashStyle BorderStyle
        {

            get { return _borderStyle; }

            set
            {

                _borderStyle = value;

                base.Invalidate();

            }

        }



        private int _roundSize = 15;

        /// <summary>

        /// 设置边角大小

        /// </summary>

        [DefaultValue(15)]

        [Description("当CornerMode为Round时，设置边角大小"), Category("自定义外观")]

        public int RoundSize
        {

            get { return _roundSize; }

            set
            {

                if (value > 0)
                {

                    _roundSize = value;

                    base.Invalidate();

                }

            }

        }



        private CornerMode _cornerMode = CornerMode.Corner;

        /// <summary>

        /// 设置边角样式

        /// </summary>

        [DefaultValue(typeof(CornerMode), "2")]

        [Description("设置边角样式"), Category("自定义外观")]

        public CornerMode CornerMode
        {

            get { return _cornerMode; }

            set
            {

                _cornerMode = value;

                SetPadding();

                base.Invalidate();

            }

        }



        private bool _leftBorder = true;

        /// <summary>

        /// 左边框是否显示

        /// </summary>

        [DefaultValue(true)]

        [Description("当CornerMode为Corner时，是否显示左边框"), Category("自定义外观")]

        public bool LeftBorder
        {

            get { return _leftBorder; }

            set
            {

                _leftBorder = value;

                base.Invalidate();

            }

        }



        private bool _rightBorder = true;

        /// <summary>

        /// 是否显示右边框

        /// </summary>

        [DefaultValue(true)]

        [Description("当CornerMode为Corner时，是否显示右边框"), Category("自定义外观")]

        public bool RightBorder
        {

            get { return _rightBorder; }

            set
            {

                _rightBorder = value;

                base.Invalidate();

            }

        }



        private bool _topBorder = true;

        /// <summary>

        /// 是否显示上边框

        /// </summary>

        [DefaultValue(true)]

        [Description("当CornerMode为Corner时，是否显示上边框"), Category("自定义外观")]

        public bool TopBorder
        {

            get { return _topBorder; }

            set
            {

                _topBorder = value;

                base.Invalidate();

            }

        }



        private bool _bottomBorder = true;

        /// <summary>

        /// 是否显示下边框

        /// </summary>

        [DefaultValue(true)]

        [Description("当CornerMode为Corner时，是否显示下边框"), Category("自定义外观")]

        public bool BottomBorder
        {

            get { return _bottomBorder; }

            set
            {

                _bottomBorder = value;

                base.Invalidate();

            }

        }

        #endregion



        #region 构造函数

        /// <summary>

        /// 构造函数

        /// </summary>

        public PanelEx()
        {

            base.ResizeRedraw = true;

            this.BackColor = Color.Transparent;

        }

        #endregion



        private void SetPadding()
        {

            int left = this.Padding.Left;

            int right = this.Padding.Right;

            int top = this.Padding.Top;

            int bottom = this.Padding.Bottom;

            if (this.CornerMode == CornerMode.None)
            {

                left = 0;

                right = 0;

                top = 0;

                bottom = 0;

            }

            else
            {

                if (this.Padding.Left < this.BorderWidth)
                {

                    left = this.BorderWidth;

                }

                if (this.Padding.Right < this.BorderWidth)
                {

                    right = this.BorderWidth;

                }

                if (this.Padding.Top < this.BorderWidth)
                {

                    top = this.BorderWidth;

                }

                if (this.Padding.Bottom < this.BorderWidth)
                {

                    bottom = this.BorderWidth;

                }

            }

            this.Padding = new Padding(left, top, right, bottom);

        }



        #region 控件重绘事件

        /// <summary>

        /// 控件重绘事件

        /// </summary>

        /// <param name="e"></param>

        protected override void OnPaint(PaintEventArgs e)
        {

            base.OnPaint(e);

            Graphics g = e.Graphics;

            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            Rectangle rec = new Rectangle(0, 0, this.Width, this.Height);

            Pen pen = new Pen(BorderColor, BorderWidth);

            pen.DashStyle = BorderStyle;

            GraphicsPath path = CreateRound(rec, RoundSize, this.TopLeft, this.TopRight, this.BottomLeft, this.BottomRight);



            //绘制背景

            if (this.GradientMode == GradientMode.None)
            {

                using (Brush brush2 = new SolidBrush(this.BackColor1))
                {

                    if (this.CornerMode == CornerMode.Round)
                    {

                        g.FillPath(brush2, path);

                    }

                    else
                    {

                        g.FillRectangle(brush2, rec);

                    }

                }

            }

            else
            {

                if (this.CornerMode == CornerMode.Round)
                {

                    DrawGradient(g, rec, path, this.BackColor1, this.BackColor2, this._gradientMode);

                }

                else
                {

                    DrawGradient(g, rec, this.BackColor1, this.BackColor2, this._gradientMode);

                }

            }



            //绘制边框

            if (BorderWidth > 0)
            {

                switch (CornerMode)
                {

                    case CornerMode.None:

                        break;

                    case CornerMode.Corner:

                        if (LeftBorder)
                        {

                            g.DrawLine(pen, 0, 0, 0, this.Height - 1);

                        }

                        if (BottomBorder)
                        {

                            g.DrawLine(pen, 0, this.Height - 1, this.Width - 1, this.Height - 1);

                        }

                        if (RightBorder)
                        {

                            g.DrawLine(pen, Width - 1, this.Height - 1, this.Width - 1, 0);

                        }

                        if (TopBorder)
                        {

                            g.DrawLine(pen, this.Width - 1, 0, 0, 0);

                        }

                        break;

                    case CornerMode.Round:

                        g.DrawPath(pen, path);

                        break;

                }

            }

        }

        #endregion



        public static GraphicsPath CreateRound(Rectangle rect, int radius, bool topLeft, bool topRight, bool bottomLeft, bool bottomRight)
        {

            rect.Width -= 1;

            rect.Height -= 1;



            GraphicsPath roundRect = new GraphicsPath();

            //顶端

            roundRect.AddLine(rect.Left + radius / 2, rect.Top, rect.Right - radius / 2, rect.Top);

            //右上角

            if (topRight)
            {

                roundRect.AddArc(rect.Right - radius, rect.Top, radius, radius, 270, 90);

            }

            else
            {

                roundRect.AddLine(rect.Right - radius / 2, rect.Top, rect.Right, rect.Top);

                roundRect.AddLine(rect.Right, rect.Top, rect.Right, rect.Top + radius / 2);

            }



            //右边

            roundRect.AddLine(rect.Right, rect.Top + radius / 2, rect.Right, rect.Bottom - radius / 2);



            //右下角

            if (bottomRight)
            {

                roundRect.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);

            }

            else
            {

                roundRect.AddLine(rect.Right, rect.Bottom - radius / 2, rect.Right, rect.Bottom);

                roundRect.AddLine(rect.Right, rect.Bottom, rect.Right - radius / 2, rect.Bottom);

            }



            //底边

            roundRect.AddLine(rect.Right - radius / 2, rect.Bottom, rect.Left + radius / 2, rect.Bottom);



            //左下角

            if (bottomLeft)
            {

                roundRect.AddArc(rect.Left, rect.Bottom - radius, radius, radius, 90, 90);

            }

            else
            {

                roundRect.AddLine(rect.Left + radius / 2, rect.Bottom, rect.Left, rect.Bottom);

                roundRect.AddLine(rect.Left, rect.Bottom, rect.Left, rect.Bottom - radius / 2);

            }



            //左边 不需要了

            // roundRect.AddLine(rect.Left, rect.Top + radius / 2, rect.Left, rect.Bottom - radius / 2);



            //左上角

            if (topLeft)
            {

                roundRect.AddArc(rect.Left, rect.Top, radius, radius, 180, 90);

            }

            else
            {

                roundRect.AddLine(rect.Left, rect.Top + radius / 2, rect.Left, rect.Top);

                roundRect.AddLine(rect.Left, rect.Top, rect.Left + radius / 2, rect.Top);

            }

            //闭合图像

            roundRect.CloseAllFigures();

            return roundRect;

        }





        public static void DrawGradient(Graphics e, Rectangle rect, GraphicsPath path, Color color1, Color color2, GradientMode mode)
        {

            LinearGradientMode backwardDiagonal = LinearGradientMode.BackwardDiagonal;

            if (mode == GradientMode.Vertical)
            {

                backwardDiagonal = LinearGradientMode.Vertical;

            }

            else if (mode == GradientMode.Horizontal)
            {

                backwardDiagonal = LinearGradientMode.Horizontal;

            }

            else if (mode == GradientMode.BackwardDiagonal)
            {

                backwardDiagonal = LinearGradientMode.BackwardDiagonal;

            }

            else if (mode == GradientMode.ForwardDiagonal)
            {

                backwardDiagonal = LinearGradientMode.ForwardDiagonal;

            }

            LinearGradientBrush brush = new LinearGradientBrush(rect, color1, color2, backwardDiagonal);

            e.FillPath(brush, path);

            brush.Dispose();

        }



        public static void DrawGradient(Graphics e, Rectangle rect, Color color1, Color color2, GradientMode mode)
        {

            LinearGradientMode backwardDiagonal = LinearGradientMode.BackwardDiagonal;

            if (mode == GradientMode.Vertical)
            {

                backwardDiagonal = LinearGradientMode.Vertical;

            }

            else if (mode == GradientMode.Horizontal)
            {

                backwardDiagonal = LinearGradientMode.Horizontal;

            }

            else if (mode == GradientMode.BackwardDiagonal)
            {

                backwardDiagonal = LinearGradientMode.BackwardDiagonal;

            }

            else if (mode == GradientMode.ForwardDiagonal)
            {

                backwardDiagonal = LinearGradientMode.ForwardDiagonal;

            }

            LinearGradientBrush brush = new LinearGradientBrush(rect, color1, color2, backwardDiagonal);

            e.FillRectangle(brush, rect);

            brush.Dispose();

        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // PanelEx
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ResumeLayout(false);

        }

    }





    public enum GradientMode
    {

        /// <summary>

        /// 无填充样式

        /// </summary>

        None = 0,

        /// <summary>

        /// 垂直填充

        /// </summary>

        Vertical = 1,

        /// <summary>

        /// 水平填充

        /// </summary>

        Horizontal = 2,

        /// <summary>

        /// 右上角到左下角

        /// </summary>

        BackwardDiagonal = 3,

        /// <summary>

        /// 左上角到右下角

        /// </summary>

        ForwardDiagonal = 4

    }



    public enum CornerMode
    {

        /// <summary>

        /// 没有边框

        /// </summary>

        None = 0,



        /// <summary>

        /// 指定圆角

        /// 此时的边框设置以上边框为准

        /// </summary>

        Round = 1,



        /// <summary>

        /// 指定尖角

        /// </summary>

        Corner = 2,

    }
}
